# Compose va AndroidX o'z qoidalarini o'zi qo'shadi.
-keepattributes *Annotation*
