plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// GitHub Actions avtomatik beradi: GITHUB_RUN_NUMBER (versiya raqami) va GITHUB_REPOSITORY (owner/repo).
val runNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
val appVersion = (project.findProperty("appVersion") as String?) ?: "4.0.7"
val githubRepo = System.getenv("GITHUB_REPOSITORY") ?: ""

android {
    namespace = "com.liquid.notes"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.liquid.notes"
        minSdk = 26
        targetSdk = 35
        versionCode = runNumber
        versionName = appVersion
        buildConfigField("String", "GITHUB_REPO", "\"$githubRepo\"")
    }

    signingConfigs {
        create("notes") {
            // Doimiy kalit: har bir yangi APK eskisining ustiga o'rnatiladi, eslatmalar saqlanib qoladi.
            storeFile = file("notes.keystore")
            storePassword = "liquidnotes"
            keyAlias = "notes"
            keyPassword = "liquidnotes"
            storeType = "pkcs12"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("notes")
        }
        debug {
            signingConfig = signingConfigs.getByName("notes")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
