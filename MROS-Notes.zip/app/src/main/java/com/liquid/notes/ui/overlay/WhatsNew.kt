package com.liquid.notes.ui.overlay

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liquid.notes.BuildConfig
import com.liquid.notes.ui.components.AppIcon
import com.liquid.notes.ui.glass.GlassStyle
import com.liquid.notes.ui.glass.GlassSurface
import com.liquid.notes.ui.icons.Sf
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.theme.TS
import com.liquid.notes.util.LocalStrings

/** iOS-style "What's New" sheet: shown once after every update, doubles as a how-to. */
@Composable
internal fun WhatsNewLayer(state: OverlayState) {
    val shown = state.whatsNew
    val sx by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = if (shown) spring<Float>(dampingRatio = 0.62f, stiffness = 260f) else tween<Float>(220),
        label = "wnX",
    )
    val sy by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = if (shown) spring<Float>(dampingRatio = 0.55f, stiffness = 170f) else tween<Float>(200),
        label = "wnY",
    )
    if (!shown && sx < 0.02f && sy < 0.02f) return
    val ios = LocalIos.current
    val s = LocalStrings.current
    val origin = remember(shown) { state.touch?.last ?: Offset.Unspecified }
    var box by remember { mutableStateOf(Rect.Zero) }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val icons: List<Pair<ImageVector, Color>> = listOf(
        Sf.Sparkles to ios.accent,
        Sf.Drop to ios.blue,
        Sf.Hand to ios.purple,
        Sf.Checklist to ios.orange,
        Sf.Undo to ios.teal,
        Sf.Tag to ios.pink,
        Sf.Grid to ios.green,
        Sf.ArrowsCircle to ios.gray,
        Sf.Bell to ios.red,
    )
    Box(
        Modifier
            .fillMaxSize()
            .padding(start = 10.dp, end = 10.dp, top = top + 10.dp, bottom = bottom + 10.dp),
    ) {
        GlassSurface(
            modifier = Modifier
                .fillMaxSize()
                .onGloballyPositioned { box = it.boundsInRoot() }
                .graphicsLayer {
                    // big window: rises from the bottom and lands like a drop (wide → tall)
                    val h = if (box.height > 0f) box.height else 2400f
                    translationY = (h + 60.dp.toPx()) * (1f - sy.coerceIn(0f, 1f))
                    scaleX = 1.05f - 0.05f * sx
                    scaleY = 0.93f + 0.07f * sy
                    transformOrigin = TransformOrigin(0.5f, 1f)
                    alpha = (sy * 3f).coerceIn(0f, 1f)
                }
                .pointerInput(Unit) { detectTapGestures { } },
            corner = 40.dp,
            style = GlassStyle.Panel,
            elevation = 24.dp,
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(Modifier.fillMaxSize()) {
                Column(
                    Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 26.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Spacer(Modifier.height(34.dp))
                    AppIcon(76.dp)
                    Spacer(Modifier.height(16.dp))
                    Text(
                        s.whatsNewHeading,
                        style = TS.largeTitle.copy(fontSize = 30.sp),
                        color = ios.label,
                        textAlign = TextAlign.Center,
                    )
                    Text(
                        "MROS Notes ${BuildConfig.VERSION_NAME}",
                        style = TS.subhead,
                        color = ios.secondaryLabel,
                    )
                    Spacer(Modifier.height(26.dp))
                    s.whatsNewItems.forEachIndexed { i, (title, text) ->
                        val (icon, color) = icons[i % icons.size]
                        FeatureRow(icon, color, title, text, index = i, appear = { sy })
                    }
                    Spacer(Modifier.height(20.dp))
                }
                ContinueButton(
                    text = s.continueLabel,
                    modifier = Modifier.padding(start = 22.dp, end = 22.dp, top = 12.dp, bottom = 20.dp),
                ) { state.whatsNew = false }
            }
        }
    }
}

@Composable
private fun FeatureRow(icon: ImageVector, color: Color, title: String, text: String, index: Int, appear: () -> Float) {
    val ios = LocalIos.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
            .graphicsLayer {
                // rows flow in one after another, like drops
                val p = (appear() * 1.5f - index * 0.09f).coerceIn(0f, 1f)
                alpha = p
                translationY = (1f - p) * 22.dp.toPx()
            },
        verticalAlignment = Alignment.Top,
    ) {
        GlassSurface(
            modifier = Modifier.size(44.dp),
            corner = 14.dp,
            tint = color,
            lens = false,
            elevation = 4.dp,
            backdrop = null,
        ) {
            Icon(icon, null, Modifier.size(24.dp), tint = Color.White)
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = TS.headline, color = ios.label)
            Spacer(Modifier.height(2.dp))
            Text(text, style = TS.subhead, color = ios.secondaryLabel)
        }
    }
}

@Composable
private fun ContinueButton(text: String, modifier: Modifier, onClick: () -> Unit) {
    val ios = LocalIos.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    GlassSurface(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        corner = 27.dp,
        tint = ios.accent,
        pressed = pressed,
        lens = false,
        elevation = 8.dp,
        backdrop = null,
    ) {
        Text(text, style = TS.body.copy(fontWeight = FontWeight.SemiBold), color = ios.onAccent)
    }
}
