package com.liquid.notes.ui.overlay

import android.os.Build
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import com.liquid.notes.ui.glass.Backdrop
import com.liquid.notes.ui.glass.BackdropLayer
import com.liquid.notes.ui.glass.GlassStyle
import com.liquid.notes.ui.glass.GlassSurface
import com.liquid.notes.ui.glass.glassSupported
import com.liquid.notes.ui.icons.Sf
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.theme.TS
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.roundToInt

class MenuAction(
    val title: String,
    val icon: ImageVector? = null,
    val destructive: Boolean = false,
    val checked: Boolean = false,
    val enabled: Boolean = true,
    val onClick: () -> Unit,
)

class MenuGroup(val title: String?, val actions: List<MenuAction>)

class MenuRequest(
    val anchor: Rect,
    val groups: List<MenuGroup>,
    val alignEnd: Boolean = true,
    val preview: (@Composable () -> Unit)? = null,
)

class AlertButton(
    val title: String,
    val bold: Boolean = false,
    val destructive: Boolean = false,
    val needsInput: Boolean = false,
    val onClick: (String) -> Unit,
)

class AlertRequest(
    val title: String,
    val message: String? = null,
    val input: String? = null,
    val placeholder: String = "",
    val buttons: List<AlertButton>,
)

class SheetItem(
    val title: String,
    val icon: ImageVector,
    val selected: Boolean,
    val onClick: () -> Unit,
)

class SheetRequest(val title: String, val items: List<SheetItem>)

class ProgressRequest(val title: String, val value: Float)

@Stable
class OverlayState {
    var menu by mutableStateOf<MenuRequest?>(null)
    var alert by mutableStateOf<AlertRequest?>(null)
    var sheet by mutableStateOf<SheetRequest?>(null)
    var progress by mutableStateOf<ProgressRequest?>(null)

    val anyVisible: Boolean get() = menu != null || alert != null || sheet != null || progress != null

    fun dismissOutside() {
        menu = null
        sheet = null
    }

    fun dismissAll() {
        menu = null
        sheet = null
        alert = null
    }

    fun message(title: String, text: String?, ok: String) {
        alert = AlertRequest(title = title, message = text, buttons = listOf(AlertButton(ok, bold = true) { }))
    }
}

private class LastHolder<T>(var value: T?)

/** Keeps the last non-null value so content can animate out. */
@Composable
private fun <T> rememberLast(value: T?): T? {
    val holder = remember { LastHolder<T>(null) }
    if (value != null) holder.value = value
    return holder.value
}

@Composable
fun OverlayHost(state: OverlayState, backdrop: Backdrop) {
    val ios = LocalIos.current
    val visible = state.anyVisible
    BackHandler(enabled = visible) {
        if (state.menu != null || state.sheet != null) state.dismissOutside() else if (state.progress == null) state.alert = null
    }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(240)),
        exit = fadeOut(tween(220)),
    ) {
        // the world behind slowly goes "under water"
        val depth by transition.animateFloat(
            transitionSpec = { tween<Float>(360) },
            label = "underwater",
        ) { st -> if (st == EnterExitState.Visible) 1f else 0f }
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) { detectTapGestures(onTap = { state.dismissOutside() }) },
        ) {
            if (glassSupported) {
                BackdropLayer(backdrop, Modifier.fillMaxSize(), blur = 1.dp + 11.dp * depth, saturation = 1f + 0.2f * depth)
            }
            Box(Modifier.fillMaxSize().background(ios.dim))
        }
    }
    MenuLayer(state)
    SheetLayer(state)
    AlertLayer(state)
    ProgressLayer(state)
}

// ------------------------------------------------------------------ menus

@Composable
private fun MenuLayer(state: OverlayState) {
    val req = state.menu
    val last = rememberLast(req)
    val shown = req != null
    // X and Y grow on different springs: the menu stretches out of the button like a drop
    val px by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = if (shown) spring<Float>(dampingRatio = 0.58f, stiffness = 430f) else tween<Float>(170),
        label = "menuX",
    )
    val py by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = if (shown) spring<Float>(dampingRatio = 0.5f, stiffness = 250f) else tween<Float>(150),
        label = "menuY",
    )
    if (last == null || (!shown && px < 0.02f && py < 0.02f)) return
    val ios = LocalIos.current
    val density = LocalDensity.current
    val screenH = with(density) { LocalConfiguration.current.screenHeightDp.dp.toPx() }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val hasPreview = last.preview != null
    val opensUp = !hasPreview && last.anchor.center.y > screenH * 0.6f
    Layout(
        modifier = Modifier.fillMaxSize(),
        content = {
            Column(
                modifier = Modifier.graphicsLayer {
                    val a = minOf(px, py).coerceIn(0f, 1f)
                    alpha = px.coerceIn(0f, 1f)
                    scaleX = 0.3f + 0.7f * px
                    scaleY = 0.12f + 0.88f * py
                    transformOrigin = TransformOrigin(
                        if (last.alignEnd) 1f else 0f,
                        when {
                            hasPreview -> 0.5f
                            opensUp -> 1f
                            else -> 0f
                        },
                    )
                    val b = (1f - a) * 14.dp.toPx()
                    renderEffect = if (Build.VERSION.SDK_INT >= 31 && b > 0.5f) BlurEffect(b, b, TileMode.Decal) else null
                },
                horizontalAlignment = if (last.alignEnd) Alignment.End else Alignment.Start,
            ) {
                val preview = last.preview
                if (preview != null) {
                    Box(Modifier.pointerInput(Unit) { detectTapGestures { } }) { preview() }
                    Spacer(Modifier.height(10.dp))
                }
                GlassSurface(
                    modifier = Modifier
                        .width(254.dp)
                        .pointerInput(Unit) { detectTapGestures { } },
                    corner = 26.dp,
                    style = GlassStyle.Panel,
                    elevation = 18.dp,
                ) {
                    Column(Modifier.padding(vertical = 6.dp)) {
                        var rowIndex = 0
                        last.groups.forEachIndexed { gi, group ->
                            if (gi > 0) {
                                Box(
                                    Modifier
                                        .padding(horizontal = 16.dp, vertical = 5.dp)
                                        .fillMaxWidth()
                                        .height(0.6.dp)
                                        .background(ios.separator),
                                )
                            }
                            val gt = group.title
                            if (gt != null) {
                                Text(
                                    gt,
                                    style = TS.footnote,
                                    color = ios.secondaryLabel,
                                    modifier = Modifier.padding(start = 20.dp, top = 6.dp, bottom = 2.dp),
                                )
                            }
                            group.actions.forEach { a ->
                                MenuRow(a, index = rowIndex, appear = { px }) {
                                    state.menu = null
                                    a.onClick()
                                }
                                rowIndex += 1
                            }
                        }
                    }
                }
            }
        },
    ) { measurables, constraints ->
        val placeable = measurables.first().measure(Constraints(maxWidth = constraints.maxWidth, maxHeight = constraints.maxHeight))
        val margin = 12.dp.roundToPx()
        val topPx = top.roundToPx() + margin
        val bottomPx = constraints.maxHeight - bottom.roundToPx() - margin
        val a = last.anchor
        val rawX = if (last.alignEnd) a.right - placeable.width else a.left
        val maxX = max(margin, constraints.maxWidth - placeable.width - margin)
        val x = rawX.roundToInt().coerceIn(margin, maxX)
        var y = if (hasPreview) a.top.roundToInt() else (a.bottom + 8.dp.toPx()).roundToInt()
        if (y + placeable.height > bottomPx) {
            y = if (hasPreview) bottomPx - placeable.height else (a.top - 8.dp.toPx() - placeable.height).roundToInt()
        }
        y = y.coerceAtLeast(topPx)
        layout(constraints.maxWidth, constraints.maxHeight) { placeable.place(x, y) }
    }
}

@Composable
private fun MenuRow(a: MenuAction, index: Int, appear: () -> Float, onClick: () -> Unit) {
    val ios = LocalIos.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val color = when {
        !a.enabled -> ios.secondaryLabel
        a.destructive -> ios.red
        else -> ios.label
    }
    Row(
        Modifier
            .graphicsLayer {
                // rows ripple in one after another
                val rp = (appear() * 1.4f - index * 0.08f).coerceIn(0f, 1f)
                alpha = rp
                translationY = (1f - rp) * -8.dp.toPx()
            }
            .padding(horizontal = 6.dp)
            .fillMaxWidth()
            .height(46.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (pressed && a.enabled) ios.fill else Color.Transparent)
            .clickable(interactionSource = src, indication = null, enabled = a.enabled, onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(30.dp), contentAlignment = Alignment.CenterStart) {
            val icon = if (a.checked) Sf.Checkmark else a.icon
            if (icon != null) {
                Icon(icon, contentDescription = null, modifier = Modifier.size(if (a.checked) 16.dp else 20.dp), tint = color)
            }
        }
        Text(a.title, style = TS.body, color = color, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// ------------------------------------------------------------------ sheet

@Composable
private fun SheetLayer(state: OverlayState) {
    val ios = LocalIos.current
    val req = state.sheet
    val last = rememberLast(req)
    AnimatedVisibility(
        visible = req != null,
        enter = slideInVertically(spring(dampingRatio = 0.7f, stiffness = 300f)) { it },
        exit = slideOutVertically(tween(220)) { it },
        modifier = Modifier.fillMaxSize(),
    ) {
        if (last != null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                GlassSurface(
                    modifier = Modifier
                        .navigationBarsPadding()
                        .padding(start = 8.dp, end = 8.dp, bottom = 8.dp)
                        .fillMaxWidth()
                        .pointerInput(Unit) { detectTapGestures { } },
                    corner = 36.dp,
                    style = GlassStyle.Panel,
                    elevation = 20.dp,
                    contentAlignment = Alignment.TopCenter,
                ) {
                    Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 14.dp)) {
                        Box(Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 12.dp)) {
                            Text(
                                last.title,
                                style = TS.headline,
                                color = ios.label,
                                modifier = Modifier.align(Alignment.Center),
                            )
                            Box(
                                Modifier
                                    .align(Alignment.CenterEnd)
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(ios.fill)
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = null,
                                    ) { state.sheet = null },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Sf.XMark, null, Modifier.size(13.dp), tint = ios.secondaryLabel)
                            }
                        }
                        Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState())) {
                            last.items.forEach { item ->
                                SheetRow(item) {
                                    state.sheet = null
                                    if (!item.selected) item.onClick()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SheetRow(item: SheetItem, onClick: () -> Unit) {
    val ios = LocalIos.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    Row(
        Modifier
            .padding(horizontal = 10.dp)
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(if (pressed) ios.fill else Color.Transparent)
            .clickable(interactionSource = src, indication = null, onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(item.icon, null, Modifier.size(24.dp), tint = if (item.selected) ios.secondaryLabel else ios.accent)
        Spacer(Modifier.width(14.dp))
        Text(
            item.title,
            style = TS.body,
            color = if (item.selected) ios.secondaryLabel else ios.label,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (item.selected) Icon(Sf.Checkmark, null, Modifier.size(16.dp), tint = ios.accent)
    }
}

// ------------------------------------------------------------------ alert

@Composable
private fun AlertLayer(state: OverlayState) {
    val ios = LocalIos.current
    val req = state.alert
    val last = rememberLast(req)
    val shown = req != null
    val ax by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = if (shown) spring<Float>(dampingRatio = 0.42f, stiffness = 380f) else tween<Float>(150),
        label = "alertX",
    )
    val p by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = if (shown) spring<Float>(dampingRatio = 0.5f, stiffness = 260f) else tween<Float>(150),
        label = "alert",
    )
    if (last == null || (!shown && p < 0.02f)) return
    var text by remember(last) {
        val initial = last.input ?: ""
        mutableStateOf(TextFieldValue(initial, TextRange(0, initial.length)))
    }
    val focus = remember(last) { FocusRequester() }
    LaunchedEffect(last) {
        if (last.input != null) {
            delay(120)
            runCatching { focus.requestFocus() }
        }
    }
    fun press(b: AlertButton) {
        if (b.needsInput && text.text.isBlank()) return
        state.alert = null
        b.onClick(text.text)
    }
    Box(Modifier.fillMaxSize().imePadding(), contentAlignment = Alignment.Center) {
        GlassSurface(
            modifier = Modifier
                .width(300.dp)
                .graphicsLayer {
                    // lands like a water drop: wide and flat, then springs into shape
                    alpha = p.coerceIn(0f, 1f)
                    scaleX = 1.22f - 0.22f * ax
                    scaleY = 0.6f + 0.4f * p
                    val b = (1f - minOf(ax, p).coerceIn(0f, 1f)) * 12.dp.toPx()
                    renderEffect = if (Build.VERSION.SDK_INT >= 31 && b > 0.5f) BlurEffect(b, b, TileMode.Decal) else null
                }
                .pointerInput(Unit) { detectTapGestures { } },
            corner = 34.dp,
            style = GlassStyle.Panel,
            elevation = 24.dp,
        ) {
            Column(
                Modifier.padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(last.title, style = TS.headline, color = ios.label, textAlign = TextAlign.Center)
                val msg = last.message
                if (!msg.isNullOrBlank()) {
                    Spacer(Modifier.height(5.dp))
                    Text(
                        msg,
                        style = TS.subhead,
                        color = ios.label,
                        textAlign = TextAlign.Center,
                        maxLines = 12,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (last.input != null) {
                    Spacer(Modifier.height(14.dp))
                    BasicTextField(
                        value = text,
                        onValueChange = { text = it },
                        singleLine = true,
                        textStyle = TS.body.copy(color = ios.label),
                        cursorBrush = SolidColor(ios.accent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = {
                            val primary = last.buttons.lastOrNull { it.bold } ?: last.buttons.lastOrNull()
                            if (primary != null) press(primary)
                        }),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp)
                            .clip(RoundedCornerShape(21.dp))
                            .background(ios.fill)
                            .padding(horizontal = 14.dp)
                            .focusRequester(focus),
                        decorationBox = { inner ->
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.CenterStart) {
                                if (text.text.isEmpty()) {
                                    Text(last.placeholder, style = TS.body, color = ios.secondaryLabel)
                                }
                                inner()
                            }
                        },
                    )
                }
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    last.buttons.forEach { b ->
                        val enabled = !(b.needsInput && text.text.isBlank())
                        AlertCapsule(b, enabled, Modifier.weight(1f)) { press(b) }
                    }
                }
            }
        }
    }
}

@Composable
private fun AlertCapsule(b: AlertButton, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val ios = LocalIos.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val bg = when {
        b.destructive -> ios.red
        b.bold -> ios.accent
        else -> ios.fill
    }
    val fg = when {
        b.destructive -> Color.White
        b.bold -> ios.onAccent
        else -> ios.label
    }
    Box(
        modifier
            .height(48.dp)
            .graphicsLayer {
                val sc = if (pressed) 0.96f else 1f
                scaleX = sc
                scaleY = sc
                alpha = if (enabled) 1f else 0.4f
            }
            .clip(RoundedCornerShape(24.dp))
            .background(bg)
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            b.title,
            style = TS.body.copy(fontWeight = if (b.bold || b.destructive) FontWeight.SemiBold else FontWeight.Medium),
            color = fg,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
    }
}

// ------------------------------------------------------------------ progress

@Composable
private fun ProgressLayer(state: OverlayState) {
    val ios = LocalIos.current
    val req = state.progress
    val last = rememberLast(req)
    AnimatedVisibility(visible = req != null, enter = fadeIn(), exit = fadeOut(), modifier = Modifier.fillMaxSize()) {
        if (last != null) {
            val current = state.progress ?: last
            val v by animateFloatAsState(current.value.coerceIn(0f, 1f), label = "progress")
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                GlassSurface(
                    modifier = Modifier.width(280.dp).pointerInput(Unit) { detectTapGestures { } },
                    corner = 30.dp,
                    style = GlassStyle.Panel,
                    elevation = 24.dp,
                ) {
                    Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(current.title, style = TS.headline, color = ios.label)
                        Spacer(Modifier.height(14.dp))
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(CircleShape)
                                .background(ios.fill),
                        ) {
                            Box(
                                Modifier
                                    .fillMaxWidth(v)
                                    .height(6.dp)
                                    .clip(CircleShape)
                                    .background(ios.accent),
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("${(v * 100).roundToInt()}%", style = TS.footnote, color = ios.secondaryLabel)
                    }
                }
            }
        }
    }
}
