package com.liquid.notes.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.liquid.notes.R
import com.liquid.notes.ui.glass.GlassSurface
import com.liquid.notes.ui.icons.Sf
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.theme.TS
import kotlin.math.roundToInt

/** The 3D glass app icon, drawn from its two adaptive layers. */
@Composable
fun AppIcon(size: Dp) {
    Box(
        Modifier
            .size(size)
            .shadow(10.dp, RoundedCornerShape(size * 0.24f))
            .clip(RoundedCornerShape(size * 0.24f)),
        contentAlignment = Alignment.Center,
    ) {
        Image(painterResource(R.mipmap.ic_launcher_bg), null, Modifier.requiredSize(size * 1.5f))
        Image(painterResource(R.mipmap.ic_launcher_fg), null, Modifier.requiredSize(size * 1.5f))
    }
}

/** iOS Settings-style coloured icon tile, as a small glass drop. */
@Composable
fun IconTile(color: Color, content: @Composable () -> Unit) {
    GlassSurface(
        modifier = Modifier.size(30.dp),
        corner = 9.dp,
        tint = color,
        lens = false,
        elevation = 2.dp,
        backdrop = null,
    ) {
        content()
    }
}

@Composable
fun TileIcon(icon: ImageVector) {
    Icon(icon, null, Modifier.size(18.dp), tint = Color.White)
}

/** The 🔄 update icon: turns slowly all the time, spins fast while checking. */
@Composable
fun SpinningUpdateIcon(fast: Boolean) {
    val t = rememberInfiniteTransition(label = "spin")
    val angle by t.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (fast) 800 else 4800, easing = LinearEasing)),
        label = "spinAngle",
    )
    Icon(
        Sf.ArrowsCircle,
        null,
        Modifier
            .size(18.dp)
            .graphicsLayer { rotationZ = angle },
        tint = Color.White,
    )
}

@Composable
fun InfoGroup(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(GROUP_RADIUS.dp))
            .background(LocalIos.current.card),
        content = content,
    )
}

@Composable
fun InfoRow(
    tile: Color,
    title: String,
    value: String = "",
    valueColor: Color? = null,
    divider: Boolean = false,
    chevron: Boolean = false,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    icon: @Composable () -> Unit,
) {
    val ios = LocalIos.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    Column(
        Modifier
            .fillMaxWidth()
            .background(if (pressed && onClick != null) ios.pressed else Color.Transparent)
            .then(
                if (onClick != null) {
                    Modifier.clickable(interactionSource = src, indication = null, onClick = onClick)
                } else {
                    Modifier
                },
            ),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(52.dp)
                .padding(start = 14.dp, end = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconTile(tile) { icon() }
            Spacer(Modifier.width(14.dp))
            Text(
                title,
                style = TS.body,
                color = ios.label,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            if (value.isNotEmpty()) {
                Text(value, style = TS.body, color = valueColor ?: ios.secondaryLabel, maxLines = 1)
            }
            if (trailing != null) trailing()
            if (chevron) {
                Spacer(Modifier.width(8.dp))
                Icon(Sf.ChevronRight, null, Modifier.size(13.dp), tint = ios.tertiaryLabel)
            }
        }
        if (divider) Hairline(start = 58.dp)
    }
}

/** iOS 26 style switch: the thumb is a glass pill that stretches while you hold it. */
@Composable
fun GlassSwitch(checked: Boolean, onToggle: () -> Unit) {
    val ios = LocalIos.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val pos by animateFloatAsState(if (checked) 1f else 0f, spring(dampingRatio = 0.62f, stiffness = 480f), label = "switch")
    val grow by animateFloatAsState(if (pressed) 1f else 0f, spring(dampingRatio = 0.5f, stiffness = 600f), label = "switchGrow")
    Box(
        Modifier
            .size(width = 54.dp, height = 32.dp)
            .clip(CircleShape)
            .background(lerp(ios.fill, ios.green, pos.coerceIn(0f, 1f)))
            .clickable(interactionSource = src, indication = null, onClick = onToggle),
        contentAlignment = Alignment.CenterStart,
    ) {
        val thumbW = 28.dp + 10.dp * grow
        Box(
            Modifier
                .offset {
                    val travel = (54.dp - thumbW - 4.dp).toPx()
                    IntOffset((2.dp.toPx() + travel * pos).roundToInt(), 0)
                }
                .size(width = thumbW, height = 28.dp)
                .shadow(3.dp, CircleShape)
                .clip(CircleShape)
                .background(Color.White),
        )
    }
}

fun openUrl(context: Context, url: String) {
    val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(i) }
}
