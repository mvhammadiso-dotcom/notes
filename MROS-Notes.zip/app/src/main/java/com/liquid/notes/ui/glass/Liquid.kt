package com.liquid.notes.ui.glass

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/** Remembers where the finger last touched the screen (root coordinates) — the drop starts there. */
class TouchTracker {
    var last: Offset = Offset.Unspecified
}

fun Modifier.trackTouches(tracker: TouchTracker): Modifier = this.pointerInput(tracker) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        tracker.last = down.position
    }
}

/** A wobbly circle: the outline of a spreading drop of water. */
private fun dropPath(c: Offset, r: Float, p: Float): Path {
    val path = Path()
    val n = 84
    val wobble = (1f - p).coerceIn(0f, 1f)
    val amp = r * 0.09f * wobble
    val phase = p * 7.5f
    for (i in 0..n) {
        val a = (i.toFloat() / n) * 2f * PI.toFloat()
        val rr = r + amp * (sin(3f * a + phase) + 0.6f * sin(5f * a - phase * 1.4f) + 0.3f * sin(9f * a + phase * 2.2f))
        val x = c.x + cos(a) * rr
        val y = c.y + sin(a) * rr
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}

/**
 * Reveals the content as a drop of water spreading out from [origin].
 * progress 0 = nothing visible, 1 = fully open. The rim glints like a water meniscus while it moves.
 */
fun Modifier.liquidReveal(progress: () -> Float, origin: Offset, rim: Color): Modifier = this.drawWithContent {
    val p = progress()
    if (p >= 0.999f) {
        drawContent()
        return@drawWithContent
    }
    if (p <= 0.002f) return@drawWithContent
    val o = if (origin.isSpecified) origin else Offset(size.width / 2f, size.height / 2f)
    val far = max(
        max(hypot(o.x, o.y), hypot(size.width - o.x, o.y)),
        max(hypot(o.x, size.height - o.y), hypot(size.width - o.x, size.height - o.y)),
    ) * 1.12f
    val path = dropPath(o, far * p, p)
    clipPath(path) {
        this@drawWithContent.drawContent()
    }
    val fade = (1f - p).coerceIn(0f, 1f)
    drawPath(path, color = rim.copy(alpha = 0.45f * fade), style = Stroke(width = 6.dp.toPx()))
    drawPath(path, color = Color.White.copy(alpha = 0.85f * fade), style = Stroke(width = 1.6.dp.toPx()))
}

/** Geometry of a screen growing out of [from]: the current rect and its corner radius. */
private fun morphGeometry(
    from: Rect?,
    size: Size,
    x: Float,
    y: Float,
    minStart: Float,
    maxStartCorner: Float,
    endCorner: Float,
): Pair<Rect, Float> {
    val m = minStart
    var s = from ?: Rect(size.width / 2f - m / 2f, size.height * 0.88f - m / 2f, size.width / 2f + m / 2f, size.height * 0.88f + m / 2f)
    if (s.width < m || s.height < m) {
        val c = s.center
        val hw = max(s.width, m) / 2f
        val hh = max(s.height, m) / 2f
        s = Rect(c.x - hw, c.y - hh, c.x + hw, c.y + hh)
    }
    val gx = x.coerceIn(0f, 1.15f)
    val gy = y.coerceIn(0f, 1.15f)
    val r = Rect(
        left = s.left - s.left * gx,
        top = s.top - s.top * gy,
        right = s.right + (size.width - s.right) * gx,
        bottom = s.bottom + (size.height - s.bottom) * gy,
    )
    val p = minOf(x, y).coerceIn(0f, 1f)
    val startCorner = minOf(minOf(s.width, s.height) / 2f, maxStartCorner)
    return r to (startCorner * (1f - p) + endCorner * p)
}

/**
 * Clip shape for a screen growing out of a button/row. Used as a graphicsLayer outline, so the
 * GPU clips the already-recorded screen — nothing is redrawn while it animates.
 */
class MorphShape(
    private val from: Rect?,
    private val x: Float,
    private val y: Float,
    private val minStart: Float,
    private val maxStartCorner: Float,
    private val endCorner: Float,
) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val (r, c) = morphGeometry(from, size, x, y, minStart, maxStartCorner, endCorner)
        return Outline.Rounded(RoundRect(rect = r, cornerRadius = CornerRadius(c, c)))
    }
}

/** The glass veil + rim drawn on top of a morphing screen (a small, separate draw node). */
fun DrawScope.drawMorphVeil(
    from: Rect?,
    x: Float,
    y: Float,
    minStart: Float,
    maxStartCorner: Float,
    endCorner: Float,
    rim: Color,
) {
    if (x >= 0.999f && y >= 0.999f) return
    if (x <= 0.002f && y <= 0.002f) return
    val (r, c) = morphGeometry(from, size, x, y, minStart, maxStartCorner, endCorner)
    val fade = 1f - minOf(x, y).coerceIn(0f, 1f)
    if (fade < 0.01f) return
    val path = Path()
    path.addRoundRect(RoundRect(rect = r, cornerRadius = CornerRadius(c, c)))
    drawPath(path, color = rim.copy(alpha = 0.22f * fade))
    drawPath(
        path,
        brush = Brush.verticalGradient(
            colors = listOf(Color.White.copy(alpha = 0.5f * fade), Color.Transparent),
            startY = r.top,
            endY = r.top + r.height * 0.45f,
        ),
    )
    drawPath(path, color = rim.copy(alpha = 0.4f * fade), style = Stroke(width = 5.dp.toPx()))
    drawPath(path, color = Color.White.copy(alpha = 0.9f * fade), style = Stroke(width = 1.6.dp.toPx()))
}

/**
 * For overlays (alerts, sheets): grow out of the touch point.
 * [box] = the element's own untransformed bounds in root coordinates.
 */
fun GraphicsLayerScope.morphFrom(origin: Offset, box: Rect, px: Float, py: Float) {
    if (!origin.isSpecified || box.width <= 0f || box.height <= 0f) {
        scaleX = 0.6f + 0.4f * px
        scaleY = 0.6f + 0.4f * py
        return
    }
    val start = 44.dp.toPx()
    val sx0 = (start / box.width).coerceAtMost(1f)
    val sy0 = (start / box.height).coerceAtMost(1f)
    scaleX = sx0 + (1f - sx0) * px
    scaleY = sy0 + (1f - sy0) * py
    translationX = (origin.x - box.center.x) * (1f - px)
    translationY = (origin.y - box.center.y) * (1f - py)
}
