package com.liquid.notes.ui

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.isSpecified
import com.liquid.notes.data.ListTarget
import com.liquid.notes.data.NotesStore
import com.liquid.notes.ui.glass.TouchTracker
import com.liquid.notes.ui.overlay.OverlayState
import com.liquid.notes.ui.update.UpdateController

sealed interface Screen {
    val key: String

    data object Folders : Screen {
        override val key: String get() = "folders"
    }

    data class Notes(val target: ListTarget) : Screen {
        override val key: String get() = "notes:" + target.key
    }

    data class Editor(val noteId: String) : Screen {
        override val key: String get() = "editor:$noteId"
    }

    data object Info : Screen {
        override val key: String get() = "info"
    }
}

/** Minimal iOS-style navigation stack. */
@Stable
class Navigator(initial: List<Screen>, private val onRemoved: (Screen) -> Unit) {
    val stack = mutableStateListOf<Screen>().also { it.addAll(initial) }

    var lastWasPush by mutableStateOf(true)
        private set

    val current: Screen get() = stack[stack.size - 1]

    val canPop: Boolean get() = stack.size > 1

    /** Where the user touched last (root coordinates). */
    val touch = TouchTracker()
    private val origins = HashMap<String, Rect>()

    /** The rect (button, row, chip…) a screen grows out of and shrinks back into. */
    fun originOf(screen: Screen): Rect? = origins[screen.key]

    private fun originFor(from: Rect?): Rect? {
        if (from != null && from.width > 0f) return from
        val t = touch.last
        return if (t.isSpecified) Rect(t, t) else null
    }

    fun push(screen: Screen, from: Rect? = null) {
        if (current == screen) return
        val o = originFor(from)
        if (o != null) origins[screen.key] = o else origins.remove(screen.key)
        lastWasPush = true
        stack.add(screen)
    }

    fun pop(): Boolean {
        if (stack.size <= 1) return false
        lastWasPush = false
        val removed = stack.removeAt(stack.size - 1)
        onRemoved(removed)
        return true
    }

    fun replaceTop(screen: Screen, from: Rect? = null) {
        val o = originFor(from)
        if (o != null) origins[screen.key] = o else origins.remove(screen.key)
        lastWasPush = true
        val removed = stack.removeAt(stack.size - 1)
        stack.add(screen)
        onRemoved(removed)
    }
}

val LocalStore = staticCompositionLocalOf<NotesStore> { error("NotesStore not provided") }
val LocalNav = staticCompositionLocalOf<Navigator> { error("Navigator not provided") }
val LocalOverlay = staticCompositionLocalOf<OverlayState> { error("OverlayState not provided") }
val LocalUpdates = staticCompositionLocalOf<UpdateController> { error("UpdateController not provided") }
