package com.liquid.notes.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.liquid.notes.data.DEFAULT_FOLDER
import com.liquid.notes.data.ListTarget
import com.liquid.notes.data.Note
import com.liquid.notes.data.NoteText
import com.liquid.notes.data.SortMode
import com.liquid.notes.data.ViewMode
import com.liquid.notes.ui.LocalNav
import com.liquid.notes.ui.LocalOverlay
import com.liquid.notes.ui.LocalStore
import com.liquid.notes.ui.Screen
import com.liquid.notes.ui.components.BottomBar
import com.liquid.notes.ui.components.EmptyState
import com.liquid.notes.ui.components.GalleryCell
import com.liquid.notes.ui.components.LargeTitle
import com.liquid.notes.ui.components.NavBar
import com.liquid.notes.ui.components.NoteListRow
import com.liquid.notes.ui.components.SearchField
import com.liquid.notes.ui.components.SectionHeader
import com.liquid.notes.ui.components.posOf
import com.liquid.notes.ui.components.rememberNoteActions
import com.liquid.notes.ui.glass.BoundsHolder
import com.liquid.notes.ui.glass.GlassCircleButton
import com.liquid.notes.ui.glass.LocalBackdrop
import com.liquid.notes.ui.glass.ScrollEdge
import com.liquid.notes.ui.glass.backdropSource
import com.liquid.notes.ui.glass.rememberBackdrop
import com.liquid.notes.ui.icons.Sf
import com.liquid.notes.ui.overlay.AlertButton
import com.liquid.notes.ui.overlay.AlertRequest
import com.liquid.notes.ui.overlay.MenuAction
import com.liquid.notes.ui.overlay.MenuGroup
import com.liquid.notes.ui.overlay.MenuRequest
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.theme.TS
import com.liquid.notes.util.Dates
import com.liquid.notes.util.Strings

private class NoteSection(val key: String, val title: String?, val notes: List<Note>)

private fun buildSections(notes: List<Note>, sort: SortMode, deletedMode: Boolean, s: Strings): List<NoteSection> {
    val out = mutableListOf<NoteSection>()
    val pinned = if (deletedMode) emptyList() else notes.filter { it.pinned }
    val rest = if (deletedMode) notes else notes.filter { !it.pinned }
    if (pinned.isNotEmpty()) out += NoteSection("pinned", s.pinned, pinned)
    if (rest.isEmpty()) return out
    if (sort == SortMode.Title) {
        out += NoteSection("all", if (pinned.isEmpty()) null else s.notes, rest)
        return out
    }
    val groups = LinkedHashMap<String, Pair<String, MutableList<Note>>>()
    rest.forEach { n ->
        val ts = if (sort == SortMode.Created) n.createdAt else n.modifiedAt
        val (key, title) = Dates.section(ts, s)
        groups.getOrPut(key) { title to mutableListOf() }.second.add(n)
    }
    groups.forEach { (key, value) -> out += NoteSection(key, value.first, value.second) }
    return out
}

@Composable
fun NotesListScreen(target: ListTarget) {
    val store = LocalStore.current
    val data by store.data.collectAsState()
    val s = com.liquid.notes.util.LocalStrings.current
    val ios = LocalIos.current
    val nav = LocalNav.current
    val overlay = LocalOverlay.current
    val actions = rememberNoteActions()
    val backdrop = rememberBackdrop()
    val gridState = rememberLazyGridState()
    val openRow = remember { mutableStateOf<Any?>(null) }
    val collapsedSections = remember { mutableStateListOf<String>() }
    val menuBounds = remember { BoundsHolder() }
    var query by rememberSaveable { mutableStateOf("") }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val collapsed by remember {
        derivedStateOf { gridState.firstVisibleItemIndex > 0 || gridState.firstVisibleItemScrollOffset > 70 }
    }

    val deletedMode = target == ListTarget.Deleted
    val title = when (target) {
        ListTarget.All -> s.allNotes
        ListTarget.Deleted -> s.recentlyDeleted
        is ListTarget.InFolder ->
            if (target.id == DEFAULT_FOLDER) s.notes else data.folders.find { it.id == target.id }?.name ?: s.notes
        is ListTarget.Tag -> "#" + target.name
    }
    val base = remember(data, target) {
        data.notes.filter { n ->
            val inTarget = when (target) {
                ListTarget.All -> n.deletedAt == null
                ListTarget.Deleted -> n.deletedAt != null
                is ListTarget.InFolder -> n.deletedAt == null && n.folderId == target.id
                is ListTarget.Tag -> n.deletedAt == null && NoteText.hasTag(n.content, target.name)
            }
            inTarget && !NoteText.isBlank(n.content)
        }
    }
    val q = query.trim()
    val sort = data.sort
    val gallery = data.view == ViewMode.Gallery
    val sections = remember(base, q, sort, deletedMode, s) {
        val filtered = if (q.isEmpty()) base else base.filter { it.content.contains(q, ignoreCase = true) }
        val sorted = when {
            deletedMode -> filtered.sortedByDescending { it.deletedAt ?: 0L }
            sort == SortMode.Created -> filtered.sortedByDescending { it.createdAt }
            sort == SortMode.Title -> filtered.sortedBy { (NoteText.title(it.content) ?: "").lowercase() }
            else -> filtered.sortedByDescending { it.modifiedAt }
        }
        buildSections(sorted, if (deletedMode) SortMode.Edited else sort, deletedMode, s)
    }

    fun moreMenu() {
        val groups = if (deletedMode) {
            listOf(
                MenuGroup(
                    null,
                    listOf(
                        MenuAction(s.deleteAll, Sf.Trash, destructive = true, enabled = base.isNotEmpty()) {
                            overlay.alert = AlertRequest(
                                title = s.deleteAll,
                                message = s.deleteAllMsg,
                                buttons = listOf(
                                    AlertButton(s.cancel) { },
                                    AlertButton(s.delete, destructive = true) { store.deleteAllDeleted() },
                                ),
                            )
                        },
                    ),
                ),
            )
        } else {
            listOf(
                MenuGroup(
                    null,
                    listOf(
                        MenuAction(if (gallery) s.viewAsList else s.viewAsGallery, if (gallery) Sf.ListBullet else Sf.Grid) {
                            store.setView(if (gallery) ViewMode.Rows else ViewMode.Gallery)
                        },
                    ),
                ),
                MenuGroup(
                    s.sortBy,
                    listOf(
                        MenuAction(s.dateEdited, checked = sort == SortMode.Edited) { store.setSort(SortMode.Edited) },
                        MenuAction(s.dateCreated, checked = sort == SortMode.Created) { store.setSort(SortMode.Created) },
                        MenuAction(s.title, checked = sort == SortMode.Title) { store.setSort(SortMode.Title) },
                    ),
                ),
            )
        }
        overlay.menu = MenuRequest(anchor = menuBounds.rect, groups = groups, alignEnd = true)
    }

    Box(Modifier.fillMaxSize()) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(if (gallery) 2 else 1),
            state = gridState,
            modifier = Modifier
                .fillMaxSize()
                .backdropSource(backdrop)
                .background(ios.background),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = top + 56.dp, bottom = bottom + 110.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            val full: (androidx.compose.foundation.lazy.grid.LazyGridItemSpanScope.() -> GridItemSpan) = { GridItemSpan(maxLineSpan) }
            item(key = "title", span = full) { LargeTitle(title) }
            item(key = "search", span = full) { SearchField(query, { query = it }) }
            if (deletedMode && base.isNotEmpty() && q.isEmpty()) {
                item(key = "info", span = full) {
                    Text(
                        s.deletedInfo,
                        style = TS.footnote,
                        color = ios.secondaryLabel,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp),
                    )
                }
            }
            if (sections.isEmpty()) {
                item(key = "empty", span = full) { EmptyState(if (q.isEmpty()) s.noNotes else s.noResults) }
            }
            sections.forEach { sec ->
                val isCollapsed = sec.key in collapsedSections
                val secTitle = sec.title
                if (secTitle != null) {
                    item(key = "h_" + sec.key, span = full) {
                        SectionHeader(secTitle, collapsed = isCollapsed, onToggle = {
                            if (isCollapsed) collapsedSections.remove(sec.key) else collapsedSections.add(sec.key)
                        })
                    }
                } else {
                    item(key = "h_" + sec.key, span = full) { Spacer(Modifier.height(14.dp)) }
                }
                if (!isCollapsed) {
                    if (gallery) {
                        items(sec.notes, key = { it.id }) { n ->
                            GalleryCell(n, actions, deletedMode, Modifier.animateItem())
                        }
                    } else {
                        itemsIndexed(sec.notes, key = { _, n -> n.id }) { i, n ->
                            NoteListRow(
                                note = n,
                                pos = posOf(i, sec.notes.size),
                                openId = openRow,
                                actions = actions,
                                deletedMode = deletedMode,
                                showFolder = target == ListTarget.All || target is ListTarget.Tag,
                                modifier = Modifier.animateItem(),
                            )
                        }
                    }
                }
            }
        }

        CompositionLocalProvider(LocalBackdrop provides backdrop) {
            ScrollEdge(top = true, height = top + 66.dp, color = ios.background, modifier = Modifier.align(Alignment.TopCenter))
            ScrollEdge(top = false, height = bottom + 86.dp, color = ios.background, modifier = Modifier.align(Alignment.BottomCenter))
            NavBar(
                title = title,
                showTitle = collapsed,
                left = { GlassCircleButton(Sf.ChevronLeft, onClick = { nav.pop() }) },
                right = { GlassCircleButton(Sf.Ellipsis, onClick = { moreMenu() }, bounds = menuBounds) },
            )
            BottomBar(
                modifier = Modifier.align(Alignment.BottomCenter),
                center = {
                    Text(
                        s.notesCount(base.size),
                        style = TS.caption.copy(fontWeight = FontWeight.Medium),
                        color = ios.label,
                    )
                },
                right = {
                    if (!deletedMode) {
                        GlassCircleButton(Sf.Compose, onClick = {
                            val folder = if (target is ListTarget.InFolder) target.id else DEFAULT_FOLDER
                            val id = store.createNote(folder)
                            nav.push(Screen.Editor(id))
                        }, iconSize = 22.dp)
                    }
                },
            )
        }
    }
}
