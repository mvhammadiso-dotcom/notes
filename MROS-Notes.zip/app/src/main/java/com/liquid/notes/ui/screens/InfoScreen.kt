package com.liquid.notes.ui.screens

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.liquid.notes.ui.LocalNav
import com.liquid.notes.ui.LocalOverlay
import com.liquid.notes.ui.LocalUpdates
import com.liquid.notes.ui.components.AppIcon
import com.liquid.notes.ui.components.GlassSwitch
import com.liquid.notes.ui.components.InfoGroup
import com.liquid.notes.ui.components.InfoRow
import com.liquid.notes.ui.components.LargeTitle
import com.liquid.notes.ui.components.NavBar
import com.liquid.notes.ui.components.SectionHeader
import com.liquid.notes.ui.components.SpinningUpdateIcon
import com.liquid.notes.ui.components.TileIcon
import com.liquid.notes.ui.components.openUrl
import com.liquid.notes.ui.glass.GlassCircleButton
import com.liquid.notes.ui.glass.LocalBackdrop
import com.liquid.notes.ui.glass.ScrollEdge
import com.liquid.notes.ui.glass.backdropSource
import com.liquid.notes.ui.glass.rememberBackdrop
import com.liquid.notes.ui.icons.Sf
import com.liquid.notes.ui.overlay.AlertButton
import com.liquid.notes.ui.overlay.AlertRequest
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.theme.TS
import com.liquid.notes.util.LocalStrings
import com.liquid.notes.widget.NotesWidgets
import com.liquid.notes.widget.WidgetPrefs

const val TELEGRAM_CHANNEL = "https://t.me/mrosapp"
const val CREATOR_NAME = "mvhammadiso"
const val CREATOR_TELEGRAM = "https://t.me/mvhammadiso"

/** Info / About: updates, Telegram, widget blur, version and creator. */
@Composable
fun InfoScreen() {
    val s = LocalStrings.current
    val ios = LocalIos.current
    val nav = LocalNav.current
    val overlay = LocalOverlay.current
    val updates = LocalUpdates.current
    val context = LocalContext.current
    val backdrop = rememberBackdrop()
    val listState = rememberLazyListState()
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val collapsed by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 70 }
    }
    var blurOn by remember { mutableStateOf(WidgetPrefs.blurActive(context)) }

    // re-read the permission when coming back from Settings
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) blurOn = WidgetPrefs.blurActive(context)
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    fun refreshWidgets() {
        val app = context.applicationContext
        Thread { NotesWidgets.refresh(app) }.start()
    }

    fun toggleBlur() {
        when {
            Build.VERSION.SDK_INT < 30 -> overlay.message(s.widgetBlur, s.notSupported, s.ok)
            blurOn -> {
                WidgetPrefs.setBlur(context, false)
                blurOn = false
                refreshWidgets()
            }
            WidgetPrefs.hasWallpaperAccess() -> {
                WidgetPrefs.setBlur(context, true)
                blurOn = true
                refreshWidgets()
            }
            else -> overlay.alert = AlertRequest(
                title = s.widgetBlur,
                message = s.widgetBlurMsg,
                buttons = listOf(
                    AlertButton(s.cancel) { },
                    AlertButton(s.continueLabel, bold = true) {
                        WidgetPrefs.setBlur(context, true)
                        WidgetPrefs.openAccessSettings(context)
                    },
                ),
            )
        }
    }

    val available = updates.available
    val updateValue = when {
        updates.checking -> s.checking
        available != null -> s.updateReady(available.versionName)
        else -> ""
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .backdropSource(backdrop)
                .background(ios.background),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = top + 56.dp, bottom = bottom + 40.dp),
        ) {
            item(key = "title") { LargeTitle(s.info) }
            item(key = "hero") {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    AppIcon(88.dp)
                    Spacer(Modifier.height(14.dp))
                    Text("MROS Notes", style = TS.title2, color = ios.label)
                    Text(s.currentVersion(updates.versionName), style = TS.subhead, color = ios.secondaryLabel)
                }
            }

            item(key = "h_updates") { SectionHeader(s.updatesSection) }
            item(key = "updates") {
                InfoGroup {
                    InfoRow(
                        tile = ios.green,
                        title = s.checkUpdates,
                        value = updateValue,
                        valueColor = if (available != null && !updates.checking) ios.accent else null,
                        divider = true,
                        onClick = { updates.check(silent = false) },
                    ) { SpinningUpdateIcon(fast = updates.checking) }
                    InfoRow(
                        tile = ios.blue,
                        title = s.telegramChannel,
                        value = "@mrosapp",
                        divider = true,
                        chevron = true,
                        onClick = { openUrl(context, TELEGRAM_CHANNEL) },
                    ) { TileIcon(Sf.Paperplane) }
                    InfoRow(
                        tile = ios.orange,
                        title = s.whatsNewTitle,
                        chevron = true,
                        onClick = { overlay.whatsNew = true },
                    ) { TileIcon(Sf.Sparkles) }
                }
            }

            item(key = "h_widgets") { SectionHeader(s.widgetsSection) }
            item(key = "widgets") {
                InfoGroup {
                    InfoRow(
                        tile = ios.purple,
                        title = s.widgetBlur,
                        onClick = { toggleBlur() },
                        trailing = { GlassSwitch(checked = blurOn, onToggle = { toggleBlur() }) },
                    ) { TileIcon(Sf.Grid) }
                }
            }
            item(key = "widgets_note") {
                Text(
                    s.widgetBlurFootnote,
                    style = TS.footnote,
                    color = ios.secondaryLabel,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp),
                )
            }

            item(key = "h_info") { SectionHeader("Info") }
            item(key = "info") {
                InfoGroup {
                    InfoRow(tile = ios.accent, title = s.appLabel, value = "MROS Notes", divider = true) {
                        TileIcon(Sf.Compose)
                    }
                    InfoRow(tile = ios.gray, title = s.versionLabel, value = updates.versionName, divider = true) {
                        TileIcon(Sf.Info)
                    }
                    InfoRow(tile = ios.teal, title = s.creatorLabel, value = CREATOR_NAME, divider = true) {
                        TileIcon(Sf.Person)
                    }
                    InfoRow(
                        tile = ios.blue,
                        title = s.creatorTelegram,
                        value = "@$CREATOR_NAME",
                        chevron = true,
                        onClick = { openUrl(context, CREATOR_TELEGRAM) },
                    ) { TileIcon(Sf.Paperplane) }
                }
            }
            item(key = "footer") {
                Text(
                    "MROS Notes · $CREATOR_NAME",
                    style = TS.caption,
                    color = ios.tertiaryLabel,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 24.dp),
                )
            }
        }

        CompositionLocalProvider(LocalBackdrop provides backdrop) {
            ScrollEdge(top = true, height = top + 66.dp, color = ios.background, modifier = Modifier.align(Alignment.TopCenter))
            NavBar(
                title = s.info,
                showTitle = collapsed,
                left = { GlassCircleButton(Sf.ChevronLeft, onClick = { nav.pop() }) },
            )
        }
    }
}
