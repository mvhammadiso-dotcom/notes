package com.liquid.notes.ui.screens

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.ui.draw.clip
import androidx.core.content.ContextCompat
import com.liquid.notes.notify.Reminders
import com.liquid.notes.ui.overlay.SheetItem
import com.liquid.notes.ui.overlay.SheetRequest
import java.util.Calendar
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.liquid.notes.data.NoteText
import com.liquid.notes.ui.LocalNav
import com.liquid.notes.ui.LocalOverlay
import com.liquid.notes.ui.LocalStore
import com.liquid.notes.ui.Screen
import com.liquid.notes.ui.components.BottomBar
import com.liquid.notes.ui.components.NavBar
import com.liquid.notes.ui.components.rememberNoteActions
import com.liquid.notes.ui.components.shareText
import com.liquid.notes.ui.glass.BoundsHolder
import com.liquid.notes.ui.glass.GlassCircleButton
import com.liquid.notes.ui.glass.GlassPill
import com.liquid.notes.ui.glass.LocalBackdrop
import com.liquid.notes.ui.glass.PillButton
import com.liquid.notes.ui.glass.PillTextButton
import com.liquid.notes.ui.glass.ScrollEdge
import com.liquid.notes.ui.glass.backdropSource
import com.liquid.notes.ui.glass.rememberBackdrop
import com.liquid.notes.ui.icons.Sf
import com.liquid.notes.ui.overlay.MenuAction
import com.liquid.notes.ui.overlay.MenuGroup
import com.liquid.notes.ui.overlay.MenuRequest
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.theme.TS
import com.liquid.notes.util.Dates
import com.liquid.notes.util.LocalStrings
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest

@Composable
fun EditorScreen(noteId: String) {
    val store = LocalStore.current
    val data by store.data.collectAsState()
    val note = data.notes.find { it.id == noteId }
    val ios = LocalIos.current
    val s = LocalStrings.current
    val nav = LocalNav.current
    val overlay = LocalOverlay.current
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val actions = rememberNoteActions()
    val backdrop = rememberBackdrop()
    val editor = remember(noteId) { EditorState(note?.content ?: "") }
    val scroll = rememberScrollState()
    val menuBounds = remember { BoundsHolder() }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    val formatBounds = remember { BoundsHolder() }
    val composeBounds = remember { BoundsHolder() }

    // Autosave every edit (the store debounces disk writes).
    LaunchedEffect(editor) {
        snapshotFlow { editor.serialize() }.collect { text -> store.setContent(noteId, text) }
    }
    // Group typing into undo steps.
    LaunchedEffect(editor) {
        snapshotFlow { editor.serialize() }.collectLatest { text ->
            delay(650)
            editor.commit(text)
        }
    }
    // A new, empty note opens with the keyboard, like iOS.
    LaunchedEffect(editor) {
        if (NoteText.isBlank(editor.serialize())) {
            // wait until the screen has finished growing — opening the keyboard mid-animation stutters
            delay(650)
            editor.focusStart()
        }
    }

    if (note == null) {
        Box(Modifier.fillMaxSize().background(ios.editorBackground))
        return
    }

    fun done() {
        focusManager.clearFocus()
        keyboard?.hide()
    }

    fun back() {
        done()
        nav.pop()
    }

    fun share() = shareText(context, NoteText.plain(editor.serialize()))

    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) overlay.message(s.remindMe, s.notifPermissionMsg, s.ok)
    }

    fun setReminder(at: Long?) {
        Reminders.set(context, noteId, at)
        if (at != null && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun pickDateTime() {
        val start = Calendar.getInstance()
        start.add(Calendar.HOUR_OF_DAY, 1)
        DatePickerDialog(
            context,
            { _, y, m, d ->
                TimePickerDialog(
                    context,
                    { _, h, min ->
                        val c = Calendar.getInstance()
                        c.set(y, m, d, h, min, 0)
                        c.set(Calendar.MILLISECOND, 0)
                        if (c.timeInMillis > System.currentTimeMillis()) setReminder(c.timeInMillis)
                    },
                    start.get(Calendar.HOUR_OF_DAY),
                    0,
                    Dates.is24h,
                ).show()
            },
            start.get(Calendar.YEAR),
            start.get(Calendar.MONTH),
            start.get(Calendar.DAY_OF_MONTH),
        ).show()
    }

    fun reminderSheet() {
        fun at(daysAhead: Int, hour: Int): Long {
            val c = Calendar.getInstance()
            c.add(Calendar.DAY_OF_YEAR, daysAhead)
            c.set(Calendar.HOUR_OF_DAY, hour)
            c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            return c.timeInMillis
        }
        val now = System.currentTimeMillis()
        val evening = at(0, 20)
        val hasReminder = store.data.value.notes.find { it.id == noteId }?.remindAt != null
        val items = buildList {
            add(SheetItem(s.inOneHour, Sf.Bell, false) { setReminder(now + 60 * 60 * 1000L) })
            if (evening > now + 10 * 60 * 1000L) {
                add(SheetItem(s.thisEvening, Sf.Moon, false) { setReminder(evening) })
            } else {
                add(SheetItem(s.tomorrowEvening, Sf.Moon, false) { setReminder(at(1, 20)) })
            }
            add(SheetItem(s.tomorrowMorning, Sf.Sun, false) { setReminder(at(1, 9)) })
            add(SheetItem(s.pickDateTime, Sf.Calendar, false) { pickDateTime() })
            if (hasReminder) add(SheetItem(s.removeReminder, Sf.Trash, false) { setReminder(null) })
        }
        overlay.sheet = SheetRequest(s.remindMe, items)
    }

    fun menu() {
        val current = store.data.value.notes.find { it.id == noteId } ?: return
        val (words, chars) = editor.stats()
        overlay.menu = MenuRequest(
            anchor = menuBounds.rect,
            alignEnd = true,
            groups = listOf(
                MenuGroup(
                    null,
                    listOf(
                        MenuAction(
                            if (current.pinned) s.unpinNote else s.pinNote,
                            if (current.pinned) Sf.PinSlash else Sf.Pin,
                        ) { store.togglePin(noteId) },
                        MenuAction(s.move, Sf.Folder) { actions.move(current) },
                        MenuAction(s.share, Sf.Share) { share() },
                        MenuAction(s.remindMe, Sf.Bell) { reminderSheet() },
                        MenuAction(s.duplicate, Sf.Duplicate) {
                            done()
                            val copy = store.duplicateNote(noteId)
                            if (copy != null) nav.replaceTop(Screen.Editor(copy))
                        },
                    ),
                ),
                MenuGroup(
                    null,
                    listOf(
                        MenuAction(s.delete, Sf.Trash, destructive = true) {
                            done()
                            nav.pop()
                            store.deleteNote(noteId)
                        },
                    ),
                ),
                MenuGroup(null, listOf(MenuAction(s.wordsChars(words, chars), Sf.Info, enabled = false) { })),
            ),
        )
    }

    fun formatMenu() {
        overlay.menu = MenuRequest(
            anchor = formatBounds.rect,
            alignEnd = false,
            groups = listOf(
                MenuGroup(
                    s.format,
                    listOf(
                        MenuAction(s.bulletedList, Sf.ListBullet) { editor.toggleList(bullet = true) },
                        MenuAction(s.numberedList, Sf.ListNumber) { editor.toggleList(bullet = false) },
                        MenuAction(s.checklist, Sf.Checklist) { editor.toggleChecklist() },
                    ),
                ),
                MenuGroup(
                    null,
                    listOf(
                        MenuAction(s.moveCheckedDown, Sf.Sort) { editor.moveCheckedToBottom() },
                        MenuAction(s.uncheckAll, Sf.Restore) { editor.uncheckAll() },
                        MenuAction(s.deleteChecked, Sf.Trash, destructive = true) { editor.deleteChecked() },
                    ),
                ),
            ),
        )
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .backdropSource(backdrop)
                .background(ios.editorBackground)
                .imePadding()
                .verticalScroll(scroll)
                .padding(top = top + 58.dp, bottom = 130.dp),
        ) {
            Text(
                Dates.editorHeader(note.modifiedAt, s),
                style = TS.footnote,
                color = ios.secondaryLabel,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
            )
            val remindAt = note.remindAt
            if (remindAt != null && remindAt > System.currentTimeMillis()) {
                Box(Modifier.fillMaxWidth().padding(bottom = 12.dp), contentAlignment = Alignment.Center) {
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(ios.fill)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                            ) { reminderSheet() }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Sf.Bell, null, Modifier.size(14.dp), tint = ios.accent)
                        Spacer(Modifier.width(6.dp))
                        Text(s.reminderAt(Dates.reminder(remindAt, s)), style = TS.footnote, color = ios.accent)
                    }
                }
            }
            BlockEditor(editor, Modifier.padding(horizontal = 20.dp))
            Spacer(
                Modifier
                    .fillMaxWidth()
                    .height(320.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { editor.focusEnd() },
            )
        }

        CompositionLocalProvider(LocalBackdrop provides backdrop) {
            ScrollEdge(top = true, height = top + 66.dp, color = ios.editorBackground, modifier = Modifier.align(Alignment.TopCenter))
            NavBar(
                title = null,
                showTitle = false,
                left = { GlassCircleButton(Sf.ChevronLeft, onClick = { back() }) },
                right = {
                    GlassPill {
                        if (editor.isEditing) {
                            PillButton(Sf.Undo, onClick = { editor.undo() }, enabled = editor.canUndo)
                            PillButton(Sf.Redo, onClick = { editor.redo() }, enabled = editor.canRedo)
                        } else {
                            PillButton(Sf.Share, onClick = { share() })
                        }
                        PillButton(Sf.Ellipsis, onClick = { menu() }, bounds = menuBounds)
                    }
                    AnimatedVisibility(
                        visible = editor.isEditing,
                        enter = scaleIn(initialScale = 0.6f) + fadeIn(),
                        exit = scaleOut(targetScale = 0.6f) + fadeOut(),
                    ) {
                        GlassCircleButton(Sf.Checkmark, onClick = { done() }, prominent = true, iconSize = 20.dp)
                    }
                },
            )
            BottomBar(
                modifier = Modifier.align(Alignment.BottomCenter),
                insets = WindowInsets.ime.union(WindowInsets.navigationBars),
                left = {
                    GlassPill {
                        PillTextButton("Aa", onClick = { formatMenu() }, bounds = formatBounds)
                        PillButton(Sf.Checklist, onClick = { editor.toggleChecklist() }, iconSize = 22.dp)
                    }
                },
                right = {
                    GlassCircleButton(Sf.Compose, onClick = {
                        done()
                        val id = store.createNote(note.folderId)
                        nav.replaceTop(Screen.Editor(id), from = composeBounds.rect)
                    }, iconSize = 22.dp, bounds = composeBounds)
                },
            )
        }
    }
}
