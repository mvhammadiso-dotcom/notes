package com.liquid.notes.ui.components

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.liquid.notes.data.Note
import com.liquid.notes.data.NoteText
import com.liquid.notes.ui.icons.Sf
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.theme.TS
import com.liquid.notes.util.LocalStrings

enum class GroupPos { Single, First, Middle, Last }

fun posOf(index: Int, count: Int): GroupPos = when {
    count <= 1 -> GroupPos.Single
    index == 0 -> GroupPos.First
    index == count - 1 -> GroupPos.Last
    else -> GroupPos.Middle
}

val GroupPos.hasDivider: Boolean get() = this == GroupPos.First || this == GroupPos.Middle

const val GROUP_RADIUS = 24

fun groupShape(pos: GroupPos, r: Dp = GROUP_RADIUS.dp): Shape = when (pos) {
    GroupPos.Single -> RoundedCornerShape(r)
    GroupPos.First -> RoundedCornerShape(topStart = r, topEnd = r)
    GroupPos.Last -> RoundedCornerShape(bottomStart = r, bottomEnd = r)
    GroupPos.Middle -> RectangleShape
}

@Composable
fun Modifier.noRippleClick(enabled: Boolean = true, onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        enabled = enabled,
        onClick = onClick,
    )

@Composable
fun Hairline(start: Dp = 0.dp) {
    Box(
        Modifier
            .padding(start = start)
            .fillMaxWidth()
            .height(0.6.dp)
            .background(LocalIos.current.separator),
    )
}

@Composable
fun LargeTitle(text: String) {
    Text(
        text = text,
        style = TS.largeTitle,
        color = LocalIos.current.label,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.padding(start = 4.dp, top = 2.dp, bottom = 8.dp),
    )
}

@Composable
fun SectionHeader(text: String, collapsed: Boolean = false, onToggle: (() -> Unit)? = null) {
    val ios = LocalIos.current
    val rotation by animateFloatAsState(if (collapsed) -90f else 0f, label = "sectionChevron")
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 4.dp, end = 6.dp, top = 22.dp, bottom = 8.dp)
            .then(if (onToggle != null) Modifier.noRippleClick(onClick = onToggle) else Modifier),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, style = TS.title3, color = ios.label, modifier = Modifier.weight(1f), maxLines = 1)
        if (onToggle != null) {
            Icon(
                Sf.ChevronDown,
                contentDescription = null,
                modifier = Modifier.size(15.dp).graphicsLayer { rotationZ = rotation },
                tint = ios.accent,
            )
        }
    }
}

@Composable
fun EmptyState(text: String) {
    val ios = LocalIos.current
    Box(Modifier.fillMaxWidth().padding(top = 120.dp), contentAlignment = Alignment.Center) {
        Text(text, style = TS.title3.copy(fontSize = TS.headline.fontSize), color = ios.secondaryLabel)
    }
}

/** iOS search field (capsule, magnifier, mic / clear, Cancel). */
@Composable
fun SearchField(value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val ios = LocalIos.current
    val s = LocalStrings.current
    val focusManager = LocalFocusManager.current
    var focused by remember { mutableStateOf(false) }
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!t.isNullOrBlank()) onValueChange(t)
        }
    }
    Row(
        modifier
            .fillMaxWidth()
            .padding(top = 2.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(
            Modifier
                .weight(1f)
                .height(40.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(ios.fill)
                .padding(start = 11.dp, end = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Sf.Search, null, Modifier.size(17.dp), tint = ios.secondaryLabel)
            Spacer(Modifier.width(7.dp))
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = TS.body.copy(color = ios.label),
                cursorBrush = SolidColor(ios.accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                modifier = Modifier
                    .weight(1f)
                    .onFocusChanged { focused = it.isFocused },
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (value.isEmpty()) Text(s.search, style = TS.body, color = ios.secondaryLabel, maxLines = 1)
                        inner()
                    }
                },
            )
            if (value.isNotEmpty()) {
                Box(
                    Modifier
                        .size(19.dp)
                        .clip(CircleShape)
                        .background(ios.secondaryLabel.copy(alpha = 0.55f))
                        .noRippleClick { onValueChange("") },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Sf.XMark, null, Modifier.size(9.dp), tint = ios.card)
                }
            } else {
                Icon(
                    Sf.Mic,
                    null,
                    Modifier
                        .size(19.dp)
                        .noRippleClick {
                            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            try {
                                speech.launch(i)
                            } catch (e: ActivityNotFoundException) {
                                // no speech recogniser on this phone
                            }
                        },
                    tint = ios.secondaryLabel,
                )
            }
        }
        AnimatedVisibility(visible = focused || value.isNotEmpty()) {
            Text(
                s.cancel,
                style = TS.body,
                color = ios.accent,
                maxLines = 1,
                modifier = Modifier
                    .padding(start = 12.dp, end = 2.dp)
                    .noRippleClick {
                        onValueChange("")
                        focusManager.clearFocus()
                    },
            )
        }
    }
}

/** Top navigation bar: glass buttons left/right, small title fading in on scroll. */
@Composable
fun NavBar(
    title: String?,
    showTitle: Boolean,
    left: @Composable () -> Unit = {},
    right: @Composable RowScope.() -> Unit = {},
) {
    val ios = LocalIos.current
    val a by animateFloatAsState(if (showTitle) 1f else 0f, label = "navTitle")
    Box(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(56.dp)
            .padding(horizontal = 16.dp),
    ) {
        Box(Modifier.align(Alignment.CenterStart)) { left() }
        if (title != null) {
            Text(
                title,
                style = TS.headline,
                color = ios.label,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 96.dp)
                    .graphicsLayer { alpha = a },
            )
        }
        Row(
            Modifier.align(Alignment.CenterEnd),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            content = right,
        )
    }
}

/** Bottom toolbar holding floating glass controls. */
@Composable
fun BottomBar(
    modifier: Modifier = Modifier,
    insets: WindowInsets = WindowInsets.navigationBars,
    left: @Composable () -> Unit = {},
    center: @Composable () -> Unit = {},
    right: @Composable () -> Unit = {},
) {
    Box(
        modifier
            .fillMaxWidth()
            .windowInsetsPadding(insets)
            .padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 10.dp)
            .height(52.dp),
    ) {
        Box(Modifier.align(Alignment.CenterStart)) { left() }
        Box(Modifier.align(Alignment.Center)) { center() }
        Box(Modifier.align(Alignment.CenterEnd)) { right() }
    }
}

/** The lifted card shown above a context menu (like iOS peek). */
@Composable
fun NotePreviewCard(note: Note, width: Dp) {
    val ios = LocalIos.current
    val s = LocalStrings.current
    Column(
        Modifier
            .width(width)
            .heightIn(max = 300.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(ios.card)
            .padding(horizontal = 20.dp, vertical = 18.dp),
    ) {
        Text(
            NoteText.title(note.content) ?: s.newNote,
            style = TS.title2,
            color = ios.label,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        val body = NoteText.body(note.content)
        if (body.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(body, style = TS.subhead, color = ios.label, maxLines = 10, overflow = TextOverflow.Ellipsis)
        }
    }
}

fun shareText(context: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    runCatching { context.startActivity(Intent.createChooser(send, null)) }
}
