package com.liquid.notes.util

import android.icu.text.SimpleDateFormat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import java.util.Date
import java.util.Locale

object Dates {
    /** Set from the activity (system 12/24-hour setting). */
    @Volatile
    var is24h: Boolean = true

    private fun locale(s: Strings): Locale = when (s.lang) {
        "uz" -> Locale.forLanguageTag("uz")
        "ru" -> Locale.forLanguageTag("ru")
        else -> Locale.getDefault()
    }

    private fun fmt(pattern: String, s: Strings, ts: Long): String =
        SimpleDateFormat(pattern, locale(s)).format(Date(ts))

    private fun cap(text: String, s: Strings): String =
        text.replaceFirstChar { if (it.isLowerCase()) it.titlecase(locale(s)) else it.toString() }

    fun daysAgo(ts: Long): Long {
        val zone = ZoneId.systemDefault()
        val d = Instant.ofEpochMilli(ts).atZone(zone).toLocalDate()
        return ChronoUnit.DAYS.between(d, LocalDate.now(zone))
    }

    private fun time(ts: Long, s: Strings): String = fmt(if (is24h) "HH:mm" else "h:mm a", s, ts)

    /** The short date shown in a note row: time, "Yesterday", weekday or a date. */
    fun rowDate(ts: Long, s: Strings): String {
        val days = daysAgo(ts)
        return when {
            days <= 0L -> time(ts, s)
            days == 1L -> s.yesterday
            days < 7L -> cap(fmt("cccc", s, ts), s)
            s.lang == "en" -> fmt("M/d/yy", s, ts)
            else -> fmt("dd.MM.yyyy", s, ts)
        }
    }

    /** Section grouping for note lists, like iOS: Today, Yesterday, Previous 7/30 Days, months, years. */
    fun section(ts: Long, s: Strings): Pair<String, String> {
        val days = daysAgo(ts)
        val zone = ZoneId.systemDefault()
        val date = Instant.ofEpochMilli(ts).atZone(zone).toLocalDate()
        val today = LocalDate.now(zone)
        return when {
            days <= 0L -> "today" to s.today
            days == 1L -> "yesterday" to s.yesterday
            days < 7L -> "p7" to s.prev7
            days < 30L -> "p30" to s.prev30
            date.year == today.year -> "m${date.monthValue}" to cap(fmt("LLLL", s, ts), s)
            else -> "y${date.year}" to date.year.toString()
        }
    }

    /** "Today, 20:00" / "Tomorrow, 09:00" / "18.11, 14:30" for reminders. */
    fun reminder(ts: Long, s: Strings): String {
        val zone = ZoneId.systemDefault()
        val d = Instant.ofEpochMilli(ts).atZone(zone).toLocalDate()
        val today = LocalDate.now(zone)
        val time = time(ts, s)
        return when (ChronoUnit.DAYS.between(today, d)) {
            0L -> s.today + ", " + time
            1L -> s.tomorrow + ", " + time
            else -> fmt(if (s.lang == "en") "MMM d" else "dd.MM", s, ts) + ", " + time
        }
    }

    /** "16 November 2026 at 03:07" header at the top of the editor. */
    fun editorHeader(ts: Long, s: Strings): String {
        val t = if (is24h) "HH:mm" else "h:mm a"
        val pattern = when (s.lang) {
            "uz" -> "d-MMMM, yyyy, $t"
            "ru" -> "d MMMM yyyy 'г. в' $t"
            else -> "d MMMM yyyy 'at' $t"
        }
        return fmt(pattern, s, ts)
    }
}
