package com.liquid.notes

import android.content.Intent
import android.os.Bundle
import android.text.format.DateFormat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.liquid.notes.data.NotesStore
import com.liquid.notes.ui.NotesRoot
import com.liquid.notes.ui.glass.warmUpGlass
import com.liquid.notes.ui.theme.NotesTheme
import com.liquid.notes.util.Dates
import com.liquid.notes.widget.NotesWidgets

class MainActivity : ComponentActivity() {

    private lateinit var store: NotesStore

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        store = NotesStore.get(this)
        warmUpGlass()
        Dates.is24h = DateFormat.is24HourFormat(this)
        val shared = sharedText(intent)
        val action = intent?.action
        val newNote = action == ACTION_NEW_NOTE
        val newChecklist = action == NotesWidgets.ACTION_NEW_CHECKLIST
        val openNoteId = intent?.getStringExtra(NotesWidgets.EXTRA_NOTE_ID)
        setContent {
            NotesTheme {
                NotesRoot(store, shared, newNote, newChecklist, openNoteId)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Dates.is24h = DateFormat.is24HourFormat(this)
        // e.g. after granting wallpaper access in Settings
        val app = applicationContext
        Thread { NotesWidgets.refresh(app) }.start()
    }

    override fun onStop() {
        super.onStop()
        store.flush()
    }

    companion object {
        const val ACTION_NEW_NOTE = "com.liquid.notes.NEW_NOTE"
    }

    private fun sharedText(i: Intent?): String? {
        if (i == null || i.action != Intent.ACTION_SEND) return null
        if (i.type?.startsWith("text/") != true) return null
        val subject = i.getStringExtra(Intent.EXTRA_SUBJECT)
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return null
        return if (!subject.isNullOrBlank() && !text.startsWith(subject)) subject + "\n" + text else text
    }
}
