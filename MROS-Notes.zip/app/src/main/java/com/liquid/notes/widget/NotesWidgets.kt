package com.liquid.notes.widget

import android.app.PendingIntent
import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import com.liquid.notes.MainActivity
import com.liquid.notes.R
import com.liquid.notes.data.Note
import com.liquid.notes.data.NoteText
import com.liquid.notes.data.NotesStore
import com.liquid.notes.util.Dates
import com.liquid.notes.util.Strings
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/*
 * Home-screen widgets. The glass itself is an XML layer-list (crisp at any size, follows light/dark).
 * Optionally a blurred copy of the wallpaper is placed under the glass — Android only lets apps read
 * the wallpaper with "All files access", so that part is opt-in.
 */
object NotesWidgets {
    const val EXTRA_NOTE_ID = "com.liquid.notes.extra.NOTE_ID"
    const val ACTION_OPEN_NOTE = "com.liquid.notes.OPEN_NOTE"
    const val ACTION_NEW_CHECKLIST = "com.liquid.notes.NEW_CHECKLIST"

    private fun strings() = Strings(Locale.getDefault().language)

    fun liveNotes(ctx: Context): List<Note> =
        NotesStore.get(ctx).data.value.notes
            .filter { it.deletedAt == null && !NoteText.isBlank(it.content) }
            .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.modifiedAt })

    /** Redraw every placed widget (called after each save). */
    fun refresh(context: Context) {
        try {
            val m = AppWidgetManager.getInstance(context)
            m.getAppWidgetIds(ComponentName(context, NoteWidgetProvider::class.java)).forEach { renderNote(context, m, it) }
            val listIds = m.getAppWidgetIds(ComponentName(context, ListWidgetProvider::class.java))
            listIds.forEach { renderList(context, m, it) }
            if (listIds.isNotEmpty()) m.notifyAppWidgetViewDataChanged(listIds, R.id.w_list)
            m.getAppWidgetIds(ComponentName(context, QuickWidgetProvider::class.java)).forEach { renderQuick(context, m, it) }
        } catch (e: Exception) {
            // widgets are best-effort
        }
    }

    private fun mutableFlag(): Int = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0

    private fun appIntent(ctx: Context, action: String?, noteId: String?): Intent {
        val i = Intent(ctx, MainActivity::class.java)
        i.action = action ?: Intent.ACTION_MAIN
        if (noteId != null) i.putExtra(EXTRA_NOTE_ID, noteId)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        return i
    }

    private fun open(ctx: Context, action: String?, noteId: String?, request: Int): PendingIntent =
        PendingIntent.getActivity(
            ctx,
            request,
            appIntent(ctx, action, noteId),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    private fun sizeDp(m: AppWidgetManager, id: Int, defW: Int, defH: Int): Pair<Int, Int> {
        val o = m.getAppWidgetOptions(id)
        val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0).takeIf { it > 0 } ?: defW
        val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0).takeIf { it > 0 } ?: defH
        return w to h
    }

    private fun applyWallpaper(ctx: Context, m: AppWidgetManager, id: Int, rv: RemoteViews, defW: Int, defH: Int) {
        val bmp = if (WidgetPrefs.blurActive(ctx)) {
            val (w, h) = sizeDp(m, id, defW, defH)
            WallpaperBlur.forWidget(ctx, (w - 12).coerceAtLeast(40).toFloat(), (h - 12).coerceAtLeast(40).toFloat(), 26f)
        } else {
            null
        }
        if (bmp != null) {
            rv.setImageViewBitmap(R.id.w_wall, bmp)
            rv.setViewVisibility(R.id.w_wall, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.w_wall, View.GONE)
        }
    }

    fun renderNote(ctx: Context, m: AppWidgetManager, id: Int) {
        val s = strings()
        val rv = RemoteViews(ctx.packageName, R.layout.widget_note)
        applyWallpaper(ctx, m, id, rv, 160, 160)
        val note = liveNotes(ctx).firstOrNull()
        if (note == null) {
            rv.setTextViewText(R.id.w_title, s.noNotes)
            rv.setTextViewText(R.id.w_body, s.newNote)
            rv.setTextViewText(R.id.w_date, "")
            rv.setOnClickPendingIntent(R.id.w_root, open(ctx, MainActivity.ACTION_NEW_NOTE, null, 100_000 + id))
        } else {
            rv.setTextViewText(R.id.w_title, (if (note.pinned) "📌 " else "") + (NoteText.title(note.content) ?: s.newNote))
            rv.setTextViewText(R.id.w_body, NoteText.body(note.content).ifBlank { s.noAdditionalText })
            rv.setTextViewText(R.id.w_date, Dates.rowDate(note.modifiedAt, s))
            rv.setOnClickPendingIntent(R.id.w_root, open(ctx, ACTION_OPEN_NOTE, note.id, 200_000 + id))
        }
        m.updateAppWidget(id, rv)
    }

    fun renderList(ctx: Context, m: AppWidgetManager, id: Int) {
        val s = strings()
        val count = liveNotes(ctx).size
        val rv = RemoteViews(ctx.packageName, R.layout.widget_list)
        applyWallpaper(ctx, m, id, rv, 250, 250)
        rv.setTextViewText(R.id.w_header, "MROS Notes")
        rv.setTextViewText(R.id.w_count, s.notesCount(count))
        rv.setTextViewText(R.id.w_empty, s.noNotes)
        rv.setOnClickPendingIntent(R.id.w_add, open(ctx, MainActivity.ACTION_NEW_NOTE, null, 300_000 + id))
        rv.setOnClickPendingIntent(R.id.w_header_row, open(ctx, null, null, 400_000 + id))
        val service = Intent(ctx, NotesListService::class.java)
        service.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        service.data = Uri.parse(service.toUri(Intent.URI_INTENT_SCHEME))
        rv.setRemoteAdapter(R.id.w_list, service)
        rv.setEmptyView(R.id.w_list, R.id.w_empty)
        val template = PendingIntent.getActivity(
            ctx,
            500_000 + id,
            appIntent(ctx, ACTION_OPEN_NOTE, null),
            PendingIntent.FLAG_UPDATE_CURRENT or mutableFlag(),
        )
        rv.setPendingIntentTemplate(R.id.w_list, template)
        m.updateAppWidget(id, rv)
    }

    fun renderQuick(ctx: Context, m: AppWidgetManager, id: Int) {
        val s = strings()
        val rv = RemoteViews(ctx.packageName, R.layout.widget_quick)
        applyWallpaper(ctx, m, id, rv, 180, 70)
        rv.setTextViewText(R.id.w_quick_note_label, s.newNote)
        rv.setTextViewText(R.id.w_quick_check_label, s.checklist)
        rv.setOnClickPendingIntent(R.id.w_quick_note, open(ctx, MainActivity.ACTION_NEW_NOTE, null, 600_000 + id))
        rv.setOnClickPendingIntent(R.id.w_quick_check, open(ctx, ACTION_NEW_CHECKLIST, null, 700_000 + id))
        m.updateAppWidget(id, rv)
    }
}

class NoteWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { NotesWidgets.renderNote(context, appWidgetManager, it) }
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle?) {
        NotesWidgets.renderNote(context, appWidgetManager, appWidgetId)
    }
}

class ListWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { NotesWidgets.renderList(context, appWidgetManager, it) }
        appWidgetManager.notifyAppWidgetViewDataChanged(appWidgetIds, R.id.w_list)
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle?) {
        NotesWidgets.renderList(context, appWidgetManager, appWidgetId)
    }
}

class QuickWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { NotesWidgets.renderQuick(context, appWidgetManager, it) }
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle?) {
        NotesWidgets.renderQuick(context, appWidgetManager, appWidgetId)
    }
}

/** Feeds the rows of the list widget. */
class NotesListService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsService.RemoteViewsFactory = NotesListFactory(applicationContext)
}

class NotesListFactory(private val ctx: Context) : RemoteViewsService.RemoteViewsFactory {
    private var notes: List<Note> = emptyList()
    private val s = Strings(Locale.getDefault().language)

    override fun onCreate() {}

    override fun onDataSetChanged() {
        notes = NotesWidgets.liveNotes(ctx).take(30)
    }

    override fun onDestroy() {
        notes = emptyList()
    }

    override fun getCount(): Int = notes.size

    override fun getViewAt(position: Int): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_list_item)
        val n = notes.getOrNull(position) ?: return rv
        rv.setTextViewText(R.id.w_item_title, (if (n.pinned) "📌 " else "") + (NoteText.title(n.content) ?: s.newNote))
        rv.setTextViewText(
            R.id.w_item_sub,
            Dates.rowDate(n.modifiedAt, s) + "   " + (NoteText.preview(n.content) ?: s.noAdditionalText),
        )
        rv.setViewVisibility(R.id.w_item_div, if (position == notes.size - 1) View.GONE else View.VISIBLE)
        val fill = Intent()
        fill.putExtra(NotesWidgets.EXTRA_NOTE_ID, n.id)
        rv.setOnClickFillInIntent(R.id.w_item, fill)
        return rv
    }

    override fun getLoadingView(): RemoteViews? = null

    override fun getViewTypeCount(): Int = 1

    override fun getItemId(position: Int): Long = notes.getOrNull(position)?.id?.hashCode()?.toLong() ?: position.toLong()

    override fun hasStableIds(): Boolean = true
}

object WidgetPrefs {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("widgets", Context.MODE_PRIVATE)

    fun blurWanted(ctx: Context): Boolean = prefs(ctx).getBoolean("wallpaper_blur", false)

    fun setBlur(ctx: Context, on: Boolean) {
        prefs(ctx).edit().putBoolean("wallpaper_blur", on).apply()
    }

    fun hasWallpaperAccess(): Boolean = Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()

    fun blurActive(ctx: Context): Boolean = blurWanted(ctx) && hasWallpaperAccess()

    fun openAccessSettings(ctx: Context) {
        if (Build.VERSION.SDK_INT < 30) return
        val own = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName))
        own.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(own)
        } catch (e: Exception) {
            val all = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
            all.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { ctx.startActivity(all) }
        }
    }
}

/** Small, heavily blurred copy of the home-screen wallpaper (cached per wallpaper). */
object WallpaperBlur {
    private var cached: Bitmap? = null
    private var cachedId = Int.MIN_VALUE

    @Synchronized
    private fun blurred(ctx: Context): Bitmap? {
        val wm = WallpaperManager.getInstance(ctx)
        val wid = try {
            wm.getWallpaperId(WallpaperManager.FLAG_SYSTEM)
        } catch (e: Exception) {
            -1
        }
        val hit = cached
        if (hit != null && wid == cachedId && !hit.isRecycled) return hit
        val d = try {
            wm.drawable
        } catch (e: Exception) {
            null
        } ?: return null
        val iw = d.intrinsicWidth.takeIf { it > 0 } ?: 1080
        val ih = d.intrinsicHeight.takeIf { it > 0 } ?: 2340
        val w = 180
        val h = (w * ih.toFloat() / iw).roundToInt().coerceIn(60, 600)
        val base = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(base)
        d.setBounds(0, 0, w, h)
        d.draw(c)
        // two passes of shrink + bilinear enlarge ≈ a soft gaussian blur
        var b = base
        repeat(2) {
            val small = Bitmap.createScaledBitmap(b, max(2, b.width / 7), max(2, b.height / 7), true)
            b = Bitmap.createScaledBitmap(small, w, h, true)
        }
        cached = b
        cachedId = wid
        return b
    }

    fun forWidget(ctx: Context, wDp: Float, hDp: Float, cornerDp: Float): Bitmap? {
        val base = try {
            blurred(ctx)
        } catch (e: Exception) {
            null
        } ?: return null
        val aspect = wDp / hDp
        var cw = base.width.toFloat()
        var ch = cw / aspect
        if (ch > base.height) {
            ch = base.height.toFloat()
            cw = ch * aspect
        }
        val left = (base.width - cw) / 2f
        val top = (base.height - ch) / 2f
        val outW: Int
        val outH: Int
        if (aspect >= 1f) {
            outW = 200
            outH = (200 / aspect).roundToInt().coerceAtLeast(8)
        } else {
            outH = 200
            outW = (200 * aspect).roundToInt().coerceAtLeast(8)
        }
        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val r = cornerDp / wDp * outW
        val clip = Path()
        clip.addRoundRect(RectF(0f, 0f, outW.toFloat(), outH.toFloat()), r, r, Path.Direction.CW)
        c.clipPath(clip)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        c.drawBitmap(
            base,
            Rect(left.toInt(), top.toInt(), (left + cw).toInt(), (top + ch).toInt()),
            RectF(0f, 0f, outW.toFloat(), outH.toFloat()),
            paint,
        )
        return out
    }
}
