package com.liquid.notes.notify

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ListenableWorker
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.liquid.notes.BuildConfig
import com.liquid.notes.MainActivity
import com.liquid.notes.R
import com.liquid.notes.data.NoteText
import com.liquid.notes.data.NotesStore
import com.liquid.notes.data.ReleaseInfo
import com.liquid.notes.data.Updater
import com.liquid.notes.util.Strings
import com.liquid.notes.widget.NotesWidgets
import java.util.Locale
import java.util.concurrent.TimeUnit

private fun strings() = Strings(Locale.getDefault().language)

object Notify {
    const val CHANNEL_REMINDERS = "reminders"
    const val CHANNEL_UPDATES = "updates"
    const val ACTION_CHECK_UPDATE = "com.liquid.notes.CHECK_UPDATE"
    private const val ACCENT = 0xFFE3A500.toInt()

    fun ensureChannels(ctx: Context) {
        val s = strings()
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val reminders = NotificationChannel(CHANNEL_REMINDERS, s.reminderChannel, NotificationManager.IMPORTANCE_HIGH)
        reminders.enableVibration(true)
        nm.createNotificationChannel(reminders)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_UPDATES, s.updateChannel, NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun canPost(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            return false
        }
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    fun post(ctx: Context, id: Int, builder: NotificationCompat.Builder) {
        if (!canPost(ctx)) return
        try {
            NotificationManagerCompat.from(ctx).notify(id, builder.setColor(ACCENT).build())
        } catch (e: SecurityException) {
            // permission revoked meanwhile
        }
    }

    fun cancel(ctx: Context, id: Int) {
        NotificationManagerCompat.from(ctx).cancel(id)
    }

    fun openAppIntent(ctx: Context, action: String?, noteId: String?, request: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
        i.action = action ?: Intent.ACTION_MAIN
        if (noteId != null) i.putExtra(NotesWidgets.EXTRA_NOTE_ID, noteId)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        return PendingIntent.getActivity(ctx, request, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}

/** Note reminders via AlarmManager (exact when allowed, otherwise within a few minutes). */
object Reminders {
    const val ACTION_FIRE = "com.liquid.notes.REMINDER_FIRE"
    const val ACTION_SNOOZE = "com.liquid.notes.REMINDER_SNOOZE"
    const val ACTION_DONE = "com.liquid.notes.REMINDER_DONE"
    const val EXTRA_ID = "com.liquid.notes.extra.REMINDER_NOTE"

    fun notificationId(noteId: String): Int = 10_000 + (noteId.hashCode() and 0x0FFFFFFF)

    private fun pending(ctx: Context, action: String, noteId: String): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java)
        i.action = action
        i.putExtra(EXTRA_ID, noteId)
        val request = noteId.hashCode() xor action.hashCode()
        return PendingIntent.getBroadcast(ctx, request, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** Set (or clear with null) a note's reminder and (re)schedule its alarm. */
    fun set(ctx: Context, noteId: String, at: Long?) {
        NotesStore.get(ctx).setReminder(noteId, at)
        if (at == null) {
            cancelAlarm(ctx, noteId)
        } else {
            schedule(ctx, noteId, at)
        }
    }

    fun schedule(ctx: Context, noteId: String, at: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val pi = pending(ctx, ACTION_FIRE, noteId)
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        try {
            if (exact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancelAlarm(ctx: Context, noteId: String) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        am.cancel(pending(ctx, ACTION_FIRE, noteId))
    }

    /** After reboot / app update all alarms are gone — put the future ones back. */
    fun rescheduleAll(ctx: Context) {
        val now = System.currentTimeMillis()
        NotesStore.get(ctx).data.value.notes.forEach { n ->
            val at = n.remindAt
            if (at != null && n.deletedAt == null) {
                if (at > now) schedule(ctx, n.id, at) else show(ctx, n.id)
            }
        }
    }

    /** Post the reminder notification for a note (and clear its reminder). */
    fun show(ctx: Context, noteId: String) {
        val store = NotesStore.get(ctx)
        val n = store.data.value.notes.find { it.id == noteId } ?: return
        store.setReminder(noteId, null)
        if (n.deletedAt != null) return
        val s = strings()
        val title = NoteText.title(n.content) ?: s.newNote
        val body = NoteText.body(n.content)
        val b = NotificationCompat.Builder(ctx, Notify.CHANNEL_REMINDERS)
            .setSmallIcon(R.drawable.ic_stat_notes)
            .setContentTitle(title)
            .setContentText(body.ifBlank { s.remindMe })
            .setStyle(NotificationCompat.BigTextStyle().bigText(body.ifBlank { s.remindMe }))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(Notify.openAppIntent(ctx, NotesWidgets.ACTION_OPEN_NOTE, noteId, notificationId(noteId)))
            .addAction(0, s.snooze, pending(ctx, ACTION_SNOOZE, noteId))
            .addAction(0, s.markDone, pending(ctx, ACTION_DONE, noteId))
        Notify.post(ctx, notificationId(noteId), b)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(Reminders.EXTRA_ID) ?: return
        when (intent.action) {
            Reminders.ACTION_FIRE -> Reminders.show(context, id)
            Reminders.ACTION_SNOOZE -> {
                Notify.cancel(context, Reminders.notificationId(id))
                Reminders.set(context, id, System.currentTimeMillis() + 10 * 60 * 1000L)
            }
            Reminders.ACTION_DONE -> {
                Notify.cancel(context, Reminders.notificationId(id))
                Reminders.set(context, id, null)
            }
        }
        NotesStore.get(context).flush()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Notify.ensureChannels(context)
        Reminders.rescheduleAll(context)
        NotesStore.get(context).flush()
        UpdateNotifier.schedule(context)
    }
}

/** Checks GitHub Releases in the background (every ~12 h) and posts "new version" notifications. */
object UpdateNotifier {
    private const val WORK = "mros-update-check"
    private const val NOTIFICATION_ID = 7

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("notify", Context.MODE_PRIVATE)

    fun enabled(ctx: Context): Boolean = prefs(ctx).getBoolean("updates", true)

    fun setEnabled(ctx: Context, on: Boolean) {
        prefs(ctx).edit().putBoolean("updates", on).apply()
        if (on) schedule(ctx) else WorkManager.getInstance(ctx).cancelUniqueWork(WORK)
    }

    fun schedule(ctx: Context) {
        if (!enabled(ctx) || BuildConfig.GITHUB_REPO.isBlank()) return
        val request = PeriodicWorkRequestBuilder<UpdateWorker>(12, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, request)
    }

    fun maybeNotify(ctx: Context, r: ReleaseInfo) {
        if (r.versionCode <= BuildConfig.VERSION_CODE) return
        val p = prefs(ctx)
        if (p.getInt("notified_code", 0) >= r.versionCode) return
        p.edit().putInt("notified_code", r.versionCode).apply()
        val s = strings()
        val b = NotificationCompat.Builder(ctx, Notify.CHANNEL_UPDATES)
            .setSmallIcon(R.drawable.ic_stat_notes)
            .setContentTitle(s.updateNotifTitle(r.versionName))
            .setContentText(r.notes.lineSequence().firstOrNull { it.isNotBlank() } ?: s.updateNotifText)
            .setAutoCancel(true)
            .setContentIntent(Notify.openAppIntent(ctx, Notify.ACTION_CHECK_UPDATE, null, 9_000))
        Notify.post(ctx, NOTIFICATION_ID, b)
    }
}

class UpdateWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): ListenableWorker.Result {
        val ctx = applicationContext
        if (!UpdateNotifier.enabled(ctx)) return ListenableWorker.Result.success()
        val repo = BuildConfig.GITHUB_REPO
        if (repo.isBlank()) return ListenableWorker.Result.success()
        return try {
            UpdateNotifier.maybeNotify(ctx, Updater.latest(repo))
            ListenableWorker.Result.success()
        } catch (e: Exception) {
            ListenableWorker.Result.success()
        }
    }
}
