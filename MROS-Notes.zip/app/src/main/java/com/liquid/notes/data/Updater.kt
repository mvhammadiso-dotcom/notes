package com.liquid.notes.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import javax.net.ssl.SSLException
import java.net.UnknownHostException
import java.net.URLEncoder
import java.net.URLDecoder
import java.net.SocketTimeoutException
import java.net.ConnectException

data class ReleaseInfo(
    val versionCode: Int,
    val versionName: String,
    val notes: String,
    val apkUrl: String,
)

/** Why an update check failed — mapped to a clear, translated message in the UI. */
enum class UpdateProblem { NotFound, NoRelease, RateLimited, Network, Other }

class UpdateException(val problem: UpdateProblem, message: String) : IOException(message)

/**
 * Self-update through GitHub Releases.
 * The CI workflow publishes every build as a release tagged "v<version>-<run number>" with MROS-Notes.apk;
 * the app compares the run number with its own versionCode.
 *
 * The check does NOT depend on the GitHub API (60 requests/hour per IP — mobile networks share IPs and hit
 * that limit easily). It follows github.com/<repo>/releases/latest, reads the tag from the redirect and
 * downloads the APK from the fixed release URL. The API is only asked, best-effort, for release notes.
 */
object Updater {
    private const val UA = "MROS-Notes-Android"
    const val APK_NAME = "MROS-Notes.apk"

    suspend fun latest(repo: String): ReleaseInfo = withContext(Dispatchers.IO) {
        val tag = try {
            latestTag(repo)
        } catch (e: UpdateException) {
            throw e
        } catch (e: Exception) {
            throw classify(e)
        }
        val code = Regex("\\d+").findAll(tag).lastOrNull()?.value?.toIntOrNull()
            ?: throw UpdateException(UpdateProblem.Other, "Release tag: $tag")
        val semver = Regex("\\d+\\.\\d+(\\.\\d+)?").find(tag)?.value
        var apk = "https://github.com/$repo/releases/download/" + URLEncoder.encode(tag, "UTF-8").replace("+", "%20") + "/" + APK_NAME
        var notes = ""
        // optional extras from the API (notes, exact asset URL); ignored if rate-limited
        runCatching {
            val c = open(URL("https://api.github.com/repos/$repo/releases/tags/" + URLEncoder.encode(tag, "UTF-8")), json = true)
            try {
                val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                notes = o.optString("body", "").trim()
                val assets = o.optJSONArray("assets") ?: JSONArray()
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name", "").endsWith(".apk", ignoreCase = true)) {
                        val u = a.optString("browser_download_url", "")
                        if (u.isNotBlank()) apk = u
                        break
                    }
                }
            } finally {
                c.disconnect()
            }
        }
        ReleaseInfo(
            versionCode = code,
            versionName = if (semver != null) "$semver ($code)" else "build $code",
            notes = notes,
            apkUrl = apk,
        )
    }

    /** github.com/<repo>/releases/latest → 302 → …/releases/tag/<tag> */
    private fun latestTag(repo: String): String {
        val c = URL("https://github.com/$repo/releases/latest").openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.connectTimeout = 15_000
        c.readTimeout = 15_000
        c.setRequestProperty("User-Agent", UA)
        try {
            val code = c.responseCode
            val location = c.getHeaderField("Location") ?: ""
            if (code == 404) throw UpdateException(UpdateProblem.NotFound, "HTTP 404")
            if (code == 429) throw UpdateException(UpdateProblem.RateLimited, "HTTP 429")
            if (code !in 300..399) throw UpdateException(UpdateProblem.Other, "HTTP $code")
            val tag = location.substringAfter("/releases/tag/", "").substringBefore('?').substringBefore('#')
            if (tag.isBlank()) throw UpdateException(UpdateProblem.NoRelease, "no releases")
            return URLDecoder.decode(tag, "UTF-8")
        } finally {
            c.disconnect()
        }
    }

    private fun classify(e: Exception): UpdateException = when (e) {
        is UpdateException -> e
        is UnknownHostException, is ConnectException, is SocketTimeoutException, is SSLException ->
            UpdateException(UpdateProblem.Network, e.javaClass.simpleName)
        else -> UpdateException(UpdateProblem.Other, e.message ?: e.javaClass.simpleName)
    }

    suspend fun download(context: Context, url: String, onProgress: (Float) -> Unit): File =
        withContext(Dispatchers.IO) {
            val dir = File(context.cacheDir, "updates")
            dir.mkdirs()
            val out = File(dir, "MROS-Notes-update.apk")
            if (out.exists()) out.delete()
            val conn = try {
                open(URL(url), json = false)
            } catch (e: Exception) {
                throw classify(e)
            }
            try {
                val total = conn.contentLengthLong
                conn.inputStream.use { input ->
                    FileOutputStream(out).use { output ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            done += n
                            if (total > 0) onProgress((done.toFloat() / total).coerceIn(0f, 1f))
                        }
                    }
                }
            } finally {
                conn.disconnect()
            }
            out
        }

    fun canInstall(context: Context): Boolean = context.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(context: Context) {
        val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + context.packageName))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(i) }
    }

    fun install(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(i)
    }

    private fun open(url: URL, json: Boolean, depth: Int = 0): HttpURLConnection {
        val c = url.openConnection() as HttpURLConnection
        c.instanceFollowRedirects = true
        c.connectTimeout = 20_000
        c.readTimeout = 30_000
        c.setRequestProperty("User-Agent", UA)
        if (json) c.setRequestProperty("Accept", "application/vnd.github+json")
        val code = c.responseCode
        if (code in 300..399 && depth < 6) {
            val location = c.getHeaderField("Location")
            c.disconnect()
            if (location == null) throw IOException("HTTP $code")
            return open(URL(url, location), json, depth + 1)
        }
        if (code !in 200..299) {
            c.disconnect()
            throw when (code) {
                404 -> UpdateException(UpdateProblem.NotFound, "HTTP 404")
                403, 429 -> UpdateException(UpdateProblem.RateLimited, "HTTP $code")
                else -> UpdateException(UpdateProblem.Other, "HTTP $code")
            }
        }
        return c
    }
}
