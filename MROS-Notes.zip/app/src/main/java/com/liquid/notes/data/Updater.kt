package com.liquid.notes.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class ReleaseInfo(
    val versionCode: Int,
    val versionName: String,
    val notes: String,
    val apkUrl: String,
)

/**
 * Self-update through GitHub Releases.
 * The CI workflow publishes every build as a release tagged "v<run number>" with LiquidNotes.apk attached;
 * the app compares that number with its own versionCode.
 */
object Updater {

    suspend fun latest(repo: String): ReleaseInfo = withContext(Dispatchers.IO) {
        val conn = open(URL("https://api.github.com/repos/$repo/releases/latest"), json = true)
        try {
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val o = JSONObject(body)
            val tag = o.optString("tag_name", "")
            val code = Regex("\\d+").findAll(tag).lastOrNull()?.value?.toIntOrNull()
                ?: throw IOException("Release tag: $tag")
            val assets = o.optJSONArray("assets") ?: JSONArray()
            var apk: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name", "").endsWith(".apk", ignoreCase = true)) {
                    apk = a.optString("browser_download_url", "")
                    break
                }
            }
            if (apk.isNullOrBlank()) throw IOException("APK not found in release $tag")
            ReleaseInfo(
                versionCode = code,
                versionName = "1.0.$code",
                notes = o.optString("body", "").trim(),
                apkUrl = apk,
            )
        } finally {
            conn.disconnect()
        }
    }

    suspend fun download(context: Context, url: String, onProgress: (Float) -> Unit): File =
        withContext(Dispatchers.IO) {
            val dir = File(context.cacheDir, "updates")
            dir.mkdirs()
            val out = File(dir, "MROS-Notes-update.apk")
            if (out.exists()) out.delete()
            val conn = open(URL(url), json = false)
            try {
                val total = conn.contentLengthLong
                conn.inputStream.use { input ->
                    FileOutputStream(out).use { output ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            done += n
                            if (total > 0) onProgress((done.toFloat() / total).coerceIn(0f, 1f))
                        }
                    }
                }
            } finally {
                conn.disconnect()
            }
            out
        }

    fun canInstall(context: Context): Boolean = context.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(context: Context) {
        val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + context.packageName))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(i) }
    }

    fun install(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(i)
    }

    private fun open(url: URL, json: Boolean, depth: Int = 0): HttpURLConnection {
        val c = url.openConnection() as HttpURLConnection
        c.instanceFollowRedirects = true
        c.connectTimeout = 20_000
        c.readTimeout = 30_000
        c.setRequestProperty("User-Agent", "MROS-Notes-Android")
        if (json) c.setRequestProperty("Accept", "application/vnd.github+json")
        val code = c.responseCode
        if (code in 300..399 && depth < 6) {
            val location = c.getHeaderField("Location")
            c.disconnect()
            if (location == null) throw IOException("HTTP $code")
            return open(URL(url, location), json, depth + 1)
        }
        if (code !in 200..299) {
            c.disconnect()
            throw IOException(if (code == 404) "HTTP 404 — repository private or no releases yet" else "HTTP $code")
        }
        return c
    }
}
