package com.liquid.notes.data

import android.content.Context
import android.util.AtomicFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.UUID

/** All notes live in one small JSON file, written atomically with a short debounce. */
class NotesStore private constructor(context: Context) {

    private val file = AtomicFile(File(context.filesDir, "notes.json"))
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var saveJob: Job? = null
    private val lock = Any()

    private val _data = MutableStateFlow(load())
    val data: StateFlow<AppData> = _data.asStateFlow()

    // ---------- notes ----------

    fun createNote(folderId: String, content: String = ""): String {
        val now = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        mutate { d ->
            val folder = if (d.folders.any { it.id == folderId }) folderId else DEFAULT_FOLDER
            d.copy(notes = d.notes + Note(id, folder, content, now, now))
        }
        return id
    }

    fun setContent(id: String, content: String) {
        val current = _data.value.notes.find { it.id == id } ?: return
        if (current.content == content) return
        val now = System.currentTimeMillis()
        mutateNote(id) { it.copy(content = content, modifiedAt = now) }
    }

    fun duplicateNote(id: String): String? {
        val n = _data.value.notes.find { it.id == id } ?: return null
        val now = System.currentTimeMillis()
        val copyId = UUID.randomUUID().toString()
        mutate { d -> d.copy(notes = d.notes + n.copy(id = copyId, createdAt = now, modifiedAt = now, pinned = false, deletedAt = null)) }
        return copyId
    }

    fun togglePin(id: String) = mutateNote(id) { it.copy(pinned = !it.pinned) }

    fun moveNote(id: String, folderId: String) = mutateNote(id) { it.copy(folderId = folderId) }

    fun deleteNote(id: String) {
        val now = System.currentTimeMillis()
        mutateNote(id) { it.copy(deletedAt = now, pinned = false) }
    }

    fun recoverNote(id: String) = mutate { d ->
        val ids = d.folders.map { it.id }.toSet()
        d.copy(notes = d.notes.map {
            if (it.id == id) it.copy(deletedAt = null, folderId = if (it.folderId in ids) it.folderId else DEFAULT_FOLDER) else it
        })
    }

    fun deleteForever(id: String) = mutate { d -> d.copy(notes = d.notes.filterNot { it.id == id }) }

    fun deleteAllDeleted() = mutate { d -> d.copy(notes = d.notes.filter { it.deletedAt == null }) }

    /** iOS drops a note that was left empty. */
    fun discardIfEmpty(id: String) {
        val n = _data.value.notes.find { it.id == id } ?: return
        if (n.deletedAt == null && NoteText.isBlank(n.content)) deleteForever(id)
    }

    // ---------- folders ----------

    fun createFolder(name: String): String {
        val id = UUID.randomUUID().toString()
        mutate { d -> d.copy(folders = d.folders + Folder(id, name.trim(), System.currentTimeMillis())) }
        return id
    }

    fun renameFolder(id: String, name: String) = mutate { d ->
        d.copy(folders = d.folders.map { if (it.id == id) it.copy(name = name.trim()) else it })
    }

    fun deleteFolder(id: String) {
        if (id == DEFAULT_FOLDER) return
        val now = System.currentTimeMillis()
        mutate { d ->
            d.copy(
                folders = d.folders.filterNot { it.id == id },
                notes = d.notes.map {
                    if (it.folderId == id && it.deletedAt == null) it.copy(deletedAt = now, pinned = false) else it
                },
            )
        }
    }

    fun folderNameTaken(name: String, exceptId: String?, defaultName: String): Boolean {
        val n = name.trim()
        if (n.equals(defaultName, ignoreCase = true)) return true
        return _data.value.folders.any { it.id != exceptId && it.id != DEFAULT_FOLDER && it.name.equals(n, ignoreCase = true) }
    }

    // ---------- prefs ----------

    fun setSort(mode: SortMode) = mutate { it.copy(sort = mode) }

    fun setView(mode: ViewMode) = mutate { it.copy(view = mode) }

    // ---------- persistence ----------

    fun flush() {
        saveJob?.cancel()
        write(_data.value)
    }

    private fun mutateNote(id: String, block: (Note) -> Note) = mutate { d ->
        d.copy(notes = d.notes.map { if (it.id == id) block(it) else it })
    }

    private fun mutate(block: (AppData) -> AppData) {
        _data.update(block)
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(350)
            write(_data.value)
        }
    }

    private fun write(d: AppData) {
        synchronized(lock) {
            var out: FileOutputStream? = null
            try {
                out = file.startWrite()
                out.write(toJson(d).toByteArray(Charsets.UTF_8))
                file.finishWrite(out)
            } catch (e: Exception) {
                if (out != null) file.failWrite(out)
            }
        }
    }

    private fun load(): AppData {
        val parsed = try {
            if (file.baseFile.exists()) fromJson(String(file.readFully(), Charsets.UTF_8)) else null
        } catch (e: Exception) {
            null
        }
        val base = parsed ?: firstRun()
        val folderIds = base.folders.map { it.id }.toSet()
        val cutoff = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000
        val notes = base.notes
            .filter { n ->
                val d = n.deletedAt
                if (d != null) d > cutoff else !NoteText.isBlank(n.content)
            }
            .map { if (it.folderId in folderIds) it else it.copy(folderId = DEFAULT_FOLDER) }
        return base.copy(notes = notes)
    }

    private fun firstRun(): AppData {
        val now = System.currentTimeMillis()
        val text = when (Locale.getDefault().language) {
            "uz" -> listOf(
                "MROS Notes’ga xush kelibsiz 👋",
                "iOS Eslatmalar uslubidagi ilova, Liquid Glass dizayn bilan. #mros",
                "",
                "${NoteText.CHECKED}Eslatma yaratish",
                "${NoteText.UNCHECKED}Ro‘yxat bandini belgilash",
                "${NoteText.UNCHECKED}Eslatmani chapga suring — ko‘chirish yoki o‘chirish",
                "${NoteText.UNCHECKED}Uzoq bosing — menyu",
                "",
                "• “- ” yozsangiz ro‘yxat boshlanadi",
                "• Pastdagi Aa — formatlash",
            )
            "ru" -> listOf(
                "Добро пожаловать в MROS Notes 👋",
                "Заметки в стиле iOS с дизайном Liquid Glass. #mros",
                "",
                "${NoteText.CHECKED}Создать заметку",
                "${NoteText.UNCHECKED}Отметить пункт списка",
                "${NoteText.UNCHECKED}Смахните заметку влево — переместить или удалить",
                "${NoteText.UNCHECKED}Долгое нажатие — меню",
                "",
                "• Напишите «- », чтобы начать список",
                "• Кнопка Aa внизу — форматирование",
            )
            else -> listOf(
                "Welcome to MROS Notes 👋",
                "iOS-style notes with a Liquid Glass design. #mros",
                "",
                "${NoteText.CHECKED}Create a note",
                "${NoteText.UNCHECKED}Tick a checklist item",
                "${NoteText.UNCHECKED}Swipe a note left to move or delete it",
                "${NoteText.UNCHECKED}Long-press for the menu",
                "",
                "• Type “- ” to start a list",
                "• Aa at the bottom — formatting",
            )
        }.joinToString("\n")
        return AppData(
            folders = listOf(Folder(DEFAULT_FOLDER, "", 0L)),
            notes = listOf(Note(UUID.randomUUID().toString(), DEFAULT_FOLDER, text, now, now)),
        )
    }

    private fun toJson(d: AppData): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("sort", d.sort.name)
        root.put("view", d.view.name)
        val folders = JSONArray()
        d.folders.forEach { f ->
            folders.put(JSONObject().put("id", f.id).put("name", f.name).put("createdAt", f.createdAt))
        }
        root.put("folders", folders)
        val notes = JSONArray()
        d.notes.forEach { n ->
            val o = JSONObject()
            o.put("id", n.id)
            o.put("folderId", n.folderId)
            o.put("content", n.content)
            o.put("createdAt", n.createdAt)
            o.put("modifiedAt", n.modifiedAt)
            o.put("pinned", n.pinned)
            val del = n.deletedAt
            if (del != null) o.put("deletedAt", del)
            notes.put(o)
        }
        root.put("notes", notes)
        return root.toString()
    }

    private fun fromJson(text: String): AppData {
        val root = JSONObject(text)
        val folders = mutableListOf<Folder>()
        val fa = root.optJSONArray("folders") ?: JSONArray()
        for (i in 0 until fa.length()) {
            val f = fa.getJSONObject(i)
            folders += Folder(f.getString("id"), f.optString("name", ""), f.optLong("createdAt", 0L))
        }
        if (folders.none { it.id == DEFAULT_FOLDER }) folders.add(0, Folder(DEFAULT_FOLDER, "", 0L))
        val notes = mutableListOf<Note>()
        val na = root.optJSONArray("notes") ?: JSONArray()
        for (i in 0 until na.length()) {
            val n = na.getJSONObject(i)
            notes += Note(
                id = n.getString("id"),
                folderId = n.optString("folderId", DEFAULT_FOLDER),
                content = n.optString("content", ""),
                createdAt = n.optLong("createdAt", 0L),
                modifiedAt = n.optLong("modifiedAt", 0L),
                pinned = n.optBoolean("pinned", false),
                deletedAt = if (n.has("deletedAt") && !n.isNull("deletedAt")) n.getLong("deletedAt") else null,
            )
        }
        val sort = runCatching { SortMode.valueOf(root.optString("sort", "Edited")) }.getOrDefault(SortMode.Edited)
        val view = runCatching { ViewMode.valueOf(root.optString("view", "Rows")) }.getOrDefault(ViewMode.Rows)
        return AppData(folders, notes, sort, view)
    }

    companion object {
        @Volatile
        private var instance: NotesStore? = null

        fun get(context: Context): NotesStore =
            instance ?: synchronized(this) {
                instance ?: NotesStore(context.applicationContext).also { instance = it }
            }
    }
}
