package com.liquid.notes.util

import androidx.compose.runtime.staticCompositionLocalOf

/** Tiny in-code localisation: English, Uzbek, Russian (follows the phone language). */
class Strings(lang: String) {
    val lang: String = when (lang) {
        "uz", "ru" -> lang
        else -> "en"
    }

    private fun t(en: String, uz: String, ru: String) = when (lang) {
        "uz" -> uz
        "ru" -> ru
        else -> en
    }

    val folders = t("Folders", "Jildlar", "Папки")
    val onMyPhone = t("On My Phone", "Telefonimda", "На телефоне")
    val allNotes = t("All Notes", "Barcha eslatmalar", "Все заметки")
    val notes = t("Notes", "Eslatmalar", "Заметки")
    val recentlyDeleted = t("Recently Deleted", "Yaqinda o‘chirilganlar", "Недавно удаленные")
    val edit = t("Edit", "Tahrirlash", "Изменить")
    val done = t("Done", "Tayyor", "Готово")
    val search = t("Search", "Qidirish", "Поиск")
    val cancel = t("Cancel", "Bekor qilish", "Отменить")
    val save = t("Save", "Saqlash", "Сохранить")
    val ok = t("OK", "OK", "ОК")
    val later = t("Later", "Keyinroq", "Позже")

    val newFolder = t("New Folder", "Yangi jild", "Новая папка")
    val newFolderMsg = t("Enter a name for this folder.", "Bu jild uchun nom kiriting.", "Введите имя для этой папки.")
    val name = t("Name", "Nomi", "Имя")
    val rename = t("Rename", "Nomini o‘zgartirish", "Переименовать")
    val renameFolder = t("Rename Folder", "Jild nomini o‘zgartirish", "Переименовать папку")
    val deleteFolder = t("Delete Folder", "Jildni o‘chirish", "Удалить папку")
    val deleteFolderMsg = t(
        "All notes in this folder will be moved to Recently Deleted.",
        "Bu jilddagi barcha eslatmalar “Yaqinda o‘chirilganlar”ga o‘tkaziladi.",
        "Все заметки из этой папки будут перемещены в «Недавно удаленные».",
    )
    val nameTaken = t("Name Taken", "Bu nom band", "Имя занято")
    val nameTakenMsg = t("Please choose a different name.", "Iltimos, boshqa nom tanlang.", "Выберите другое имя.")

    val pinned = t("Pinned", "Qadalgan", "Закрепленные")
    val today = t("Today", "Bugun", "Сегодня")
    val yesterday = t("Yesterday", "Kecha", "Вчера")
    val prev7 = t("Previous 7 Days", "Oldingi 7 kun", "Предыдущие 7 дней")
    val prev30 = t("Previous 30 Days", "Oldingi 30 kun", "Предыдущие 30 дней")
    val newNote = t("New Note", "Yangi eslatma", "Новая заметка")
    val noAdditionalText = t("No additional text", "Qo‘shimcha matn yo‘q", "Нет дополнительного текста")
    val noNotes = t("No Notes", "Eslatmalar yo‘q", "Нет заметок")
    val noResults = t("No Results", "Hech narsa topilmadi", "Нет результатов")

    val pinNote = t("Pin Note", "Eslatmani qadash", "Закрепить заметку")
    val unpinNote = t("Unpin Note", "Qadashni olib tashlash", "Открепить заметку")
    val move = t("Move", "Ko‘chirish", "Переместить")
    val share = t("Share", "Ulashish", "Поделиться")
    val delete = t("Delete", "O‘chirish", "Удалить")
    val recover = t("Recover", "Tiklash", "Восстановить")
    val deleteForever = t("Delete Permanently", "Butunlay o‘chirish", "Удалить навсегда")
    val deleteAll = t("Delete All", "Hammasini o‘chirish", "Удалить все")
    val deleteAllMsg = t(
        "These notes will be deleted. This action can’t be undone.",
        "Bu eslatmalar o‘chiriladi. Bu amalni ortga qaytarib bo‘lmaydi.",
        "Эти заметки будут удалены. Это действие нельзя отменить.",
    )
    val deletedInfo = t(
        "Notes are available here for 30 days. After that time, notes will be permanently deleted.",
        "Eslatmalar bu yerda 30 kun saqlanadi. Shundan so‘ng ular butunlay o‘chiriladi.",
        "Заметки доступны здесь 30 дней. После этого они будут удалены навсегда.",
    )
    val selectFolder = t("Select a folder", "Jildni tanlang", "Выберите папку")

    val viewAsGallery = t("View as Gallery", "Galereya ko‘rinishi", "Вид «Галерея»")
    val viewAsList = t("View as List", "Ro‘yxat ko‘rinishi", "Вид «Список»")
    val sortBy = t("Sort By", "Saralash", "Сортировка")
    val dateEdited = t("Date Edited", "Tahrir sanasi", "Дата изменения")
    val dateCreated = t("Date Created", "Yaratilgan sana", "Дата создания")
    val title = t("Title", "Sarlavha", "Название")

    val tags = t("Tags", "Teglar", "Теги")
    val format = t("Format", "Format", "Формат")
    val bulletedList = t("Bulleted List", "Belgili ro‘yxat", "Маркированный список")
    val numberedList = t("Numbered List", "Raqamli ro‘yxat", "Нумерованный список")
    val checklist = t("Checklist", "Nazorat ro‘yxati", "Чек-лист")
    val moveCheckedDown = t("Move Checked to Bottom", "Belgilanganlarni pastga", "Отмеченные вниз")
    val uncheckAll = t("Uncheck All", "Belgilarni olib tashlash", "Снять все отметки")
    val deleteChecked = t("Delete Checked Items", "Belgilanganlarni o‘chirish", "Удалить отмеченные")
    val undo = t("Undo", "Bekor qilish", "Отменить")
    val redo = t("Redo", "Qaytarish", "Повторить")
    val duplicate = t("Duplicate", "Nusxa olish", "Дублировать")
    fun wordsChars(w: Int, c: Int) = t("$w words · $c characters", "$w so‘z · $c belgi", "Слов: $w · Символов: $c")
    fun daysLeft(n: Long) = t(if (n == 1L) "1 day" else "$n days", "$n kun", "$n дн.")

    val widgetBlur = t("Blur Wallpaper Behind Widgets", "Widget orqasida obi-oy blur", "Размытие обоев под виджетами")
    val widgetBlurMsg = t(
        "Android only lets apps read the wallpaper with “All files access”. MROS Notes uses it just to draw a blurred wallpaper behind its widgets.",
        "Android obi-oyni faqat “Barcha fayllarga kirish” ruxsati bilan o‘qishga beradi. MROS Notes undan faqat widget orqasiga xiralashgan obi-oy chizish uchun foydalanadi.",
        "Android даёт читать обои только с разрешением «Доступ ко всем файлам». MROS Notes использует его только для размытых обоев под виджетами.",
    )
    val continueLabel = t("Continue", "Davom etish", "Продолжить")
    val notSupported = t("Needs Android 11 or newer.", "Android 11 yoki yangisi kerak.", "Нужен Android 11 или новее.")

    val info = t("Info", "Ma’lumot", "О приложении")
    val updatesSection = t("Updates", "Yangilanishlar", "Обновления")
    val telegramChannel = t("Telegram Channel", "Telegram kanal", "Telegram-канал")
    val whatsNewTitle = t("What’s New", "Nimalar yangi", "Что нового")
    val whatsNewHeading = t("What’s New", "Nimalar yangi", "Что нового")
    val widgetsSection = t("Widgets", "Widgetlar", "Виджеты")
    val widgetBlurFootnote = t(
        "Puts a blurred copy of your wallpaper behind MROS Notes widgets. Needs “All files access”.",
        "MROS Notes widgetlari orqasiga obi-oyning xiralashgan nusxasini qo‘yadi. “Barcha fayllarga kirish” ruxsati kerak.",
        "Размытая копия обоев под виджетами MROS Notes. Нужен «Доступ ко всем файлам».",
    )
    val appLabel = t("App", "Ilova", "Приложение")
    val versionLabel = t("Version", "Versiya", "Версия")
    val creatorLabel = t("Creator", "Yaratuvchi", "Создатель")
    val creatorTelegram = t("Creator on Telegram", "Yaratuvchi Telegram’da", "Создатель в Telegram")
    val latest = t("Latest", "So‘nggi", "Последняя")
    fun updateReady(v: String) = t("$v available", "$v mavjud", "Доступна $v")

    /** "What's New" sheet shown once after each update — also a quick how-to. */
    val whatsNewItems: List<Pair<String, String>> = when (lang) {
        "uz" -> listOf(
            "Liquid Glass" to "Tugmalar, menyular va oynalar suv tomchisidek shisha. Orqadagi narsalar ular orqali sinib ko‘rinadi.",
            "Suvdek ochilish" to "Har bir ekran va oyna siz bosgan tugmadan cho‘zilib ochiladi va yopilganda unga qaytib kiradi.",
            "Surish tugmalari" to "Eslatmani chapga suring — ko‘chirish yoki o‘chirish, o‘ngga — qadash. Oxirigacha sursangiz darhol bajariladi.",
            "Formatlash" to "Pastdagi Aa — belgili va raqamli ro‘yxat, checklist. Qator boshida “- ” yozsangiz ro‘yxat o‘zi boshlanadi.",
            "Undo / Redo" to "Yozayotganda tepada ↶ ↷ tugmalari bor — xatoni bir bosishda qaytaring.",
            "#teglar" to "Matnga #so‘z yozing — Jildlar ekranidagi Teglar bo‘limida shu tegli eslatmalar to‘planadi.",
            "Widgetlar" to "Bosh ekranni uzoq bosing → Widgetlar → MROS Notes: eslatma, ro‘yxat yoki tezkor tugmalar.",
            "Yangilanishlar" to "Jildlar → ••• → Ma’lumot → 🔄. Yangi versiya chiqsa ilovaning o‘zi yuklab o‘rnatadi.",
        )
        "ru" -> listOf(
            "Liquid Glass" to "Кнопки, меню и окна — стекло как капля воды, сквозь него преломляется то, что позади.",
            "Жидкие анимации" to "Каждый экран и окно вытягивается из нажатой кнопки и возвращается в неё при закрытии.",
            "Кнопки смахивания" to "Смахните заметку влево — переместить или удалить, вправо — закрепить. До конца — выполнить сразу.",
            "Форматирование" to "Aa внизу — маркированный и нумерованный список, чек-лист. «- » в начале строки начинает список.",
            "Отмена / Повтор" to "Во время ввода вверху есть ↶ ↷ — исправьте ошибку одним нажатием.",
            "#теги" to "Напишите #слово — заметки с этим тегом соберутся в разделе «Теги» на экране папок.",
            "Виджеты" to "Долгое нажатие на рабочем столе → Виджеты → MROS Notes: заметка, список или быстрые кнопки.",
            "Обновления" to "Папки → ••• → О приложении → 🔄. Новая версия скачается и установится прямо из приложения.",
        )
        else -> listOf(
            "Liquid Glass" to "Buttons, menus and dialogs are glass like a drop of water — whatever is behind refracts through them.",
            "Liquid motion" to "Every screen and dialog stretches out of the button you pressed and flows back into it when closed.",
            "Swipe buttons" to "Swipe a note left to move or delete, right to pin. Swipe all the way to do it instantly.",
            "Formatting" to "Aa at the bottom: bulleted and numbered lists, checklists. Type “- ” at the start of a line to begin a list.",
            "Undo / Redo" to "While typing, ↶ ↷ at the top fix a mistake in one tap.",
            "#tags" to "Write #word — notes with that tag gather under Tags on the Folders screen.",
            "Widgets" to "Long-press the home screen → Widgets → MROS Notes: a note, a list or quick buttons.",
            "Updates" to "Folders → ••• → Info → 🔄. New versions download and install right from the app.",
        )
    }

    // updates
    val checkUpdates = t("Check for Updates", "Yangilanishlarni tekshirish", "Проверить обновления")
    val checking = t("Checking…", "Tekshirilmoqda…", "Проверка…")
    val updateAvailable = t("Update Available", "Yangi versiya bor", "Доступно обновление")
    val upToDate = t("You’re Up to Date", "Eng so‘nggi versiya o‘rnatilgan", "Установлена последняя версия")
    val updateNow = t("Update", "Yangilash", "Обновить")
    val downloading = t("Downloading…", "Yuklanmoqda…", "Загрузка…")
    val updateFailed = t("Couldn’t Check for Updates", "Yangilanishni tekshirib bo‘lmadi", "Не удалось проверить обновления")
    val downloadFailed = t("Download Failed", "Yuklab bo‘lmadi", "Ошибка загрузки")
    val noRepo = t(
        "This build doesn’t know its GitHub repository. Build it with GitHub Actions.",
        "Bu APK GitHub repozitoriyasini bilmaydi. Uni GitHub Actions orqali yig‘ing.",
        "Эта сборка не знает свой репозиторий GitHub. Соберите её через GitHub Actions.",
    )
    val allowInstall = t(
        "Allow installing apps from this source, then tap Update again.",
        "Ushbu manbadan ilova o‘rnatishga ruxsat bering, so‘ng yana “Yangilash”ni bosing.",
        "Разрешите установку приложений из этого источника и снова нажмите «Обновить».",
    )
    fun errNotFound(repo: String) = t(
        "GitHub can’t find “$repo”. The repository must be Public (Settings → General → Danger Zone → Change visibility).",
        "GitHub’da “$repo” topilmadi. Repozitoriya Public bo‘lishi kerak (Settings → General → Danger Zone → Change visibility).",
        "GitHub не находит «$repo». Репозиторий должен быть Public (Settings → General → Danger Zone → Change visibility).",
    )
    fun errNoRelease(repo: String) = t(
        "“$repo” has no releases yet. Wait for the GitHub Actions build to finish (green ✓).",
        "“$repo” da hali Release yo‘q. GitHub Actions yig‘ishi muvaffaqiyatli (yashil ✓) tugashini kuting.",
        "В «$repo» ещё нет релизов. Дождитесь успешной сборки GitHub Actions (зелёная ✓).",
    )
    val errRateLimit = t(
        "GitHub is limiting requests right now. Try again in a few minutes.",
        "GitHub hozir so‘rovlarni cheklayapti. Bir necha daqiqadan keyin qayta urinib ko‘ring.",
        "GitHub сейчас ограничивает запросы. Попробуйте через несколько минут.",
    )
    val errNetwork = t(
        "No connection to GitHub. Check the internet and try again.",
        "GitHub’ga ulanib bo‘lmadi. Internetni tekshirib, qayta urinib ko‘ring.",
        "Нет связи с GitHub. Проверьте интернет и попробуйте снова.",
    )

    fun currentVersion(v: String) = t("Version $v", "Versiya $v", "Версия $v")
    fun newVersionMsg(newV: String, curV: String) = t(
        "Version $newV is available. You have $curV.",
        "$newV versiyasi chiqdi. Sizda $curV.",
        "Доступна версия $newV. У вас $curV.",
    )

    fun notesCount(n: Int): String = when (lang) {
        "uz" -> "$n ta eslatma"
        "ru" -> "$n " + ruPlural(n, "заметка", "заметки", "заметок")
        else -> if (n == 1) "1 Note" else "$n Notes"
    }

    private fun ruPlural(n: Int, one: String, few: String, many: String): String {
        val m10 = n % 10
        val m100 = n % 100
        return when {
            m10 == 1 && m100 != 11 -> one
            m10 in 2..4 && m100 !in 12..14 -> few
            else -> many
        }
    }
}

val LocalStrings = staticCompositionLocalOf { Strings("en") }
