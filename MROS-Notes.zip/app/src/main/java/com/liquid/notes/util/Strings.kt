package com.liquid.notes.util

import androidx.compose.runtime.staticCompositionLocalOf

/** Tiny in-code localisation: English, Uzbek, Russian (follows the phone language). */
class Strings(lang: String) {
    val lang: String = when (lang) {
        "uz", "ru" -> lang
        else -> "en"
    }

    private fun t(en: String, uz: String, ru: String) = when (lang) {
        "uz" -> uz
        "ru" -> ru
        else -> en
    }

    val folders = t("Folders", "Jildlar", "Папки")
    val onMyPhone = t("On My Phone", "Telefonimda", "На телефоне")
    val allNotes = t("All Notes", "Barcha eslatmalar", "Все заметки")
    val notes = t("Notes", "Eslatmalar", "Заметки")
    val recentlyDeleted = t("Recently Deleted", "Yaqinda o‘chirilganlar", "Недавно удаленные")
    val edit = t("Edit", "Tahrirlash", "Изменить")
    val done = t("Done", "Tayyor", "Готово")
    val search = t("Search", "Qidirish", "Поиск")
    val cancel = t("Cancel", "Bekor qilish", "Отменить")
    val save = t("Save", "Saqlash", "Сохранить")
    val ok = t("OK", "OK", "ОК")
    val later = t("Later", "Keyinroq", "Позже")

    val newFolder = t("New Folder", "Yangi jild", "Новая папка")
    val newFolderMsg = t("Enter a name for this folder.", "Bu jild uchun nom kiriting.", "Введите имя для этой папки.")
    val name = t("Name", "Nomi", "Имя")
    val rename = t("Rename", "Nomini o‘zgartirish", "Переименовать")
    val renameFolder = t("Rename Folder", "Jild nomini o‘zgartirish", "Переименовать папку")
    val deleteFolder = t("Delete Folder", "Jildni o‘chirish", "Удалить папку")
    val deleteFolderMsg = t(
        "All notes in this folder will be moved to Recently Deleted.",
        "Bu jilddagi barcha eslatmalar “Yaqinda o‘chirilganlar”ga o‘tkaziladi.",
        "Все заметки из этой папки будут перемещены в «Недавно удаленные».",
    )
    val nameTaken = t("Name Taken", "Bu nom band", "Имя занято")
    val nameTakenMsg = t("Please choose a different name.", "Iltimos, boshqa nom tanlang.", "Выберите другое имя.")

    val pinned = t("Pinned", "Qadalgan", "Закрепленные")
    val today = t("Today", "Bugun", "Сегодня")
    val yesterday = t("Yesterday", "Kecha", "Вчера")
    val prev7 = t("Previous 7 Days", "Oldingi 7 kun", "Предыдущие 7 дней")
    val prev30 = t("Previous 30 Days", "Oldingi 30 kun", "Предыдущие 30 дней")
    val newNote = t("New Note", "Yangi eslatma", "Новая заметка")
    val noAdditionalText = t("No additional text", "Qo‘shimcha matn yo‘q", "Нет дополнительного текста")
    val noNotes = t("No Notes", "Eslatmalar yo‘q", "Нет заметок")
    val noResults = t("No Results", "Hech narsa topilmadi", "Нет результатов")

    val pinNote = t("Pin Note", "Eslatmani qadash", "Закрепить заметку")
    val unpinNote = t("Unpin Note", "Qadashni olib tashlash", "Открепить заметку")
    val move = t("Move", "Ko‘chirish", "Переместить")
    val share = t("Share", "Ulashish", "Поделиться")
    val delete = t("Delete", "O‘chirish", "Удалить")
    val recover = t("Recover", "Tiklash", "Восстановить")
    val deleteForever = t("Delete Permanently", "Butunlay o‘chirish", "Удалить навсегда")
    val deleteAll = t("Delete All", "Hammasini o‘chirish", "Удалить все")
    val deleteAllMsg = t(
        "These notes will be deleted. This action can’t be undone.",
        "Bu eslatmalar o‘chiriladi. Bu amalni ortga qaytarib bo‘lmaydi.",
        "Эти заметки будут удалены. Это действие нельзя отменить.",
    )
    val deletedInfo = t(
        "Notes are available here for 30 days. After that time, notes will be permanently deleted.",
        "Eslatmalar bu yerda 30 kun saqlanadi. Shundan so‘ng ular butunlay o‘chiriladi.",
        "Заметки доступны здесь 30 дней. После этого они будут удалены навсегда.",
    )
    val selectFolder = t("Select a folder", "Jildni tanlang", "Выберите папку")

    val viewAsGallery = t("View as Gallery", "Galereya ko‘rinishi", "Вид «Галерея»")
    val viewAsList = t("View as List", "Ro‘yxat ko‘rinishi", "Вид «Список»")
    val sortBy = t("Sort By", "Saralash", "Сортировка")
    val dateEdited = t("Date Edited", "Tahrir sanasi", "Дата изменения")
    val dateCreated = t("Date Created", "Yaratilgan sana", "Дата создания")
    val title = t("Title", "Sarlavha", "Название")

    val tags = t("Tags", "Teglar", "Теги")
    val format = t("Format", "Format", "Формат")
    val bulletedList = t("Bulleted List", "Belgili ro‘yxat", "Маркированный список")
    val numberedList = t("Numbered List", "Raqamli ro‘yxat", "Нумерованный список")
    val checklist = t("Checklist", "Nazorat ro‘yxati", "Чек-лист")
    val moveCheckedDown = t("Move Checked to Bottom", "Belgilanganlarni pastga", "Отмеченные вниз")
    val uncheckAll = t("Uncheck All", "Belgilarni olib tashlash", "Снять все отметки")
    val deleteChecked = t("Delete Checked Items", "Belgilanganlarni o‘chirish", "Удалить отмеченные")
    val undo = t("Undo", "Bekor qilish", "Отменить")
    val redo = t("Redo", "Qaytarish", "Повторить")
    val duplicate = t("Duplicate", "Nusxa olish", "Дублировать")
    fun wordsChars(w: Int, c: Int) = t("$w words · $c characters", "$w so‘z · $c belgi", "Слов: $w · Символов: $c")
    fun daysLeft(n: Long) = t(if (n == 1L) "1 day" else "$n days", "$n kun", "$n дн.")

    val widgetBlur = t("Blur Wallpaper Behind Widgets", "Widget orqasida obi-oy blur", "Размытие обоев под виджетами")
    val widgetBlurMsg = t(
        "Android only lets apps read the wallpaper with “All files access”. MROS Notes uses it just to draw a blurred wallpaper behind its widgets.",
        "Android obi-oyni faqat “Barcha fayllarga kirish” ruxsati bilan o‘qishga beradi. MROS Notes undan faqat widget orqasiga xiralashgan obi-oy chizish uchun foydalanadi.",
        "Android даёт читать обои только с разрешением «Доступ ко всем файлам». MROS Notes использует его только для размытых обоев под виджетами.",
    )
    val continueLabel = t("Continue", "Davom etish", "Продолжить")
    val notSupported = t("Needs Android 11 or newer.", "Android 11 yoki yangisi kerak.", "Нужен Android 11 или новее.")

    // updates
    val checkUpdates = t("Check for Updates", "Yangilanishlarni tekshirish", "Проверить обновления")
    val checking = t("Checking…", "Tekshirilmoqda…", "Проверка…")
    val updateAvailable = t("Update Available", "Yangi versiya bor", "Доступно обновление")
    val upToDate = t("You’re Up to Date", "Eng so‘nggi versiya o‘rnatilgan", "Установлена последняя версия")
    val updateNow = t("Update", "Yangilash", "Обновить")
    val downloading = t("Downloading…", "Yuklanmoqda…", "Загрузка…")
    val updateFailed = t("Couldn’t Check for Updates", "Yangilanishni tekshirib bo‘lmadi", "Не удалось проверить обновления")
    val downloadFailed = t("Download Failed", "Yuklab bo‘lmadi", "Ошибка загрузки")
    val noRepo = t(
        "This build doesn’t know its GitHub repository. Build it with GitHub Actions.",
        "Bu APK GitHub repozitoriyasini bilmaydi. Uni GitHub Actions orqali yig‘ing.",
        "Эта сборка не знает свой репозиторий GitHub. Соберите её через GitHub Actions.",
    )
    val allowInstall = t(
        "Allow installing apps from this source, then tap Update again.",
        "Ushbu manbadan ilova o‘rnatishga ruxsat bering, so‘ng yana “Yangilash”ni bosing.",
        "Разрешите установку приложений из этого источника и снова нажмите «Обновить».",
    )
    fun currentVersion(v: String) = t("Version $v", "Versiya $v", "Версия $v")
    fun newVersionMsg(newV: String, curV: String) = t(
        "Version $newV is available. You have $curV.",
        "$newV versiyasi chiqdi. Sizda $curV.",
        "Доступна версия $newV. У вас $curV.",
    )

    fun notesCount(n: Int): String = when (lang) {
        "uz" -> "$n ta eslatma"
        "ru" -> "$n " + ruPlural(n, "заметка", "заметки", "заметок")
        else -> if (n == 1) "1 Note" else "$n Notes"
    }

    private fun ruPlural(n: Int, one: String, few: String, many: String): String {
        val m10 = n % 10
        val m100 = n % 100
        return when {
            m10 == 1 && m100 != 11 -> one
            m10 in 2..4 && m100 !in 12..14 -> few
            else -> many
        }
    }
}

val LocalStrings = staticCompositionLocalOf { Strings("en") }
