package com.liquid.notes.data

const val DEFAULT_FOLDER = "notes"

data class Folder(
    val id: String,
    val name: String,
    val createdAt: Long,
)

data class Note(
    val id: String,
    val folderId: String,
    val content: String,
    val createdAt: Long,
    val modifiedAt: Long,
    val pinned: Boolean = false,
    val deletedAt: Long? = null,
    val remindAt: Long? = null,
)

enum class SortMode { Edited, Created, Title }

enum class ViewMode { Rows, Gallery }

data class AppData(
    val folders: List<Folder>,
    val notes: List<Note>,
    val sort: SortMode = SortMode.Edited,
    val view: ViewMode = ViewMode.Rows,
)

/** Which notes a list screen shows. */
sealed interface ListTarget {
    val key: String

    data object All : ListTarget {
        override val key: String get() = "all"
    }

    data object Deleted : ListTarget {
        override val key: String get() = "deleted"
    }

    data class InFolder(val id: String) : ListTarget {
        override val key: String get() = "f:$id"
    }

    data class Tag(val name: String) : ListTarget {
        override val key: String get() = "t:" + name.lowercase()
    }
}

/**
 * Note content is plain text. Checklist lines are stored markdown-style:
 * "- [ ] item" and "- [x] item".
 */
object NoteText {
    const val UNCHECKED = "- [ ] "
    const val CHECKED = "- [x] "
    const val BULLET = "• "

    /** #tags like iOS Notes: letters, digits, "_" and "-". */
    val TAG_REGEX = Regex("(?<![\\p{L}\\p{N}_#])#([\\p{L}\\p{N}_-]{1,40})")

    fun tags(content: String): List<String> =
        TAG_REGEX.findAll(content).map { it.groupValues[1] }.distinctBy { it.lowercase() }.toList()

    fun hasTag(content: String, tag: String): Boolean =
        TAG_REGEX.findAll(content).any { it.groupValues[1].equals(tag, ignoreCase = true) }

    fun isCheckLine(line: String): Boolean = line.startsWith(UNCHECKED) || line.startsWith(CHECKED)

    fun displayLine(line: String): String =
        if (isCheckLine(line)) line.substring(UNCHECKED.length) else line

    fun title(content: String): String? =
        content.lineSequence().map { displayLine(it).trim() }.firstOrNull { it.isNotEmpty() }

    fun preview(content: String): String? =
        content.lineSequence().map { displayLine(it).trim() }.filter { it.isNotEmpty() }.drop(1).firstOrNull()

    fun isBlank(content: String): Boolean = content.lineSequence().all { displayLine(it).isBlank() }

    /** Human readable text (for sharing / previews). */
    fun plain(content: String): String = content.lines().joinToString("\n") { line ->
        when {
            line.startsWith(CHECKED) -> "✓ " + line.substring(CHECKED.length)
            line.startsWith(UNCHECKED) -> "○ " + line.substring(UNCHECKED.length)
            else -> line
        }
    }

    /** Everything after the title line, as plain text. */
    fun body(content: String): String {
        val lines = plain(content).lines()
        val first = lines.indexOfFirst { it.isNotBlank() }
        if (first < 0) return ""
        return lines.drop(first + 1).joinToString("\n").trim()
    }
}
