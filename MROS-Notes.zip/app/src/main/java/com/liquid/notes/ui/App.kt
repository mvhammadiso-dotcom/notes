package com.liquid.notes.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.spring
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import com.liquid.notes.data.DEFAULT_FOLDER
import com.liquid.notes.data.ListTarget
import com.liquid.notes.data.NoteText
import com.liquid.notes.data.NotesStore
import com.liquid.notes.ui.glass.LocalBackdrop
import com.liquid.notes.ui.glass.backdropSource
import com.liquid.notes.ui.glass.liquidReveal
import com.liquid.notes.ui.glass.trackTouches
import com.liquid.notes.ui.glass.rememberBackdrop
import com.liquid.notes.ui.overlay.OverlayHost
import com.liquid.notes.ui.overlay.OverlayState
import com.liquid.notes.ui.screens.EditorScreen
import com.liquid.notes.ui.screens.FoldersScreen
import com.liquid.notes.ui.screens.NotesListScreen
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.update.UpdateController
import com.liquid.notes.util.LocalStrings
import kotlinx.coroutines.delay

@Composable
fun NotesRoot(
    store: NotesStore,
    sharedText: String?,
    newNote: Boolean = false,
    newChecklist: Boolean = false,
    openNoteId: String? = null,
) {
    val ios = LocalIos.current
    val s = LocalStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val holder = rememberSaveableStateHolder()
    val nav = remember {
        Navigator(listOf(Screen.Folders, Screen.Notes(ListTarget.InFolder(DEFAULT_FOLDER)))) { removed ->
            holder.removeState(removed.key)
            if (removed is Screen.Editor) store.discardIfEmpty(removed.noteId)
        }
    }
    val overlay = remember { OverlayState() }
    val updates = remember { UpdateController(context.applicationContext, overlay, s, scope) }
    val appBackdrop = rememberBackdrop()
    var sharedHandled by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(sharedText, newNote, newChecklist, openNoteId) {
        if (sharedHandled) return@LaunchedEffect
        when {
            !sharedText.isNullOrBlank() -> {
                sharedHandled = true
                val id = store.createNote(DEFAULT_FOLDER, sharedText)
                nav.push(Screen.Editor(id))
            }
            newNote -> {
                // launcher shortcut / widget "New Note"
                sharedHandled = true
                val id = store.createNote(DEFAULT_FOLDER)
                nav.push(Screen.Editor(id))
            }
            newChecklist -> {
                sharedHandled = true
                val id = store.createNote(DEFAULT_FOLDER, NoteText.UNCHECKED)
                nav.push(Screen.Editor(id))
            }
            openNoteId != null -> {
                // tapped a note in a widget
                sharedHandled = true
                val n = store.data.value.notes.find { it.id == openNoteId && it.deletedAt == null }
                if (n != null) nav.push(Screen.Editor(n.id))
            }
        }
    }
    // Quiet update check shortly after launch.
    LaunchedEffect(Unit) {
        delay(2500)
        updates.check(silent = true)
    }

    CompositionLocalProvider(
        LocalStore provides store,
        LocalNav provides nav,
        LocalOverlay provides overlay,
        LocalUpdates provides updates,
    ) {
        BackHandler(enabled = nav.canPop) { nav.pop() }
        Box(Modifier.fillMaxSize().trackTouches(nav.touch)) {
            Box(
                Modifier
                    .fillMaxSize()
                    .backdropSource(appBackdrop)
                    .background(ios.background),
            ) {
                AnimatedContent(
                    targetState = nav.current,
                    contentKey = { it.key },
                    transitionSpec = {
                        // The motion itself is drawn by liquidReveal / depth below.
                        (EnterTransition.None togetherWith ExitTransition.None).apply {
                            targetContentZIndex = if (nav.lastWasPush) 1f else -1f
                        }
                    },
                    label = "nav",
                ) { screen ->
                    val upper = if (nav.lastWasPush) screen == nav.current else screen != nav.current
                    val progress by transition.animateFloat(
                        transitionSpec = {
                            if (upper) {
                                spring<Float>(dampingRatio = 0.8f, stiffness = 165f)
                            } else {
                                spring<Float>(dampingRatio = 1f, stiffness = 220f)
                            }
                        },
                        label = "liquid",
                    ) { state -> if (state == EnterExitState.Visible) 1f else 0f }
                    val origin = nav.originOf(screen)
                    val layer = if (upper) {
                        Modifier.liquidReveal(progress = { progress }, origin = origin, rim = ios.accent)
                    } else {
                        Modifier
                            .graphicsLayer {
                                val sc = 0.93f + 0.07f * progress.coerceIn(0f, 1f)
                                scaleX = sc
                                scaleY = sc
                            }
                            .drawWithContent {
                                drawContent()
                                val dim = (1f - progress).coerceIn(0f, 1f)
                                if (dim > 0.01f) drawRect(Color.Black.copy(alpha = 0.22f * dim))
                            }
                    }
                    Box(Modifier.fillMaxSize().then(layer)) {
                        holder.SaveableStateProvider(screen.key) {
                            when (screen) {
                                Screen.Folders -> FoldersScreen()
                                is Screen.Notes -> NotesListScreen(screen.target)
                                is Screen.Editor -> EditorScreen(screen.noteId)
                            }
                        }
                    }
                }
            }
            CompositionLocalProvider(LocalBackdrop provides appBackdrop) {
                OverlayHost(overlay, appBackdrop)
            }
        }
    }
}
