package com.liquid.notes.ui

import androidx.compose.ui.unit.dp
import com.liquid.notes.ui.glass.drawLiquidSurface
import android.content.Context
import androidx.activity.compose.BackHandler
import com.liquid.notes.BuildConfig
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.spring
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import com.liquid.notes.data.DEFAULT_FOLDER
import com.liquid.notes.data.ListTarget
import com.liquid.notes.data.NoteText
import com.liquid.notes.data.NotesStore
import com.liquid.notes.ui.glass.LocalBackdrop
import com.liquid.notes.ui.glass.backdropSource
import com.liquid.notes.ui.glass.trackTouches
import com.liquid.notes.ui.glass.rememberBackdrop
import com.liquid.notes.ui.overlay.OverlayHost
import com.liquid.notes.ui.overlay.OverlayState
import com.liquid.notes.ui.screens.EditorScreen
import com.liquid.notes.ui.screens.FoldersScreen
import com.liquid.notes.ui.screens.InfoScreen
import com.liquid.notes.ui.screens.NotesListScreen
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.update.UpdateController
import com.liquid.notes.util.LocalStrings
import kotlinx.coroutines.delay

@Composable
fun NotesRoot(
    store: NotesStore,
    sharedText: String?,
    newNote: Boolean = false,
    newChecklist: Boolean = false,
    openNoteId: String? = null,
    checkUpdate: Boolean = false,
) {
    val ios = LocalIos.current
    val s = LocalStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val holder = rememberSaveableStateHolder()
    val nav = remember {
        Navigator(listOf(Screen.Folders, Screen.Notes(ListTarget.InFolder(DEFAULT_FOLDER)))) { removed ->
            holder.removeState(removed.key)
            if (removed is Screen.Editor) store.discardIfEmpty(removed.noteId)
        }
    }
    val overlay = remember { OverlayState().also { it.touch = nav.touch } }
    val updates = remember { UpdateController(context.applicationContext, overlay, s, scope) }
    val appBackdrop = rememberBackdrop()
    var sharedHandled by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(sharedText, newNote, newChecklist, openNoteId) {
        if (sharedHandled) return@LaunchedEffect
        when {
            !sharedText.isNullOrBlank() -> {
                sharedHandled = true
                val id = store.createNote(DEFAULT_FOLDER, sharedText)
                nav.push(Screen.Editor(id))
            }
            newNote -> {
                // launcher shortcut / widget "New Note"
                sharedHandled = true
                val id = store.createNote(DEFAULT_FOLDER)
                nav.push(Screen.Editor(id))
            }
            newChecklist -> {
                sharedHandled = true
                val id = store.createNote(DEFAULT_FOLDER, NoteText.UNCHECKED)
                nav.push(Screen.Editor(id))
            }
            openNoteId != null -> {
                // tapped a note in a widget
                sharedHandled = true
                val n = store.data.value.notes.find { it.id == openNoteId && it.deletedAt == null }
                if (n != null) nav.push(Screen.Editor(n.id))
            }
        }
    }
    // After every update (and on first install) explain what is new / how to use the app.
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("app", Context.MODE_PRIVATE)
        if (prefs.getString("seen_version", null) != BuildConfig.VERSION_NAME) {
            delay(700)
            overlay.whatsNew = true
            prefs.edit().putString("seen_version", BuildConfig.VERSION_NAME).apply()
        }
    }
    // Quiet update check shortly after launch (or a visible one when opened from the update notification).
    LaunchedEffect(Unit) {
        if (checkUpdate) {
            delay(500)
            updates.check(silent = false)
        } else {
            delay(2500)
            updates.check(silent = true)
        }
    }

    CompositionLocalProvider(
        LocalStore provides store,
        LocalNav provides nav,
        LocalOverlay provides overlay,
        LocalUpdates provides updates,
    ) {
        BackHandler(enabled = nav.canPop) { nav.pop() }
        Box(Modifier.fillMaxSize().trackTouches(nav.touch)) {
            Box(
                Modifier
                    .fillMaxSize()
                    .backdropSource(appBackdrop)
                    .background(ios.background),
            ) {
                AnimatedContent(
                    targetState = nav.current,
                    contentKey = { it.key },
                    transitionSpec = {
                        // The motion itself is drawn below: big windows rise like water, the one beneath sinks back.
                        (EnterTransition.None togetherWith ExitTransition.None).apply {
                            targetContentZIndex = if (nav.lastWasPush) 1f else -1f
                        }
                    },
                    label = "nav",
                ) { screen ->
                    val upper = if (nav.lastWasPush) screen == nav.current else screen != nav.current
                    val progress by transition.animateFloat(
                        transitionSpec = {
                            if (upper) {
                                spring<Float>(dampingRatio = 0.78f, stiffness = 230f)
                            } else {
                                spring<Float>(dampingRatio = 1f, stiffness = 260f)
                            }
                        },
                        label = "rise",
                    ) { state -> if (state == EnterExitState.Visible) 1f else 0f }
                    val originX = nav.originOf(screen)?.center?.x
                    val surface = if (screen is Screen.Editor) ios.editorBackground else ios.background
                    var heightPx by remember { mutableFloatStateOf(0f) }
                    val layer = if (upper) {
                        // full-screen windows rise like water: the layer only moves (cheap), the wave is a tiny overlay
                        Modifier
                            .onSizeChanged { heightPx = it.height.toFloat() }
                            .graphicsLayer {
                                val p = progress
                                val h = if (heightPx > 0f) heightPx else 3000f
                                translationY = h * (1f - p.coerceIn(0f, 1f))
                                alpha = if (p <= 0.002f) 0f else 1f
                            }
                    } else {
                        Modifier.graphicsLayer {
                            val sc = 0.94f + 0.06f * progress.coerceIn(0f, 1f)
                            scaleX = sc
                            scaleY = sc
                        }
                    }
                    Box(Modifier.fillMaxSize().then(layer)) {
                        holder.SaveableStateProvider(screen.key) {
                            when (screen) {
                                Screen.Folders -> FoldersScreen()
                                is Screen.Notes -> NotesListScreen(screen.target)
                                is Screen.Editor -> EditorScreen(screen.noteId)
                                Screen.Info -> InfoScreen()
                            }
                        }
                        // light overlay nodes: only these redraw each frame
                        if (upper) {
                            Box(
                                Modifier
                                    .matchParentSize()
                                    .graphicsLayer { } // own layer: redrawing the wave never re-records the screen
                                    .drawBehind { drawLiquidSurface(progress, originX, surface, ios.accent) },
                            )
                        } else {
                            Box(
                                Modifier
                                    .matchParentSize()
                                    .graphicsLayer { }
                                    .drawBehind {
                                        val dim = (1f - progress).coerceIn(0f, 1f)
                                        if (dim > 0.01f) drawRect(Color.Black.copy(alpha = 0.2f * dim))
                                    },
                            )
                        }
                    }
                }
            }
            CompositionLocalProvider(LocalBackdrop provides appBackdrop) {
                OverlayHost(overlay, appBackdrop)
            }
        }
    }
}
