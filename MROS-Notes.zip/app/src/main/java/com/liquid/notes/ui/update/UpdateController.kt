package com.liquid.notes.ui.update

import android.content.Context
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.liquid.notes.BuildConfig
import com.liquid.notes.data.ReleaseInfo
import com.liquid.notes.data.Updater
import com.liquid.notes.ui.overlay.AlertButton
import com.liquid.notes.ui.overlay.AlertRequest
import com.liquid.notes.ui.overlay.OverlayState
import com.liquid.notes.ui.overlay.ProgressRequest
import com.liquid.notes.util.Strings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/** "Check for Updates": GitHub Releases → download APK → system installer. */
@Stable
class UpdateController(
    private val context: Context,
    private val overlay: OverlayState,
    private val s: Strings,
    private val scope: CoroutineScope,
) {
    var checking by mutableStateOf(false)
        private set

    /** A newer release found by the last check (drives the red dot and the Info row). */
    var available by mutableStateOf<ReleaseInfo?>(null)
        private set

    val versionName: String get() = "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})"

    fun check(silent: Boolean) {
        val repo = BuildConfig.GITHUB_REPO
        if (repo.isBlank()) {
            if (!silent) overlay.message(s.updateFailed, s.noRepo, s.ok)
            return
        }
        if (checking) return
        checking = true
        scope.launch {
            try {
                val r = Updater.latest(repo)
                if (r.versionCode > BuildConfig.VERSION_CODE) {
                    available = r
                    offer(r)
                } else if (!silent) {
                    overlay.message(s.upToDate, s.currentVersion(versionName), s.ok)
                }
            } catch (e: Exception) {
                if (!silent) overlay.message(s.updateFailed, e.message, s.ok)
            } finally {
                checking = false
            }
        }
    }

    private fun offer(r: ReleaseInfo) {
        val notes = r.notes.take(400)
        val msg = s.newVersionMsg(r.versionName, versionName) + if (notes.isNotBlank()) "\n\n$notes" else ""
        overlay.alert = AlertRequest(
            title = s.updateAvailable,
            message = msg,
            buttons = listOf(
                AlertButton(s.later) { },
                AlertButton(s.updateNow, bold = true) { download(r) },
            ),
        )
    }

    private fun download(r: ReleaseInfo) {
        if (!Updater.canInstall(context)) {
            overlay.alert = AlertRequest(
                title = s.updateAvailable,
                message = s.allowInstall,
                buttons = listOf(
                    AlertButton(s.cancel) { },
                    AlertButton(s.ok, bold = true) { Updater.openInstallPermission(context) },
                ),
            )
            return
        }
        overlay.progress = ProgressRequest(s.downloading, 0f)
        scope.launch {
            try {
                val file = Updater.download(context, r.apkUrl) { v ->
                    overlay.progress = ProgressRequest(s.downloading, v)
                }
                overlay.progress = null
                Updater.install(context, file)
            } catch (e: Exception) {
                overlay.progress = null
                overlay.message(s.downloadFailed, e.message, s.ok)
            }
        }
    }
}
