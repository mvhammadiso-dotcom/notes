package com.liquid.notes.ui.components

import android.content.Context
import androidx.compose.animation.core.Animatable
import com.liquid.notes.ui.glass.GlassSurface
import androidx.compose.ui.zIndex
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liquid.notes.data.DEFAULT_FOLDER
import com.liquid.notes.data.Note
import com.liquid.notes.data.NoteText
import com.liquid.notes.data.NotesStore
import com.liquid.notes.ui.LocalNav
import com.liquid.notes.ui.LocalOverlay
import com.liquid.notes.ui.LocalStore
import com.liquid.notes.ui.Navigator
import com.liquid.notes.ui.Screen
import com.liquid.notes.ui.glass.BoundsHolder
import com.liquid.notes.ui.glass.trackBounds
import com.liquid.notes.ui.icons.Sf
import com.liquid.notes.ui.overlay.MenuAction
import com.liquid.notes.ui.overlay.MenuGroup
import com.liquid.notes.ui.overlay.MenuRequest
import com.liquid.notes.ui.overlay.OverlayState
import com.liquid.notes.ui.overlay.SheetItem
import com.liquid.notes.ui.overlay.SheetRequest
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.theme.TS
import com.liquid.notes.util.Dates
import com.liquid.notes.util.LocalStrings
import com.liquid.notes.util.Strings
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Everything you can do to a note from a list (swipe, context menu, move sheet). */
class NoteActions(
    private val store: NotesStore,
    private val overlay: OverlayState,
    private val nav: Navigator,
    private val s: Strings,
    private val context: Context,
) {
    fun open(n: Note, from: Rect? = null) = nav.push(Screen.Editor(n.id), from)
    fun togglePin(n: Note) = store.togglePin(n.id)
    fun delete(n: Note) = store.deleteNote(n.id)
    fun recover(n: Note) = store.recoverNote(n.id)
    fun deleteForever(n: Note) = store.deleteForever(n.id)
    fun share(n: Note) = shareText(context, NoteText.plain(n.content))

    fun folderName(id: String): String =
        if (id == DEFAULT_FOLDER) s.notes else store.data.value.folders.find { it.id == id }?.name ?: s.notes

    fun move(n: Note) {
        val folders = store.data.value.folders
            .filter { it.id != DEFAULT_FOLDER }
            .sortedBy { it.name.lowercase() }
        val items = buildList {
            add(SheetItem(s.notes, Sf.Folder, n.folderId == DEFAULT_FOLDER) { store.moveNote(n.id, DEFAULT_FOLDER) })
            folders.forEach { f ->
                add(SheetItem(f.name, Sf.Folder, n.folderId == f.id) { store.moveNote(n.id, f.id) })
            }
        }
        overlay.sheet = SheetRequest(s.selectFolder, items)
    }

    fun contextMenu(n: Note, anchor: Rect, deletedMode: Boolean, previewWidthPx: Float, density: Float) {
        val widthDp = (maxOf(anchor.width, previewWidthPx) / density).dp
        val groups = if (deletedMode) {
            listOf(
                MenuGroup(
                    null,
                    listOf(
                        MenuAction(s.recover, Sf.Restore) { recover(n) },
                        MenuAction(s.deleteForever, Sf.Trash, destructive = true) { deleteForever(n) },
                    ),
                ),
            )
        } else {
            listOf(
                MenuGroup(
                    null,
                    listOf(
                        MenuAction(if (n.pinned) s.unpinNote else s.pinNote, if (n.pinned) Sf.PinSlash else Sf.Pin) { togglePin(n) },
                        MenuAction(s.share, Sf.Share) { share(n) },
                        MenuAction(s.move, Sf.Folder) { move(n) },
                        MenuAction(s.duplicate, Sf.Duplicate) { store.duplicateNote(n.id) },
                    ),
                ),
                MenuGroup(null, listOf(MenuAction(s.delete, Sf.Trash, destructive = true) { delete(n) })),
            )
        }
        overlay.menu = MenuRequest(
            anchor = anchor,
            groups = groups,
            alignEnd = false,
            preview = { NotePreviewCard(n, widthDp) },
        )
    }
}

@Composable
fun rememberNoteActions(): NoteActions {
    val store = LocalStore.current
    val overlay = LocalOverlay.current
    val nav = LocalNav.current
    val s = LocalStrings.current
    val context = LocalContext.current
    return remember(store, overlay, nav, s, context) { NoteActions(store, overlay, nav, s, context) }
}

class SwipeAction(val icon: ImageVector, val color: Color, val onClick: () -> Unit)

/** iOS-style swipe actions + tap/long-press with row highlight. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SwipeRow(
    id: Any,
    openId: MutableState<Any?>,
    leading: List<SwipeAction>,
    trailing: List<SwipeAction>,
    onClick: () -> Unit,
    onLongPress: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable (pressed: Boolean) -> Unit,
) {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val offset = remember { Animatable(0f) }
    var widthPx by remember { mutableIntStateOf(0) }
    // revealed width for n separate glass buttons: pad + n*size + (n-1)*gap + pad
    fun revealPx(n: Int): Float = with(density) { (ACTION_SIZE * n + ACTION_GAP * (n - 1) + ACTION_PAD * 2).toPx() }
    val curLeading by rememberUpdatedState(leading)
    val curTrailing by rememberUpdatedState(trailing)
    val curClick by rememberUpdatedState(onClick)
    val curLong by rememberUpdatedState(onLongPress)
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val settleSpec = spring<Float>(dampingRatio = 0.62f, stiffness = 380f)
    val haptic = LocalHapticFeedback.current
    var armed by remember { mutableStateOf(false) }

    LaunchedEffect(openId.value) {
        if (openId.value != id && offset.value != 0f) offset.animateTo(0f, settleSpec)
    }

    fun close() {
        scope.launch { offset.animateTo(0f, settleSpec) }
        if (openId.value == id) openId.value = null
    }

    fun settle() {
        armed = false
        val w = widthPx.toFloat().coerceAtLeast(1f)
        val v = offset.value
        val maxLeft = if (curTrailing.isEmpty()) 0f else -revealPx(curTrailing.size)
        val maxRight = if (curLeading.isEmpty()) 0f else revealPx(curLeading.size)
        scope.launch {
            when {
                curTrailing.isNotEmpty() && v < -w * 0.62f -> {
                    offset.animateTo(-w, tween(160))
                    curTrailing.last().onClick()
                    offset.snapTo(0f)
                    openId.value = null
                }
                curLeading.isNotEmpty() && v > w * 0.5f -> {
                    curLeading.first().onClick()
                    offset.animateTo(0f, settleSpec)
                    openId.value = null
                }
                curTrailing.isNotEmpty() && v < maxLeft / 2f -> offset.animateTo(maxLeft, settleSpec)
                curLeading.isNotEmpty() && v > maxRight / 2f -> offset.animateTo(maxRight, settleSpec)
                else -> {
                    offset.animateTo(0f, settleSpec)
                    if (openId.value == id) openId.value = null
                }
            }
        }
    }

    Box(
        modifier
            .fillMaxWidth()
            .onSizeChanged { widthPx = it.width },
    ) {
        val v = offset.value
        // separate Liquid Glass buttons revealed behind the row
        Box(Modifier.matchParentSize()) {
            if (v < 0f && trailing.isNotEmpty()) {
                GlassActions(trailing, revealedPx = -v, alignEnd = true, stretch = armed) { a ->
                    close()
                    a.onClick()
                }
            }
            if (v > 0f && leading.isNotEmpty()) {
                GlassActions(leading, revealedPx = v, alignEnd = false, stretch = armed) { a ->
                    close()
                    a.onClick()
                }
            }
        }
        Box(
            Modifier
                .offset { IntOffset(offset.value.roundToInt(), 0) }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragStart = { openId.value = id },
                        onDragEnd = { settle() },
                        onDragCancel = { settle() },
                    ) { change, amount ->
                        change.consume()
                        val w = widthPx.toFloat()
                        val min = if (curTrailing.isEmpty()) 0f else -w
                        val max = if (curLeading.isEmpty()) 0f else w
                        val target = (offset.value + amount).coerceIn(min, max)
                        // tick when the full-swipe threshold is crossed
                        val armedNow = (curTrailing.isNotEmpty() && target < -w * 0.62f) ||
                            (curLeading.isNotEmpty() && target > w * 0.5f)
                        if (armedNow != armed) {
                            armed = armedNow
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        }
                        scope.launch { offset.snapTo(target) }
                    }
                }
                .combinedClickable(
                    interactionSource = src,
                    indication = null,
                    onLongClick = { if (offset.value == 0f) curLong() },
                    onClick = { if (offset.value != 0f) close() else curClick() },
                ),
        ) {
            content(pressed && v == 0f)
        }
    }
}

private val ACTION_SIZE = 50.dp
private val ACTION_GAP = 10.dp
private val ACTION_PAD = 10.dp

/**
 * Swipe actions as separate glass drops. The one nearest the edge pops out first;
 * on a full swipe it stretches into a long capsule (like iOS) while the others fade.
 */
@Composable
private fun BoxScope.GlassActions(
    actions: List<SwipeAction>,
    revealedPx: Float,
    alignEnd: Boolean,
    stretch: Boolean,
    onAction: (SwipeAction) -> Unit,
) {
    val density = LocalDensity.current
    val n = actions.size
    val sizePx = with(density) { ACTION_SIZE.toPx() }
    val slotPx = with(density) { (ACTION_SIZE + ACTION_GAP).toPx() }
    val padPx = with(density) { ACTION_PAD.toPx() }
    val revealedDp = with(density) { revealedPx.toDp() }
    val stretchAmount by animateFloatAsState(if (stretch) 1f else 0f, spring(dampingRatio = 0.7f, stiffness = 380f), label = "stretch")
    actions.forEachIndexed { i, a ->
        val order = if (alignEnd) n - 1 - i else i // 0 = nearest the screen edge
        val appear = ((revealedPx - padPx - order * slotPx) / sizePx).coerceIn(0f, 1f)
        val edge = order == 0
        val target = if (stretch && edge) (revealedDp - ACTION_PAD * 2).coerceAtLeast(ACTION_SIZE) else ACTION_SIZE
        val width by animateDpAsState(target, spring(dampingRatio = 0.62f, stiffness = 420f), label = "actionWidth")
        val shift = ACTION_PAD + (ACTION_SIZE + ACTION_GAP) * order
        GlassActionButton(
            a = a,
            appear = appear,
            width = width,
            dim = if (edge) 1f else 1f - stretchAmount,
            modifier = Modifier
                .zIndex(if (edge) 1f else 0f)
                .align(if (alignEnd) Alignment.CenterEnd else Alignment.CenterStart)
                .offset(x = if (alignEnd) -shift else shift),
        ) { onAction(a) }
    }
}

@Composable
private fun GlassActionButton(
    a: SwipeAction,
    appear: Float,
    width: Dp,
    dim: Float,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    // pops like a bubble once it is mostly revealed
    val pop by animateFloatAsState(
        targetValue = if (appear > 0.55f) 1f else appear * 0.75f,
        animationSpec = spring(dampingRatio = 0.4f, stiffness = 520f),
        label = "actionPop",
    )
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    GlassSurface(
        modifier = modifier
            .graphicsLayer {
                scaleX = pop
                scaleY = pop
                alpha = (appear * 1.6f).coerceIn(0f, 1f) * dim.coerceIn(0f, 1f)
            }
            .width(width)
            .height(ACTION_SIZE)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        corner = ACTION_SIZE / 2,
        tint = a.color.copy(alpha = 0.94f),
        pressed = pressed,
        lens = false,
        elevation = 5.dp,
        backdrop = null,
    ) {
        Icon(a.icon, null, Modifier.size(21.dp), tint = Color.White)
    }
}

/** A note in an inset-grouped list. */
@Composable
fun NoteListRow(
    note: Note,
    pos: GroupPos,
    openId: MutableState<Any?>,
    actions: NoteActions,
    deletedMode: Boolean,
    showFolder: Boolean,
    modifier: Modifier = Modifier,
) {
    val ios = LocalIos.current
    val s = LocalStrings.current
    val density = LocalDensity.current
    val bounds = remember { BoundsHolder() }
    val title = NoteText.title(note.content) ?: s.newNote
    val preview = NoteText.preview(note.content) ?: s.noAdditionalText
    val deletedAt = note.deletedAt
    val date = if (deletedMode && deletedAt != null) {
        s.daysLeft((30L - Dates.daysAgo(deletedAt)).coerceAtLeast(0L))
    } else {
        Dates.rowDate(note.modifiedAt, s)
    }
    val previewMin = with(density) { 300.dp.toPx() }
    val leading = if (deletedMode) {
        listOf(SwipeAction(Sf.Restore, ios.accent) { actions.recover(note) })
    } else {
        listOf(SwipeAction(if (note.pinned) Sf.PinSlash else Sf.PinFill, ios.orange) { actions.togglePin(note) })
    }
    val trailing = if (deletedMode) {
        listOf(SwipeAction(Sf.Trash, ios.red) { actions.deleteForever(note) })
    } else {
        listOf(
            SwipeAction(Sf.FolderFill, ios.purple) { actions.move(note) },
            SwipeAction(Sf.Trash, ios.red) { actions.delete(note) },
        )
    }
    SwipeRow(
        id = note.id,
        openId = openId,
        leading = leading,
        trailing = trailing,
        onClick = {
            if (deletedMode) {
                actions.contextMenu(note, bounds.rect, true, previewMin, density.density)
            } else {
                actions.open(note, bounds.rect)
            }
        },
        onLongPress = { actions.contextMenu(note, bounds.rect, deletedMode, previewMin, density.density) },
        modifier = modifier
            .clip(groupShape(pos))
            .trackBounds(bounds),
    ) { pressed ->
        Column(Modifier.fillMaxWidth().background(if (pressed) ios.pressed else ios.card)) {
            Column(Modifier.padding(start = 20.dp, end = 18.dp, top = 11.dp, bottom = 11.dp)) {
                Text(title, style = TS.headline, color = ios.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(date, style = TS.subhead, color = ios.label, maxLines = 1)
                    Spacer(Modifier.width(7.dp))
                    Text(
                        preview,
                        style = TS.subhead,
                        color = ios.secondaryLabel,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (showFolder) {
                    Spacer(Modifier.height(3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Sf.Folder, null, Modifier.size(14.dp), tint = ios.secondaryLabel)
                        Spacer(Modifier.width(4.dp))
                        Text(actions.folderName(note.folderId), style = TS.footnote, color = ios.secondaryLabel, maxLines = 1)
                    }
                }
            }
            if (pos.hasDivider) Hairline(start = 20.dp)
        }
    }
}

/** Gallery view thumbnail. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GalleryCell(note: Note, actions: NoteActions, deletedMode: Boolean, modifier: Modifier = Modifier) {
    val ios = LocalIos.current
    val s = LocalStrings.current
    val density = LocalDensity.current
    val bounds = remember { BoundsHolder() }
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.96f else 1f, label = "cell")
    val previewMin = with(density) { 300.dp.toPx() }
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .fillMaxWidth()
            .padding(bottom = 14.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .combinedClickable(
                interactionSource = src,
                indication = null,
                onLongClick = { actions.contextMenu(note, bounds.rect, deletedMode, previewMin, density.density) },
                onClick = {
                    if (deletedMode) {
                        actions.contextMenu(note, bounds.rect, true, previewMin, density.density)
                    } else {
                        actions.open(note, bounds.rect)
                    }
                },
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(0.84f)
                .trackBounds(bounds)
                .clip(shape)
                .background(ios.card)
                .border(0.6.dp, ios.separator, shape)
                .padding(10.dp),
        ) {
            Column {
                Text(
                    NoteText.title(note.content) ?: s.newNote,
                    fontSize = 9.5.sp,
                    lineHeight = 12.sp,
                    color = ios.label,
                    style = TS.headline,
                    maxLines = 2,
                    overflow = TextOverflow.Clip,
                )
                Text(
                    NoteText.body(note.content).take(500),
                    fontSize = 8.sp,
                    lineHeight = 10.5.sp,
                    color = ios.label,
                    style = TS.footnote,
                    overflow = TextOverflow.Clip,
                )
            }
            if (note.pinned) {
                Icon(Sf.PinFill, null, Modifier.align(Alignment.TopEnd).size(12.dp), tint = ios.orange)
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(
            NoteText.title(note.content) ?: s.newNote,
            style = TS.footnote.copy(fontWeight = TS.headline.fontWeight),
            color = ios.label,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
        Text(Dates.rowDate(note.modifiedAt, s), style = TS.caption, color = ios.secondaryLabel, maxLines = 1)
    }
}
