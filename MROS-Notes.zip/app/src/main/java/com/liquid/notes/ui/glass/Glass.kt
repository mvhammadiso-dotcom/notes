package com.liquid.notes.ui.glass

import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.theme.TS

/*
 * Liquid Glass for Android.
 *
 * A "Backdrop" records whatever is drawn under the glass into a GraphicsLayer (RenderNode).
 * Every glass shape then re-draws that layer (offset to its own position) through a RenderEffect chain:
 *   blur  ->  saturation boost  ->  AGSL lens that bends the image near the rounded edges (Android 13+).
 * On top come a translucent tint, a top sheen and a specular rim. Android 8–11 falls back to frosted fill.
 */

val glassSupported: Boolean get() = Build.VERSION.SDK_INT >= 31

@Stable
class Backdrop internal constructor(val layer: GraphicsLayer) {
    var origin by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberBackdrop(): Backdrop {
    val layer = rememberGraphicsLayer()
    return remember(layer) { Backdrop(layer) }
}

val LocalBackdrop = compositionLocalOf<Backdrop?> { null }

/** Marks the content that glass placed above it should refract. Put the background *after* this modifier. */
fun Modifier.backdropSource(backdrop: Backdrop): Modifier = this
    .onGloballyPositioned { backdrop.origin = it.positionInRoot() }
    .drawWithContent {
        backdrop.layer.record { this@drawWithContent.drawContent() }
        drawLayer(backdrop.layer)
    }

class BoundsHolder {
    var rect: Rect = Rect.Zero
}

fun Modifier.trackBounds(holder: BoundsHolder): Modifier =
    this.onGloballyPositioned { holder.rect = it.boundsInRoot() }

private const val LENS_SHADER = """
uniform shader content;
uniform float2 size;
uniform float radius;
uniform float depth;
uniform float strength;
uniform float zoom;
uniform float chroma;

float sdRoundRect(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + float2(r, r);
    return min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0, 0.0))) - r;
}

half4 main(float2 coord) {
    float2 hs = size * 0.5;
    float2 p = coord - hs;
    float d = sdRoundRect(p, hs, radius);
    float t = clamp(1.0 + d / depth, 0.0, 1.0);
    float e = 1.5;
    float dx = sdRoundRect(p + float2(e, 0.0), hs, radius) - sdRoundRect(p - float2(e, 0.0), hs, radius);
    float dy = sdRoundRect(p + float2(0.0, e), hs, radius) - sdRoundRect(p - float2(0.0, e), hs, radius);
    float2 g = float2(dx, dy);
    float2 n = g / max(length(g), 0.0001);
    float k = t * t * t;
    float2 lo = float2(0.5, 0.5);
    float2 hi = size - float2(0.5, 0.5);
    float2 base = hs + p * zoom - n * (k * strength);
    float2 ca = n * (k * chroma);
    float4 cg = float4(content.eval(clamp(base, lo, hi)));
    float cr = float4(content.eval(clamp(base - ca, lo, hi))).r;
    float cb = float4(content.eval(clamp(base + ca, lo, hi))).b;
    float rim = smoothstep(0.55, 1.0, t);
    float3 col = float3(cr, cg.g, cb) * (1.0 + 0.12 * rim);
    col = min(col, float3(cg.a, cg.a, cg.a));
    return half4(float4(col, cg.a));
}
"""

private object GlassFx {
    fun build(
        size: IntSize,
        blurPx: Float,
        saturation: Float,
        cornerPx: Float?,
        depthPx: Float,
        strengthPx: Float,
        zoom: Float,
        chromaPx: Float,
        shader: Any?,
    ): RenderEffect? {
        if (Build.VERSION.SDK_INT < 31) return null
        if (size.width <= 0 || size.height <= 0) return null
        val base = Api31.blurSaturate(blurPx.coerceAtLeast(1f), saturation)
        val lensed = if (cornerPx != null && shader != null && Build.VERSION.SDK_INT >= 33) {
            Api33.lens(shader, size.width.toFloat(), size.height.toFloat(), cornerPx, depthPx, strengthPx, zoom, chromaPx, base)
        } else {
            null
        }
        return (lensed ?: base).asComposeRenderEffect()
    }
}

@RequiresApi(31)
private object Api31 {
    fun blurSaturate(blurPx: Float, saturation: Float): android.graphics.RenderEffect {
        val blur = android.graphics.RenderEffect.createBlurEffect(blurPx, blurPx, Shader.TileMode.CLAMP)
        if (saturation == 1f) return blur
        val cm = ColorMatrix()
        cm.setSaturation(saturation)
        return android.graphics.RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(cm), blur)
    }
}

@RequiresApi(33)
private object Api33 {
    fun newShader(): Any? = try {
        RuntimeShader(LENS_SHADER)
    } catch (t: Throwable) {
        null
    }

    fun lens(
        shaderAny: Any,
        w: Float,
        h: Float,
        corner: Float,
        depth: Float,
        strength: Float,
        zoom: Float,
        chroma: Float,
        input: android.graphics.RenderEffect,
    ): android.graphics.RenderEffect? = try {
        val s = shaderAny as RuntimeShader
        s.setFloatUniform("size", w, h)
        s.setFloatUniform("radius", corner.coerceAtMost(minOf(w, h) / 2f))
        s.setFloatUniform("depth", depth.coerceAtLeast(1f))
        s.setFloatUniform("strength", strength)
        s.setFloatUniform("zoom", zoom)
        s.setFloatUniform("chroma", chroma)
        val lens = android.graphics.RenderEffect.createRuntimeShaderEffect(s, "content")
        android.graphics.RenderEffect.createChainEffect(lens, input)
    } catch (t: Throwable) {
        null
    }
}

/** Draws the backdrop under this element, blurred (and lensed). Renders nothing below Android 12. */
@Composable
fun BackdropLayer(
    backdrop: Backdrop,
    modifier: Modifier = Modifier,
    blur: Dp = 14.dp,
    saturation: Float = 1.6f,
    lensCorner: Dp? = null,
    lensDepth: Dp = 18.dp,
    lensStrength: Dp = 12.dp,
    lensZoom: Float = 1f,
    lensChroma: Dp = 0.dp,
) {
    if (!glassSupported) return
    val density = LocalDensity.current
    var pos by remember { mutableStateOf(Offset.Zero) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    val wantsLens = lensCorner != null
    val shader: Any? = remember(wantsLens) {
        if (wantsLens && Build.VERSION.SDK_INT >= 33) Api33.newShader() else null
    }
    val effect = remember(size, blur, saturation, lensCorner, lensDepth, lensStrength, lensZoom, lensChroma, shader, density) {
        with(density) {
            GlassFx.build(
                size = size,
                blurPx = blur.toPx(),
                saturation = saturation,
                cornerPx = lensCorner?.toPx(),
                depthPx = lensDepth.toPx(),
                strengthPx = lensStrength.toPx(),
                zoom = lensZoom,
                chromaPx = lensChroma.toPx(),
                shader = shader,
            )
        }
    }
    Box(
        modifier
            .onSizeChanged { size = it }
            .onGloballyPositioned { pos = it.positionInRoot() }
            .graphicsLayer {
                renderEffect = effect
                clip = true
            }
            .drawBehind {
                val o = pos - backdrop.origin
                translate(-o.x, -o.y) {
                    drawLayer(backdrop.layer)
                }
            },
    )
}

/** Button = a fat water drop (strong rim, sheen, caustic). Panel = calmer glass for menus and sheets. */
enum class GlassStyle { Button, Panel }

/**
 * The Liquid Glass material, drawn in layers:
 * refracted backdrop → body gradient → inner edge shading (drop thickness) → glare → specular top rim
 * → caustic bottom rim → outer hairline. Pressing makes it wobble like a drop of water.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    corner: Dp = 22.dp,
    tint: Color? = null,
    pressed: Boolean = false,
    lens: Boolean = true,
    blur: Dp = 12.dp,
    elevation: Dp = 12.dp,
    style: GlassStyle = GlassStyle.Button,
    backdrop: Backdrop? = LocalBackdrop.current,
    contentAlignment: Alignment = Alignment.Center,
    content: @Composable BoxScope.() -> Unit,
) {
    val ios = LocalIos.current
    val glassShape = RoundedCornerShape(corner)
    val panel = style == GlassStyle.Panel
    // squash & stretch: X and Y springs are out of phase, so the release wobbles like jelly/water
    val sx by animateFloatAsState(
        targetValue = if (pressed) 1.11f else 1f,
        animationSpec = spring(dampingRatio = 0.34f, stiffness = 460f),
        label = "glassSx",
    )
    val sy by animateFloatAsState(
        targetValue = if (pressed) 1.05f else 1f,
        animationSpec = spring(dampingRatio = 0.4f, stiffness = 320f),
        label = "glassSy",
    )
    val glow by animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = spring(stiffness = 650f),
        label = "glassGlow",
    )
    val live = backdrop != null && glassSupported
    val bodyTop: Color
    val bodyBottom: Color
    when {
        tint != null -> {
            bodyTop = lerp(tint, Color.White, if (ios.dark) 0.18f else 0.32f)
            bodyBottom = tint
        }
        panel -> {
            bodyTop = lerp(ios.glassMenuTint, ios.glassTop, 0.35f)
            bodyBottom = ios.glassMenuTint
        }
        else -> {
            bodyTop = ios.glassTop
            bodyBottom = ios.glassBottom
        }
    }
    // without real blur (Android 8–11) the glass must be nearly opaque to stay readable
    val top = if (live) bodyTop else bodyTop.copy(alpha = maxOf(bodyTop.alpha, 0.95f))
    val bottom = if (live) bodyBottom else bodyBottom.copy(alpha = maxOf(bodyBottom.alpha, 0.95f))
    val edgeStrength = if (panel) 0.45f else 1f
    Box(
        modifier
            .graphicsLayer {
                scaleX = sx
                scaleY = sy
            }
            .then(
                if (elevation > 0.dp) {
                    Modifier.shadow(
                        elevation = elevation,
                        shape = glassShape,
                        clip = false,
                        ambientColor = ios.shadowAmbient,
                        spotColor = ios.shadowSpot,
                    )
                } else {
                    Modifier
                },
            )
            .clip(glassShape),
        contentAlignment = contentAlignment,
    ) {
        if (backdrop != null && live) {
            BackdropLayer(
                backdrop = backdrop,
                modifier = Modifier.matchParentSize(),
                blur = blur,
                lensCorner = if (lens) corner else null,
                lensZoom = if (panel) 1f else 0.9f,
                lensChroma = if (panel) 0.dp else 1.2.dp,
            )
        }
        Box(
            Modifier
                .matchParentSize()
                .drawWithCache {
                    val hair = 1.dp.toPx()
                    val r = minOf(corner.toPx(), size.minDimension / 2f)
                    val body = Brush.verticalGradient(listOf(top, bottom))
                    val spec = Brush.verticalGradient(0f to ios.glassSpecular, 0.45f to Color.Transparent)
                    val caustic = Brush.verticalGradient(0.45f to Color.Transparent, 1f to ios.glassCaustic)
                    val glare = Brush.radialGradient(
                        colors = listOf(ios.glassSpecular.copy(alpha = ios.glassGlare), Color.Transparent),
                        center = Offset(size.width * 0.32f, size.height * 0.1f),
                        radius = (size.minDimension * 0.7f).coerceAtLeast(1f),
                    )
                    val sw = hair * 1.5f
                    val si = hair * 0.7f + sw / 2f
                    onDrawBehind {
                        drawRoundRect(brush = body, cornerRadius = CornerRadius(r, r))
                        // inner edge shading = the "thickness" of the drop
                        for (i in 0 until 3) {
                            val w = hair * (1.3f + i * 1.8f)
                            val inset = w / 2f
                            drawRoundRect(
                                color = ios.glassEdge.copy(alpha = ios.glassEdge.alpha * edgeStrength * (1f - i * 0.3f)),
                                topLeft = Offset(inset, inset),
                                size = Size(size.width - w, size.height - w),
                                cornerRadius = CornerRadius((r - inset).coerceAtLeast(0f)),
                                style = Stroke(width = w),
                            )
                        }
                        if (!panel) drawRect(brush = glare)
                        val rimSize = Size(size.width - 2 * si, size.height - 2 * si)
                        val rimCorner = CornerRadius((r - si).coerceAtLeast(0f))
                        drawRoundRect(brush = spec, topLeft = Offset(si, si), size = rimSize, cornerRadius = rimCorner, style = Stroke(width = sw))
                        drawRoundRect(brush = caustic, topLeft = Offset(si, si), size = rimSize, cornerRadius = rimCorner, style = Stroke(width = sw * 1.25f))
                        drawRoundRect(
                            color = ios.glassOutline,
                            topLeft = Offset(hair / 2f, hair / 2f),
                            size = Size(size.width - hair, size.height - hair),
                            cornerRadius = CornerRadius((r - hair / 2f).coerceAtLeast(0f)),
                            style = Stroke(width = hair),
                        )
                    }
                },
        )
        if (glow > 0.01f) {
            Box(
                Modifier
                    .matchParentSize()
                    .drawBehind {
                        drawRect(
                            brush = Brush.radialGradient(
                                colors = listOf(ios.glassPress.copy(alpha = ios.glassPress.alpha * glow), Color.Transparent),
                                center = center,
                                radius = (size.maxDimension * (0.35f + 0.45f * glow)).coerceAtLeast(1f),
                            ),
                        )
                    },
            )
        }
        content()
    }
}

/** Round glass button (back, compose, ellipsis…). */
@Composable
fun GlassCircleButton(
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    iconSize: Dp = 21.dp,
    prominent: Boolean = false,
    iconTint: Color? = null,
    bounds: BoundsHolder? = null,
    contentDescription: String? = null,
) {
    val ios = LocalIos.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    GlassSurface(
        modifier = modifier
            .size(size)
            .then(if (bounds != null) Modifier.trackBounds(bounds) else Modifier)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        corner = size / 2,
        tint = if (prominent) ios.accent.copy(alpha = 0.94f) else null,
        pressed = pressed,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            modifier = Modifier.size(iconSize),
            tint = iconTint ?: if (prominent) ios.onAccent else ios.accent,
        )
    }
}

/** Capsule glass button with a text label ("Edit", "Done"). */
@Composable
fun GlassTextButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    bold: Boolean = false,
) {
    val ios = LocalIos.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    GlassSurface(
        modifier = modifier
            .height(44.dp)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        corner = 22.dp,
        pressed = pressed,
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 16.dp),
            style = TS.body.copy(fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Medium),
            color = ios.accent,
            maxLines = 1,
        )
    }
}

/** Glass capsule holding several icon buttons. */
@Composable
fun GlassPill(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    GlassSurface(modifier = modifier.height(44.dp), corner = 22.dp) {
        Row(Modifier.padding(horizontal = 3.dp), verticalAlignment = Alignment.CenterVertically) {
            content()
        }
    }
}

@Composable
fun PillButton(
    icon: ImageVector,
    onClick: () -> Unit,
    bounds: BoundsHolder? = null,
    iconSize: Dp = 20.dp,
    tint: Color = LocalIos.current.accent,
    enabled: Boolean = true,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val a by animateFloatAsState(if (pressed) 1f else 0f, label = "pill")
    val dim by animateFloatAsState(if (enabled) 1f else 0.32f, label = "pillEnabled")
    Box(
        Modifier
            .size(width = 42.dp, height = 44.dp)
            .then(if (bounds != null) Modifier.trackBounds(bounds) else Modifier)
            .graphicsLayer {
                alpha = dim
                val sc = 1f + 0.12f * a
                scaleX = sc
                scaleY = sc
            }
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(36.dp)
                .graphicsLayer { alpha = a }
                .clip(CircleShape)
                .background(LocalIos.current.glassPress),
        )
        Icon(icon, contentDescription = null, modifier = Modifier.size(iconSize), tint = tint)
    }
}

/** Text label inside a glass pill (the editor's "Aa"). */
@Composable
fun PillTextButton(
    text: String,
    onClick: () -> Unit,
    bounds: BoundsHolder? = null,
) {
    val ios = LocalIos.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val a by animateFloatAsState(if (pressed) 1f else 0f, label = "pillText")
    Box(
        Modifier
            .size(width = 44.dp, height = 44.dp)
            .then(if (bounds != null) Modifier.trackBounds(bounds) else Modifier)
            .graphicsLayer {
                val sc = 1f + 0.12f * a
                scaleX = sc
                scaleY = sc
            }
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(36.dp)
                .graphicsLayer { alpha = a }
                .clip(CircleShape)
                .background(ios.glassPress),
        )
        Text(text, style = TS.body.copy(fontWeight = FontWeight.SemiBold), color = ios.accent, maxLines = 1)
    }
}

/** iOS 26 "scroll edge effect": a soft progressive blur where content slides under the bars. */
@Composable
fun ScrollEdge(
    top: Boolean,
    height: Dp,
    color: Color,
    modifier: Modifier = Modifier,
    backdrop: Backdrop? = LocalBackdrop.current,
) {
    val live = backdrop != null && glassSupported
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                val mask = if (top) {
                    Brush.verticalGradient(0f to Color.Black, 0.45f to Color.Black, 1f to Color.Transparent)
                } else {
                    Brush.verticalGradient(0f to Color.Transparent, 0.55f to Color.Black, 1f to Color.Black)
                }
                drawRect(brush = mask, blendMode = BlendMode.DstIn)
            },
    ) {
        if (backdrop != null && live) {
            BackdropLayer(backdrop, Modifier.matchParentSize(), blur = 5.dp, saturation = 1.15f)
        }
        Box(Modifier.matchParentSize().background(color.copy(alpha = if (live) 0.62f else 0.9f)))
    }
}
