package com.liquid.notes.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import kotlin.math.sin
import kotlin.math.cos
import kotlin.math.PI
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liquid.notes.data.NoteText
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.theme.TS

enum class BlockType { Text, Check }

@Stable
class Block(val id: Long, type: BlockType, value: TextFieldValue, checked: Boolean) {
    var type by mutableStateOf(type)
    var value by mutableStateOf(value)
    var checked by mutableStateOf(checked)
}

class FocusRequest(val id: Long, val token: Int)

/**
 * The note editor is a column of blocks: free text, or one checklist item per block.
 * The focused block always survives structural edits, so the keyboard never flickers.
 */
@Stable
class EditorState(content: String) {
    private var nextId = 1L
    private var token = 0
    val blocks = mutableStateListOf<Block>()
    var focusedId by mutableStateOf<Long?>(null)
        private set
    var focusRequest by mutableStateOf<FocusRequest?>(null)
        private set

    val isEditing: Boolean get() = focusedId != null

    // undo / redo history of whole-note snapshots
    private val undoStack = ArrayList<String>()
    private val redoStack = ArrayList<String>()
    private var committed: String = ""
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    init {
        parse(content)
        committed = serialize()
    }

    /** Called (debounced) after edits; each call becomes one undo step. */
    fun commit(text: String) {
        if (text == committed) return
        undoStack.add(committed)
        if (undoStack.size > 200) undoStack.removeAt(0)
        committed = text
        redoStack.clear()
        refreshHistory()
    }

    fun undo() {
        commit(serialize())
        if (undoStack.isEmpty()) return
        val previous = undoStack.removeAt(undoStack.size - 1)
        redoStack.add(committed)
        restore(previous)
    }

    fun redo() {
        commit(serialize())
        if (redoStack.isEmpty()) return
        val next = redoStack.removeAt(redoStack.size - 1)
        undoStack.add(committed)
        restore(next)
    }

    private fun refreshHistory() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    private fun restore(text: String) {
        val wasEditing = focusedId != null
        committed = text
        blocks.clear()
        parse(text)
        refreshHistory()
        if (wasEditing) focusEnd()
    }

    fun stats(): Pair<Int, Int> {
        val word = Regex("[\\p{L}\\p{N}]+")
        var words = 0
        var chars = 0
        blocks.forEach { b ->
            words += word.findAll(b.value.text).count()
            chars += b.value.text.length
        }
        return words to chars
    }

    private fun newBlock(type: BlockType, text: String, checked: Boolean = false, cursor: Int = text.length): Block =
        Block(nextId++, type, TextFieldValue(text, TextRange(cursor.coerceIn(0, text.length))), checked)

    private fun parse(content: String) {
        val buf = StringBuilder()
        var hasBuf = false
        fun flush() {
            if (hasBuf) {
                blocks.add(newBlock(BlockType.Text, buf.toString()))
                buf.setLength(0)
                hasBuf = false
            }
        }
        for (line in content.split('\n')) {
            when {
                line.startsWith(NoteText.UNCHECKED) -> {
                    flush()
                    blocks.add(newBlock(BlockType.Check, line.substring(NoteText.UNCHECKED.length), false))
                }
                line.startsWith(NoteText.CHECKED) -> {
                    flush()
                    blocks.add(newBlock(BlockType.Check, line.substring(NoteText.CHECKED.length), true))
                }
                else -> {
                    if (hasBuf) buf.append('\n')
                    buf.append(line)
                    hasBuf = true
                }
            }
        }
        flush()
        if (blocks.isEmpty()) blocks.add(newBlock(BlockType.Text, ""))
    }

    fun serialize(): String = blocks.joinToString("\n") { b ->
        when (b.type) {
            BlockType.Text -> b.value.text
            BlockType.Check -> (if (b.checked) NoteText.CHECKED else NoteText.UNCHECKED) + b.value.text
        }
    }

    // ---------------- focus

    fun onFocus(b: Block, focused: Boolean) {
        if (focused) {
            focusedId = b.id
        } else if (focusedId == b.id) {
            focusedId = null
        }
    }

    private fun requestFocus(b: Block, cursor: Int) {
        val c = cursor.coerceIn(0, b.value.text.length)
        b.value = b.value.copy(selection = TextRange(c))
        token += 1
        focusRequest = FocusRequest(b.id, token)
    }

    fun focusStart() = requestFocus(blocks[0], blocks[0].value.text.length)

    fun focusEnd() {
        val last = blocks[blocks.size - 1]
        requestFocus(last, last.value.text.length)
    }

    // ---------------- editing

    fun onValueChange(b: Block, v: TextFieldValue) {
        if (b.type == BlockType.Text) {
            b.value = smartList(b.value, v)
            return
        }
        if (!v.text.contains('\n')) {
            b.value = v
            return
        }
        val idx = blocks.indexOf(b)
        if (idx < 0) return
        if (b.value.text.isEmpty() && v.text.trim('\n').isEmpty()) {
            // Return on an empty checklist item ends the list (like iOS)
            convertToText(idx)
            return
        }
        val parts = v.text.split('\n')
        val sel = v.selection.start
        b.value = TextFieldValue(parts[0], TextRange(parts[0].length))
        val created = ArrayList<Block>()
        for (i in 1 until parts.size) created += newBlock(BlockType.Check, parts[i], false, 0)
        blocks.addAll(idx + 1, created)
        var running = 0
        var target = b
        var cursor = parts[0].length
        parts.forEachIndexed { i, p ->
            if (sel >= running && sel <= running + p.length) {
                target = if (i == 0) b else created[i - 1]
                cursor = sel - running
            }
            running += p.length + 1
        }
        requestFocus(target, cursor)
    }

    private val numbered = Regex("^(\\d{1,3})\\. ")

    private fun linePrefix(line: String): String? =
        if (line.startsWith(NoteText.BULLET)) NoteText.BULLET else numbered.find(line)?.value

    /**
     * iOS-style lists inside text: "- " or "* " at the start of a line becomes "• ",
     * Return continues a bulleted/numbered list, Return on an empty item ends it.
     */
    private fun smartList(old: TextFieldValue, v: TextFieldValue): TextFieldValue {
        val t = v.text
        val c = v.selection.start
        if (!v.selection.collapsed || t.length != old.text.length + 1 || c <= 0 || c > t.length) return v
        if (t.substring(0, c - 1) + t.substring(c) != old.text) return v
        val ch = t[c - 1]
        val lineStart = t.lastIndexOf('\n', c - 2) + 1
        if (ch == ' ') {
            val before = t.substring(lineStart, c - 1)
            if (before == "-" || before == "*") {
                val nt = t.substring(0, lineStart) + NoteText.BULLET + t.substring(c)
                return TextFieldValue(nt, TextRange(lineStart + NoteText.BULLET.length))
            }
            return v
        }
        if (ch != '\n') return v
        val prevLine = t.substring(lineStart, c - 1)
        val prefix = linePrefix(prevLine) ?: return v
        if (prevLine.length == prefix.length) {
            // empty list item + Return = end the list
            val nt = t.substring(0, lineStart) + t.substring(c)
            return TextFieldValue(nt, TextRange(lineStart))
        }
        val next = if (prefix == NoteText.BULLET) {
            NoteText.BULLET
        } else {
            val n = numbered.find(prevLine)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            "${n + 1}. "
        }
        val nt = t.substring(0, c) + next + t.substring(c)
        return TextFieldValue(nt, TextRange(c + next.length))
    }

    private fun previousNumber(t: String, lineStart: Int): Int {
        if (lineStart <= 0) return 0
        val prevStart = t.lastIndexOf('\n', lineStart - 2) + 1
        val prev = t.substring(prevStart, lineStart - 1)
        return numbered.find(prev)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }

    /** "Aa" menu: toggle a bullet or number on the line under the cursor. */
    fun toggleList(bullet: Boolean) {
        var idx = blocks.indexOfFirst { it.id == focusedId }
        if (idx < 0) {
            val last = blocks[blocks.size - 1]
            if (last.type == BlockType.Check) {
                blocks.add(newBlock(BlockType.Text, ""))
            } else {
                last.value = last.value.copy(selection = TextRange(last.value.text.length))
            }
            idx = blocks.size - 1
        }
        val b = blocks[idx]
        if (b.type == BlockType.Check) {
            convertToText(idx)
        }
        val t = b.value.text
        val cur = b.value.selection.start.coerceIn(0, t.length)
        val lineStart = if (cur == 0) 0 else t.lastIndexOf('\n', cur - 1) + 1
        val nl = t.indexOf('\n', lineStart)
        val lineEnd = if (nl < 0) t.length else nl
        val line = t.substring(lineStart, lineEnd)
        val existing = linePrefix(line)
        val body = if (existing != null) line.substring(existing.length) else line
        val sameKind = existing != null && (existing == NoteText.BULLET) == bullet
        val newLine = when {
            sameKind -> body
            bullet -> NoteText.BULLET + body
            else -> "${previousNumber(t, lineStart) + 1}. " + body
        }
        val newText = t.substring(0, lineStart) + newLine + t.substring(lineEnd)
        val inBody = (cur - lineStart - (existing?.length ?: 0)).coerceAtLeast(0)
        val newCur = (lineStart + (newLine.length - body.length) + inBody).coerceIn(0, newText.length)
        b.value = TextFieldValue(newText, TextRange(newCur))
        requestFocus(b, newCur)
    }

    fun moveCheckedToBottom() {
        var i = 0
        while (i < blocks.size) {
            if (blocks[i].type != BlockType.Check) {
                i += 1
                continue
            }
            var j = i
            while (j < blocks.size && blocks[j].type == BlockType.Check) j += 1
            val run = blocks.subList(i, j).toList()
            val sorted = run.filter { !it.checked } + run.filter { it.checked }
            if (sorted != run) {
                for (k in j - 1 downTo i) blocks.removeAt(k)
                blocks.addAll(i, sorted)
            }
            i = j
        }
    }

    fun uncheckAll() {
        blocks.forEach { if (it.type == BlockType.Check) it.checked = false }
    }

    fun deleteChecked() {
        for (k in blocks.size - 1 downTo 0) {
            val b = blocks[k]
            if (b.type == BlockType.Check && b.checked) blocks.removeAt(k)
        }
        // merge text blocks that became neighbours
        var i = 0
        while (i < blocks.size - 1) {
            val a = blocks[i]
            val nb = blocks[i + 1]
            if (a.type == BlockType.Text && nb.type == BlockType.Text) {
                val at = a.value.text
                a.value = TextFieldValue(at + "\n" + nb.value.text, TextRange(at.length))
                blocks.removeAt(i + 1)
            } else {
                i += 1
            }
        }
        if (blocks.isEmpty()) blocks.add(newBlock(BlockType.Text, ""))
    }

    /** Hardware/IME backspace with the cursor at the very start of a block. */
    fun onBackspace(b: Block): Boolean {
        val sel = b.value.selection
        if (!sel.collapsed || sel.start != 0) return false
        val idx = blocks.indexOf(b)
        if (idx < 0) return false
        return when {
            b.type == BlockType.Check -> {
                convertToText(idx)
                true
            }
            idx > 0 && blocks[idx - 1].type == BlockType.Check -> {
                mergeIntoPreviousCheck(idx)
                true
            }
            else -> false
        }
    }

    fun toggleCheck(b: Block) {
        b.checked = !b.checked
    }

    /** Toolbar checklist button. */
    fun toggleChecklist() {
        val idx = blocks.indexOfFirst { it.id == focusedId }
        if (idx < 0) {
            val last = blocks[blocks.size - 1]
            if (last.type == BlockType.Text && last.value.text.isEmpty()) {
                last.type = BlockType.Check
                requestFocus(last, 0)
            } else {
                val nb = newBlock(BlockType.Check, "")
                blocks.add(nb)
                requestFocus(nb, 0)
            }
            return
        }
        val b = blocks[idx]
        if (b.type == BlockType.Check) {
            convertToText(idx)
            return
        }
        // Turn the line under the cursor into a checklist item; the focused block becomes that item.
        val t = b.value.text
        val cur = b.value.selection.start.coerceIn(0, t.length)
        val lineStart = if (cur == 0) 0 else t.lastIndexOf('\n', cur - 1) + 1
        val nl = t.indexOf('\n', cur)
        val lineEnd = if (nl < 0) t.length else nl
        val before = if (lineStart > 0) t.substring(0, lineStart - 1) else null
        val line = t.substring(lineStart, lineEnd)
        val after = if (nl >= 0) t.substring(nl + 1) else null
        b.type = BlockType.Check
        b.checked = false
        b.value = TextFieldValue(line, TextRange(cur - lineStart))
        var pos = idx
        if (before != null) {
            blocks.add(pos, newBlock(BlockType.Text, before))
            pos += 1
        }
        if (after != null) blocks.add(pos + 1, newBlock(BlockType.Text, after, cursor = 0))
        requestFocus(b, cur - lineStart)
    }

    private fun convertToText(start: Int) {
        var idx = start
        val b = blocks[idx]
        var text = b.value.text
        var cursor = b.value.selection.start.coerceIn(0, text.length)
        b.type = BlockType.Text
        b.checked = false
        if (idx > 0 && blocks[idx - 1].type == BlockType.Text) {
            val prev = blocks[idx - 1].value.text
            text = prev + "\n" + text
            cursor += prev.length + 1
            blocks.removeAt(idx - 1)
            idx -= 1
        }
        if (idx + 1 < blocks.size && blocks[idx + 1].type == BlockType.Text) {
            text = text + "\n" + blocks[idx + 1].value.text
            blocks.removeAt(idx + 1)
        }
        b.value = TextFieldValue(text, TextRange(cursor))
        requestFocus(b, cursor)
    }

    private fun mergeIntoPreviousCheck(idx: Int) {
        val b = blocks[idx]
        val prev = blocks[idx - 1]
        val t = b.value.text
        val nl = t.indexOf('\n')
        val first = if (nl < 0) t else t.substring(0, nl)
        val rest = if (nl < 0) null else t.substring(nl + 1)
        val cursor = prev.value.text.length
        b.type = BlockType.Check
        b.checked = prev.checked
        b.value = TextFieldValue(prev.value.text + first, TextRange(cursor))
        blocks.removeAt(idx - 1)
        if (rest != null) blocks.add(idx, newBlock(BlockType.Text, rest, cursor = 0))
        requestFocus(b, cursor)
    }
}

/** First line of a note is styled as the Title (iOS default); #tags are tinted. */
private class NoteTransformation(private val title: SpanStyle?, private val tag: SpanStyle) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val raw = text.text
        val titleEnd = if (title == null) 0 else raw.indexOf('\n').let { if (it < 0) raw.length else it }
        val matches = NoteText.TAG_REGEX.findAll(raw).toList()
        if (titleEnd <= 0 && matches.isEmpty()) return TransformedText(text, OffsetMapping.Identity)
        val b = AnnotatedString.Builder(text)
        if (title != null && titleEnd > 0) b.addStyle(title, 0, titleEnd)
        matches.forEach { m -> b.addStyle(tag, m.range.first, m.range.last + 1) }
        return TransformedText(b.toAnnotatedString(), OffsetMapping.Identity)
    }

    override fun equals(other: Any?): Boolean =
        other is NoteTransformation && other.title == title && other.tag == tag

    override fun hashCode(): Int = 31 * (title?.hashCode() ?: 0) + tag.hashCode()
}

@Composable
fun BlockEditor(state: EditorState, modifier: Modifier = Modifier) {
    val ios = LocalIos.current
    val body = TS.body.copy(color = ios.label, fontSize = 17.sp)
    val tagStyle = SpanStyle(color = ios.accent, fontWeight = FontWeight.Medium)
    val titleStyle = SpanStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.6).sp)
    val withTitle = remember(ios.accent) { NoteTransformation(titleStyle, tagStyle) }
    val plain = remember(ios.accent) { NoteTransformation(null, tagStyle) }
    Column(modifier) {
        state.blocks.forEachIndexed { index, block ->
            key(block.id) {
                BlockRow(
                    state = state,
                    block = block,
                    transform = if (index == 0 && block.type == BlockType.Text) withTitle else plain,
                    style = body,
                )
            }
        }
    }
}

@Composable
private fun BlockRow(state: EditorState, block: Block, transform: VisualTransformation, style: TextStyle) {
    val ios = LocalIos.current
    val focus = remember { FocusRequester() }
    val req = state.focusRequest
    LaunchedEffect(req) {
        if (req != null && req.id == block.id) runCatching { focus.requestFocus() }
    }
    val isCheck = block.type == BlockType.Check
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = if (isCheck) 4.dp else 0.dp),
        verticalAlignment = Alignment.Top,
    ) {
        CheckCircle(visible = isCheck, checked = block.checked, onToggle = { state.toggleCheck(block) })
        BasicTextField(
            value = block.value,
            onValueChange = { v -> state.onValueChange(block, v) },
            textStyle = style,
            cursorBrush = SolidColor(ios.accent),
            visualTransformation = transform,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
            modifier = Modifier
                .weight(1f)
                .focusRequester(focus)
                .onFocusChanged { state.onFocus(block, it.isFocused) }
                .onPreviewKeyEvent { e ->
                    if (e.type == KeyEventType.KeyDown && e.key == Key.Backspace) state.onBackspace(block) else false
                },
        )
    }
}

@Composable
private fun CheckCircle(visible: Boolean, checked: Boolean, onToggle: () -> Unit) {
    val ios = LocalIos.current
    val haptic = LocalHapticFeedback.current
    val fill by animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 600f),
        label = "check",
    )
    // water splash when an item gets ticked
    val splash = remember { Animatable(1f) }
    var previous by remember { mutableStateOf(checked) }
    LaunchedEffect(checked) {
        if (checked && !previous) {
            splash.snapTo(0f)
            splash.animateTo(1f, tween(520))
        }
        previous = checked
    }
    Box(
        Modifier
            .width(if (visible) 36.dp else 0.dp)
            .height(23.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        if (visible) {
            Canvas(
                Modifier
                    .size(24.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onToggle()
                    },
            ) {
                val r = size.minDimension / 2f
                val ring = 1.6.dp.toPx()
                val sp = splash.value
                if (sp < 1f) {
                    val fade = 1f - sp
                    drawCircle(
                        color = ios.accent.copy(alpha = 0.55f * fade),
                        radius = r * (1f + 0.9f * sp),
                        style = Stroke(width = 2.dp.toPx() * fade + 0.5f),
                    )
                    for (i in 0 until 6) {
                        val a = (i / 6f) * 2f * PI.toFloat() + 0.35f
                        val d = r * (1.15f + 1.1f * sp)
                        drawCircle(
                            color = ios.accent.copy(alpha = fade),
                            radius = 2.dp.toPx() * fade,
                            center = Offset(center.x + cos(a) * d, center.y + sin(a) * d),
                        )
                    }
                }
                if (fill < 0.98f) {
                    drawCircle(color = ios.checkRing, radius = r - ring / 2f, style = Stroke(width = ring))
                }
                if (fill > 0.01f) {
                    drawCircle(color = ios.accent, radius = r * fill.coerceAtMost(1.1f))
                    // glassy highlight on the filled drop
                    drawCircle(
                        color = Color.White.copy(alpha = 0.35f * fill.coerceIn(0f, 1f)),
                        radius = r * 0.42f * fill.coerceIn(0f, 1f),
                        center = Offset(center.x - r * 0.28f, center.y - r * 0.3f),
                    )
                    val p = Path().apply {
                        moveTo(size.width * 0.29f, size.height * 0.52f)
                        lineTo(size.width * 0.44f, size.height * 0.66f)
                        lineTo(size.width * 0.72f, size.height * 0.36f)
                    }
                    drawPath(
                        path = p,
                        color = ios.onAccent.copy(alpha = fill.coerceIn(0f, 1f)),
                        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
                    )
                }
            }
        }
    }
}
