# MROS Notes

iOS Eslatmalar (Notes) ilovasining Android nusxasi, Liquid Glass dizayn bilan.
Kotlin + Jetpack Compose, minSdk 26 (Android 8+).

- Blur Android 12+ da ishlaydi, chetlardagi linza effekti Android 13+ da. Android 8–11 da oddiy xira (frosted) fon chiqadi.
- Til telefon tiliga qarab tanlanadi: o‘zbek, rus yoki ingliz.
- Ekranlar bosilgan joydan suv tomchisidek yoyilib ochiladi; menyu va oynalar tomchidek cho‘zilib chiqadi.
- Muharrir: Undo/Redo, **Aa** (belgili/raqamli ro‘yxat, checklist, belgilanganlarni pastga, o‘chirish), `- ` yozsangiz ro‘yxat boshlanadi, #teglar.
- Jildlar ekranida Teglar bo‘limi, eslatmadan nusxa olish, so‘z soni, launcher yorlig‘i “Yangi eslatma”.
- Eslatmani surganda alohida suv tomchisi shisha tugmalar chiqadi (to‘liq surilsa cho‘zilib bajariladi).
- Widgetlar: “Eslatma” (qadalgan/oxirgi), “Eslatmalar ro‘yxati”, “Tezkor eslatma”. Jildlar → ••• → “Widget orqasida obi-oy blur” — obi-oyni xiralashtirib widget orqasiga qo‘yadi (Android “Barcha fayllarga kirish” ruxsatini so‘raydi).

## APK'ni GitHub'da yig‘ish

Repozitoriya **Public** bo‘lishi kerak, aks holda ilova yangilanishni ko‘ra olmaydi.

**Telefondan (zip bilan):**
1. GitHub'da yangi repo yarating.
2. **Add file → Create new file**, nomiga `.github/workflows/build.yml` deb yozing, ichiga shu loyihadagi `build.yml` matnini qo‘ying va **Commit** qiling.
3. **Add file → Upload files** orqali `MROS-Notes.zip` faylini yuklab, **Commit** qiling.
4. **Actions** bo‘limida yig‘ish tugashini kuting (5–8 daqiqa). Keyin **Releases** bo‘limidan `MROS-Notes.apk` ni yuklab oling.

**Kompyuterdan:** zipni oching va ichidagi hamma narsani (`.github` papkasi bilan birga) repoga yuklang.

## Yangi versiya chiqarish

O‘zgartirilgan loyihani yana yuklang. Zip ishlatsangiz, uni **aynan shu nom bilan** (`MROS-Notes.zip`) qayta yuklang. Har bir yuklashda Actions yangi Release chiqaradi (`v1`, `v2`, `v3`, …).

Ilovada: **Jildlar → ••• → Yangilanishlarni tekshirish → Yangilash**. Ilova ochilganda ham jimgina tekshiradi va yangi versiya bo‘lsa xabar beradi.
Birinchi marta yangilaganda Android “noma’lum manbadan o‘rnatish”ga ruxsat so‘raydi. Ruxsat bering va qaytadan tekshiring.

`app/notes.keystore` ni o‘chirmang va almashtirmang. Hamma versiyalar shu kalit bilan imzolanadi, shuning uchun yangi APK eskisining ustiga o‘rnatiladi va eslatmalar saqlanib qoladi.
