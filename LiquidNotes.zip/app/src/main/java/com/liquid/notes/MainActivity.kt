package com.liquid.notes

import android.content.Intent
import android.os.Bundle
import android.text.format.DateFormat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.liquid.notes.data.NotesStore
import com.liquid.notes.ui.NotesRoot
import com.liquid.notes.ui.theme.NotesTheme
import com.liquid.notes.util.Dates

class MainActivity : ComponentActivity() {

    private lateinit var store: NotesStore

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        store = NotesStore.get(this)
        Dates.is24h = DateFormat.is24HourFormat(this)
        val shared = sharedText(intent)
        setContent {
            NotesTheme {
                NotesRoot(store, shared)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Dates.is24h = DateFormat.is24HourFormat(this)
    }

    override fun onStop() {
        super.onStop()
        store.flush()
    }

    private fun sharedText(i: Intent?): String? {
        if (i == null || i.action != Intent.ACTION_SEND) return null
        if (i.type?.startsWith("text/") != true) return null
        val subject = i.getStringExtra(Intent.EXTRA_SUBJECT)
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return null
        return if (!subject.isNullOrBlank() && !text.startsWith(subject)) subject + "\n" + text else text
    }
}
