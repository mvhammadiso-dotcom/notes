package com.liquid.notes.ui.icons

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

/** SF Symbols look-alikes drawn on a 24×24 grid. */
object Sf {
    private class P(val d: String, val fill: Boolean = false)

    private fun icon(name: String, stroke: Float, vararg paths: P): ImageVector {
        val b = ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        )
        for (p in paths) {
            b.addPath(
                pathData = PathParser().parsePathString(p.d).toNodes(),
                fill = if (p.fill) SolidColor(Color.Black) else null,
                stroke = if (p.fill) null else SolidColor(Color.Black),
                strokeLineWidth = stroke,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round,
            )
        }
        return b.build()
    }

    private fun dot(x: Float, y: Float, r: Float) =
        "M${x - r} ${y}a$r $r 0 1 0 ${2 * r} 0a$r $r 0 1 0 ${-2 * r} 0z"

    private fun roundRect(x: Float, y: Float, w: Float, h: Float, r: Float) =
        "M${x + r} ${y}H${x + w - r}A$r $r 0 0 1 ${x + w} ${y + r}V${y + h - r}A$r $r 0 0 1 ${x + w - r} ${y + h}" +
            "H${x + r}A$r $r 0 0 1 $x ${y + h - r}V${y + r}A$r $r 0 0 1 ${x + r} ${y}Z"

    val ChevronLeft by lazy { icon("chevron.left", 2.5f, P("M14.6 4.8L7.4 12l7.2 7.2")) }
    val ChevronRight by lazy { icon("chevron.right", 2.5f, P("M9.4 4.8l7.2 7.2-7.2 7.2")) }
    val ChevronDown by lazy { icon("chevron.down", 2.5f, P("M4.8 8.8l7.2 7.2 7.2-7.2")) }

    val Ellipsis by lazy {
        icon("ellipsis", 0f, P(dot(5.5f, 12f, 1.8f), true), P(dot(12f, 12f, 1.8f), true), P(dot(18.5f, 12f, 1.8f), true))
    }

    val Compose by lazy {
        icon(
            "square.and.pencil", 1.8f,
            P("M11.6 4.4H7.1A2.6 2.6 0 0 0 4.5 7v10a2.6 2.6 0 0 0 2.6 2.6h10A2.6 2.6 0 0 0 19.7 17v-4.6"),
            P("M18.3 3.5a1.95 1.95 0 0 1 2.75 2.75L12.4 14.9l-3.55 0.8l0.8 -3.55z"),
        )
    }

    private const val FOLDER =
        "M3.4 7.3A2.3 2.3 0 0 1 5.7 5h3.9a1.6 1.6 0 0 1 1.2 0.55L12.2 7.2h6.1a2.3 2.3 0 0 1 2.3 2.3v7.2a2.3 2.3 0 0 1 -2.3 2.3H5.7a2.3 2.3 0 0 1 -2.3 -2.3z"

    val Folder by lazy { icon("folder", 1.8f, P(FOLDER), P("M3.4 10h17.2")) }
    val FolderFill by lazy { icon("folder.fill", 0f, P(FOLDER, true)) }
    val FolderPlus by lazy { icon("folder.badge.plus", 1.8f, P(FOLDER), P("M12 10.6v5.6M9.2 13.4h5.6")) }

    val Trash by lazy {
        icon(
            "trash", 1.8f,
            P("M4 6.6h16"),
            P("M9 6.6V5.1a1.6 1.6 0 0 1 1.6-1.6h2.8A1.6 1.6 0 0 1 15 5.1v1.5"),
            P("M6 6.6l0.9 12a2 2 0 0 0 2 1.9h6.2a2 2 0 0 0 2 -1.9l0.9 -12"),
            P("M10 10.5v6M14 10.5v6"),
        )
    }

    private const val PIN =
        "M8.6 3.4h6.8M9.6 3.4l0.35 5.4l-2.75 3.6h9.6l-2.75 -3.6l0.35 -5.4M12 12.4v8.2"

    val Pin by lazy { icon("pin", 1.8f, P(PIN)) }
    val PinSlash by lazy { icon("pin.slash", 1.8f, P(PIN), P("M4 4l16 16")) }
    val PinFill by lazy {
        icon(
            "pin.fill", 1.6f,
            P("M8.7 2.8h6.6a0.9 0.9 0 0 1 0 1.8h-0.5l-0.35 4.1l2.9 3.6a0.9 0.9 0 0 1 -0.7 1.5H7.35a0.9 0.9 0 0 1 -0.7 -1.5l2.9 -3.6l-0.35 -4.1h-0.5a0.9 0.9 0 0 1 0 -1.8z", true),
            P("M12 13.8v7"),
        )
    }

    val Checklist by lazy {
        icon(
            "checklist", 1.8f,
            P("M3.6 6.4l1.6 1.6 3-3.3"), P("M11.4 6.5h9"),
            P("M3.6 12.4l1.6 1.6 3-3.3"), P("M11.4 12.5h9"),
            P("M3.6 18.4l1.6 1.6 3-3.3"), P("M11.4 18.5h9"),
        )
    }

    val Checkmark by lazy { icon("checkmark", 2.6f, P("M5 12.6l4.6 4.6L19 7.4")) }
    val XMark by lazy { icon("xmark", 2.4f, P("M6.5 6.5l11 11M17.5 6.5l-11 11")) }
    val Plus by lazy { icon("plus", 2.2f, P("M12 5v14M5 12h14")) }

    val Search by lazy {
        icon("magnifyingglass", 2.1f, P("M4.2 10.6a6.4 6.4 0 1 0 12.8 0a6.4 6.4 0 1 0-12.8 0z"), P("M15.5 15.5l4.9 4.9"))
    }

    val Mic by lazy {
        icon(
            "mic", 1.8f,
            P("M12 3.2a3 3 0 0 1 3 3v5.3a3 3 0 0 1-6 0V6.2a3 3 0 0 1 3-3z"),
            P("M6.2 11.2a5.8 5.8 0 0 0 11.6 0"),
            P("M12 17v3.8"),
        )
    }

    val Share by lazy {
        icon(
            "square.and.arrow.up", 1.8f,
            P("M12 3.4v11.2"),
            P("M8.2 7.2L12 3.4l3.8 3.8"),
            P("M8.8 10H7.3A2.3 2.3 0 0 0 5 12.3v5.9a2.3 2.3 0 0 0 2.3 2.3h9.4a2.3 2.3 0 0 0 2.3-2.3v-5.9A2.3 2.3 0 0 0 16.7 10h-1.5"),
        )
    }

    val Restore by lazy {
        icon(
            "arrow.uturn.backward", 1.9f,
            P("M8.8 5.4L4.4 9.8l4.4 4.4"),
            P("M4.7 9.8h9.8a5 5 0 0 1 0 10h-3.4"),
        )
    }

    val Grid by lazy {
        icon(
            "square.grid.2x2", 1.8f,
            P(roundRect(4f, 4f, 6.6f, 6.6f, 1.8f)), P(roundRect(13.4f, 4f, 6.6f, 6.6f, 1.8f)),
            P(roundRect(4f, 13.4f, 6.6f, 6.6f, 1.8f)), P(roundRect(13.4f, 13.4f, 6.6f, 6.6f, 1.8f)),
        )
    }

    val ListBullet by lazy {
        icon(
            "list.bullet", 1.8f,
            P(dot(4.6f, 6.5f, 1.3f), true), P(dot(4.6f, 12f, 1.3f), true), P(dot(4.6f, 17.5f, 1.3f), true),
            P("M9 6.5h11.4M9 12h11.4M9 17.5h11.4"),
        )
    }

    val Sort by lazy {
        icon("arrow.up.arrow.down", 1.8f, P("M7.5 19.5v-15M4 8l3.5-3.5L11 8"), P("M16.5 4.5v15M13 16l3.5 3.5L20 16"))
    }

    val Pencil by lazy {
        icon("pencil", 1.8f, P("M16 4.4a2 2 0 0 1 2.85 2.85L8.4 17.7l-3.9 1 1-3.9z"), P("M14 6.4l2.85 2.85"))
    }

    val Download by lazy {
        icon(
            "arrow.down.circle", 1.8f,
            P("M3.5 12a8.5 8.5 0 1 0 17 0a8.5 8.5 0 1 0-17 0z"),
            P("M12 7.4v8.8M8.6 12.9l3.4 3.4 3.4-3.4"),
        )
    }

    val Info by lazy {
        icon(
            "info.circle", 1.8f,
            P("M3.5 12a8.5 8.5 0 1 0 17 0a8.5 8.5 0 1 0-17 0z"),
            P("M12 11v5.4"),
            P(dot(12f, 7.9f, 1.15f), true),
        )
    }
}
