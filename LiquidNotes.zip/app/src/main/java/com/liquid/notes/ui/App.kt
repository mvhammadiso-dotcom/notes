package com.liquid.notes.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.liquid.notes.data.DEFAULT_FOLDER
import com.liquid.notes.data.ListTarget
import com.liquid.notes.data.NotesStore
import com.liquid.notes.ui.glass.LocalBackdrop
import com.liquid.notes.ui.glass.backdropSource
import com.liquid.notes.ui.glass.rememberBackdrop
import com.liquid.notes.ui.overlay.OverlayHost
import com.liquid.notes.ui.overlay.OverlayState
import com.liquid.notes.ui.screens.EditorScreen
import com.liquid.notes.ui.screens.FoldersScreen
import com.liquid.notes.ui.screens.NotesListScreen
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.update.UpdateController
import com.liquid.notes.util.LocalStrings
import kotlinx.coroutines.delay

@Composable
fun NotesRoot(store: NotesStore, sharedText: String?) {
    val ios = LocalIos.current
    val s = LocalStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val holder = rememberSaveableStateHolder()
    val nav = remember {
        Navigator(listOf(Screen.Folders, Screen.Notes(ListTarget.InFolder(DEFAULT_FOLDER)))) { removed ->
            holder.removeState(removed.key)
            if (removed is Screen.Editor) store.discardIfEmpty(removed.noteId)
        }
    }
    val overlay = remember { OverlayState() }
    val updates = remember { UpdateController(context.applicationContext, overlay, s, scope) }
    val appBackdrop = rememberBackdrop()
    var sharedHandled by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(sharedText) {
        if (!sharedHandled && !sharedText.isNullOrBlank()) {
            sharedHandled = true
            val id = store.createNote(DEFAULT_FOLDER, sharedText)
            nav.push(Screen.Editor(id))
        }
    }
    // Quiet update check shortly after launch.
    LaunchedEffect(Unit) {
        delay(2500)
        updates.check(silent = true)
    }

    CompositionLocalProvider(
        LocalStore provides store,
        LocalNav provides nav,
        LocalOverlay provides overlay,
        LocalUpdates provides updates,
    ) {
        BackHandler(enabled = nav.canPop) { nav.pop() }
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .backdropSource(appBackdrop)
                    .background(ios.background),
            ) {
                AnimatedContent(
                    targetState = nav.current,
                    contentKey = { it.key },
                    transitionSpec = {
                        val ease = CubicBezierEasing(0.2f, 0.9f, 0.22f, 1f)
                        if (nav.lastWasPush) {
                            (
                                slideInHorizontally(tween(430, easing = ease)) { it } togetherWith
                                    slideOutHorizontally(tween(430, easing = ease)) { -it / 4 }
                                ).apply { targetContentZIndex = 1f }
                        } else {
                            (
                                slideInHorizontally(tween(400, easing = ease)) { -it / 4 } togetherWith
                                    slideOutHorizontally(tween(400, easing = ease)) { it }
                                ).apply { targetContentZIndex = -1f }
                        }
                    },
                    label = "nav",
                ) { screen ->
                    holder.SaveableStateProvider(screen.key) {
                        when (screen) {
                            Screen.Folders -> FoldersScreen()
                            is Screen.Notes -> NotesListScreen(screen.target)
                            is Screen.Editor -> EditorScreen(screen.noteId)
                        }
                    }
                }
            }
            CompositionLocalProvider(LocalBackdrop provides appBackdrop) {
                OverlayHost(overlay, appBackdrop)
            }
        }
    }
}
