package com.liquid.notes.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.liquid.notes.util.LocalStrings
import com.liquid.notes.util.Strings
import java.util.Locale

/** iOS system colours (UIKit semantic colours), light & dark. */
@Immutable
data class IosColors(
    val dark: Boolean,
    val background: Color,
    val card: Color,
    val editorBackground: Color,
    val label: Color,
    val secondaryLabel: Color,
    val tertiaryLabel: Color,
    val separator: Color,
    val fill: Color,
    val pressed: Color,
    val accent: Color,
    val onAccent: Color,
    val red: Color,
    val orange: Color,
    val purple: Color,
    val checkRing: Color,
    val glassTint: Color,
    val glassMenuTint: Color,
    val glassFallback: Color,
    val glassRim: Color,
    val glassRimDim: Color,
    val glassShine: Color,
    val dim: Color,
)

val LightIos = IosColors(
    dark = false,
    background = Color(0xFFF2F2F7),
    card = Color(0xFFFFFFFF),
    editorBackground = Color(0xFFFFFFFF),
    label = Color(0xFF000000),
    secondaryLabel = Color(0x993C3C43),
    tertiaryLabel = Color(0x4D3C3C43),
    separator = Color(0x4A3C3C43),
    fill = Color(0x1F767680),
    pressed = Color(0xFFD1D1D6),
    accent = Color(0xFFE3A500),
    onAccent = Color(0xFFFFFFFF),
    red = Color(0xFFFF3B30),
    orange = Color(0xFFFF9500),
    purple = Color(0xFFAF52DE),
    checkRing = Color(0xFFC7C7CC),
    glassTint = Color(0x66FFFFFF),
    glassMenuTint = Color(0xB8F7F7F8),
    glassFallback = Color(0xF5F8F8FA),
    glassRim = Color(0xF2FFFFFF),
    glassRimDim = Color(0x40FFFFFF),
    glassShine = Color(0x47FFFFFF),
    dim = Color(0x24000000),
)

val DarkIos = IosColors(
    dark = true,
    background = Color(0xFF000000),
    card = Color(0xFF1C1C1E),
    editorBackground = Color(0xFF000000),
    label = Color(0xFFFFFFFF),
    secondaryLabel = Color(0x99EBEBF5),
    tertiaryLabel = Color(0x4DEBEBF5),
    separator = Color(0x99545458),
    fill = Color(0x3D767680),
    pressed = Color(0xFF3A3A3C),
    accent = Color(0xFFFFD60A),
    onAccent = Color(0xFF000000),
    red = Color(0xFFFF453A),
    orange = Color(0xFFFF9F0A),
    purple = Color(0xFFBF5AF2),
    checkRing = Color(0xFF48484A),
    glassTint = Color(0x52303034),
    glassMenuTint = Color(0xB82A2A2D),
    glassFallback = Color(0xF52A2A2D),
    glassRim = Color(0x66FFFFFF),
    glassRimDim = Color(0x14FFFFFF),
    glassShine = Color(0x14FFFFFF),
    dim = Color(0x59000000),
)

val LocalIos = staticCompositionLocalOf { LightIos }

/** SF Pro-like text styles (tight tracking on Roboto). */
object TS {
    val largeTitle = TextStyle(fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.8).sp)
    val title2 = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp)
    val title3 = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.4).sp)
    val headline = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.35).sp)
    val body = TextStyle(fontSize = 17.sp, letterSpacing = (-0.35).sp)
    val callout = TextStyle(fontSize = 16.sp, letterSpacing = (-0.3).sp)
    val subhead = TextStyle(fontSize = 15.sp, letterSpacing = (-0.2).sp)
    val footnote = TextStyle(fontSize = 13.sp, letterSpacing = (-0.1).sp)
    val caption = TextStyle(fontSize = 12.sp)
}

@Composable
fun NotesTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ios = if (dark) DarkIos else LightIos
    val strings = remember { Strings(Locale.getDefault().language) }
    val scheme = if (dark) {
        darkColorScheme(primary = ios.accent, background = ios.background, surface = ios.card)
    } else {
        lightColorScheme(primary = ios.accent, background = ios.background, surface = ios.card)
    }
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(
            LocalIos provides ios,
            LocalStrings provides strings,
            LocalTextSelectionColors provides TextSelectionColors(
                handleColor = ios.accent,
                backgroundColor = ios.accent.copy(alpha = 0.32f),
            ),
            content = content,
        )
    }
}
