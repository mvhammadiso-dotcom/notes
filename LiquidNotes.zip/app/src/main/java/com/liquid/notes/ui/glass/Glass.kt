package com.liquid.notes.ui.glass

import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.theme.TS

/*
 * Liquid Glass for Android.
 *
 * A "Backdrop" records whatever is drawn under the glass into a GraphicsLayer (RenderNode).
 * Every glass shape then re-draws that layer (offset to its own position) through a RenderEffect chain:
 *   blur  ->  saturation boost  ->  AGSL lens that bends the image near the rounded edges (Android 13+).
 * On top come a translucent tint, a top sheen and a specular rim. Android 8–11 falls back to frosted fill.
 */

val glassSupported: Boolean get() = Build.VERSION.SDK_INT >= 31

@Stable
class Backdrop internal constructor(val layer: GraphicsLayer) {
    var origin by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberBackdrop(): Backdrop {
    val layer = rememberGraphicsLayer()
    return remember(layer) { Backdrop(layer) }
}

val LocalBackdrop = compositionLocalOf<Backdrop?> { null }

/** Marks the content that glass placed above it should refract. Put the background *after* this modifier. */
fun Modifier.backdropSource(backdrop: Backdrop): Modifier = this
    .onGloballyPositioned { backdrop.origin = it.positionInRoot() }
    .drawWithContent {
        backdrop.layer.record { this@drawWithContent.drawContent() }
        drawLayer(backdrop.layer)
    }

class BoundsHolder {
    var rect: Rect = Rect.Zero
}

fun Modifier.trackBounds(holder: BoundsHolder): Modifier =
    this.onGloballyPositioned { holder.rect = it.boundsInRoot() }

private const val LENS_SHADER = """
uniform shader content;
uniform float2 size;
uniform float radius;
uniform float depth;
uniform float strength;

float sdRoundRect(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + float2(r, r);
    return min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0, 0.0))) - r;
}

half4 main(float2 coord) {
    float2 hs = size * 0.5;
    float2 p = coord - hs;
    float d = sdRoundRect(p, hs, radius);
    float t = clamp(1.0 + d / depth, 0.0, 1.0);
    float e = 1.5;
    float dx = sdRoundRect(p + float2(e, 0.0), hs, radius) - sdRoundRect(p - float2(e, 0.0), hs, radius);
    float dy = sdRoundRect(p + float2(0.0, e), hs, radius) - sdRoundRect(p - float2(0.0, e), hs, radius);
    float2 g = float2(dx, dy);
    float2 n = g / max(length(g), 0.0001);
    float k = t * t * t;
    float2 src = coord - n * (k * strength);
    src = clamp(src, float2(0.5, 0.5), size - float2(0.5, 0.5));
    float4 c = float4(content.eval(src));
    float rim = smoothstep(0.55, 1.0, t);
    float3 lit = min(c.rgb * (1.0 + 0.10 * rim), float3(c.a, c.a, c.a));
    return half4(float4(lit, c.a));
}
"""

private object GlassFx {
    fun build(
        size: IntSize,
        blurPx: Float,
        saturation: Float,
        cornerPx: Float?,
        depthPx: Float,
        strengthPx: Float,
        shader: Any?,
    ): RenderEffect? {
        if (Build.VERSION.SDK_INT < 31) return null
        if (size.width <= 0 || size.height <= 0) return null
        val base = Api31.blurSaturate(blurPx.coerceAtLeast(1f), saturation)
        val lensed = if (cornerPx != null && shader != null && Build.VERSION.SDK_INT >= 33) {
            Api33.lens(shader, size.width.toFloat(), size.height.toFloat(), cornerPx, depthPx, strengthPx, base)
        } else {
            null
        }
        return (lensed ?: base).asComposeRenderEffect()
    }
}

@RequiresApi(31)
private object Api31 {
    fun blurSaturate(blurPx: Float, saturation: Float): android.graphics.RenderEffect {
        val blur = android.graphics.RenderEffect.createBlurEffect(blurPx, blurPx, Shader.TileMode.CLAMP)
        if (saturation == 1f) return blur
        val cm = ColorMatrix()
        cm.setSaturation(saturation)
        return android.graphics.RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(cm), blur)
    }
}

@RequiresApi(33)
private object Api33 {
    fun newShader(): Any? = try {
        RuntimeShader(LENS_SHADER)
    } catch (t: Throwable) {
        null
    }

    fun lens(
        shaderAny: Any,
        w: Float,
        h: Float,
        corner: Float,
        depth: Float,
        strength: Float,
        input: android.graphics.RenderEffect,
    ): android.graphics.RenderEffect? = try {
        val s = shaderAny as RuntimeShader
        s.setFloatUniform("size", w, h)
        s.setFloatUniform("radius", corner.coerceAtMost(minOf(w, h) / 2f))
        s.setFloatUniform("depth", depth.coerceAtLeast(1f))
        s.setFloatUniform("strength", strength)
        val lens = android.graphics.RenderEffect.createRuntimeShaderEffect(s, "content")
        android.graphics.RenderEffect.createChainEffect(lens, input)
    } catch (t: Throwable) {
        null
    }
}

/** Draws the backdrop under this element, blurred (and lensed). Renders nothing below Android 12. */
@Composable
fun BackdropLayer(
    backdrop: Backdrop,
    modifier: Modifier = Modifier,
    blur: Dp = 14.dp,
    saturation: Float = 1.6f,
    lensCorner: Dp? = null,
    lensDepth: Dp = 16.dp,
    lensStrength: Dp = 9.dp,
) {
    if (!glassSupported) return
    val density = LocalDensity.current
    var pos by remember { mutableStateOf(Offset.Zero) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    val wantsLens = lensCorner != null
    val shader: Any? = remember(wantsLens) {
        if (wantsLens && Build.VERSION.SDK_INT >= 33) Api33.newShader() else null
    }
    val effect = remember(size, blur, saturation, lensCorner, lensDepth, lensStrength, shader, density) {
        with(density) {
            GlassFx.build(
                size = size,
                blurPx = blur.toPx(),
                saturation = saturation,
                cornerPx = lensCorner?.toPx(),
                depthPx = lensDepth.toPx(),
                strengthPx = lensStrength.toPx(),
                shader = shader,
            )
        }
    }
    Box(
        modifier
            .onSizeChanged { size = it }
            .onGloballyPositioned { pos = it.positionInRoot() }
            .graphicsLayer {
                renderEffect = effect
                clip = true
            }
            .drawBehind {
                val o = pos - backdrop.origin
                translate(-o.x, -o.y) {
                    drawLayer(backdrop.layer)
                }
            },
    )
}

/** The Liquid Glass material. */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    corner: Dp = 22.dp,
    tint: Color? = null,
    pressed: Boolean = false,
    lens: Boolean = true,
    blur: Dp = 12.dp,
    elevation: Dp = 10.dp,
    backdrop: Backdrop? = LocalBackdrop.current,
    contentAlignment: Alignment = Alignment.Center,
    content: @Composable BoxScope.() -> Unit,
) {
    val ios = LocalIos.current
    val glassShape = RoundedCornerShape(corner)
    val scale by animateFloatAsState(
        targetValue = if (pressed) 1.07f else 1f,
        animationSpec = spring(dampingRatio = 0.48f, stiffness = 520f),
        label = "glassScale",
    )
    val glow by animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = spring(stiffness = 700f),
        label = "glassGlow",
    )
    val live = backdrop != null && glassSupported
    val fill = tint ?: if (live) ios.glassTint else ios.glassFallback
    Box(
        modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .then(
                if (elevation > 0.dp) {
                    Modifier.shadow(
                        elevation = elevation,
                        shape = glassShape,
                        clip = false,
                        ambientColor = Color.Black.copy(alpha = 0.10f),
                        spotColor = Color.Black.copy(alpha = 0.16f),
                    )
                } else {
                    Modifier
                },
            )
            .clip(glassShape),
        contentAlignment = contentAlignment,
    ) {
        if (backdrop != null && live) {
            BackdropLayer(
                backdrop = backdrop,
                modifier = Modifier.matchParentSize(),
                blur = blur,
                lensCorner = if (lens) corner else null,
            )
        }
        Box(Modifier.matchParentSize().background(fill))
        Box(
            Modifier
                .matchParentSize()
                .background(Brush.verticalGradient(listOf(ios.glassShine, Color.Transparent))),
        )
        if (glow > 0.01f) {
            Box(Modifier.matchParentSize().background(Color.White.copy(alpha = 0.16f * glow)))
        }
        Box(
            Modifier
                .matchParentSize()
                .border(
                    width = 0.8.dp,
                    brush = Brush.linearGradient(
                        listOf(ios.glassRim, ios.glassRimDim, ios.glassRimDim, ios.glassRim.copy(alpha = ios.glassRim.alpha * 0.7f)),
                    ),
                    shape = glassShape,
                ),
        )
        content()
    }
}

/** Round glass button (back, compose, ellipsis…). */
@Composable
fun GlassCircleButton(
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    iconSize: Dp = 21.dp,
    prominent: Boolean = false,
    iconTint: Color? = null,
    bounds: BoundsHolder? = null,
    contentDescription: String? = null,
) {
    val ios = LocalIos.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    GlassSurface(
        modifier = modifier
            .size(size)
            .then(if (bounds != null) Modifier.trackBounds(bounds) else Modifier)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        corner = size / 2,
        tint = if (prominent) ios.accent.copy(alpha = 0.94f) else null,
        pressed = pressed,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            modifier = Modifier.size(iconSize),
            tint = iconTint ?: if (prominent) ios.onAccent else ios.accent,
        )
    }
}

/** Capsule glass button with a text label ("Edit", "Done"). */
@Composable
fun GlassTextButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    bold: Boolean = false,
) {
    val ios = LocalIos.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    GlassSurface(
        modifier = modifier
            .height(44.dp)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        corner = 22.dp,
        pressed = pressed,
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 16.dp),
            style = TS.body.copy(fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Medium),
            color = ios.accent,
            maxLines = 1,
        )
    }
}

/** Glass capsule holding several icon buttons. */
@Composable
fun GlassPill(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    GlassSurface(modifier = modifier.height(44.dp), corner = 22.dp) {
        Row(Modifier.padding(horizontal = 3.dp), verticalAlignment = Alignment.CenterVertically) {
            content()
        }
    }
}

@Composable
fun PillButton(
    icon: ImageVector,
    onClick: () -> Unit,
    bounds: BoundsHolder? = null,
    iconSize: Dp = 20.dp,
    tint: Color = LocalIos.current.accent,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val a by animateFloatAsState(if (pressed) 1f else 0f, label = "pill")
    Box(
        Modifier
            .size(width = 42.dp, height = 44.dp)
            .then(if (bounds != null) Modifier.trackBounds(bounds) else Modifier)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(36.dp)
                .graphicsLayer { alpha = a }
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.22f)),
        )
        Icon(icon, contentDescription = null, modifier = Modifier.size(iconSize), tint = tint)
    }
}

/** iOS 26 "scroll edge effect": a soft progressive blur where content slides under the bars. */
@Composable
fun ScrollEdge(
    top: Boolean,
    height: Dp,
    color: Color,
    modifier: Modifier = Modifier,
    backdrop: Backdrop? = LocalBackdrop.current,
) {
    val live = backdrop != null && glassSupported
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                val mask = if (top) {
                    Brush.verticalGradient(0f to Color.Black, 0.45f to Color.Black, 1f to Color.Transparent)
                } else {
                    Brush.verticalGradient(0f to Color.Transparent, 0.55f to Color.Black, 1f to Color.Black)
                }
                drawRect(brush = mask, blendMode = BlendMode.DstIn)
            },
    ) {
        if (backdrop != null && live) {
            BackdropLayer(backdrop, Modifier.matchParentSize(), blur = 5.dp, saturation = 1.15f)
        }
        Box(Modifier.matchParentSize().background(color.copy(alpha = if (live) 0.62f else 0.9f)))
    }
}
