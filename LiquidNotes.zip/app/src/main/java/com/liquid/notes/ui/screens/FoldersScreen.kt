package com.liquid.notes.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.liquid.notes.data.DEFAULT_FOLDER
import com.liquid.notes.data.Folder
import com.liquid.notes.data.ListTarget
import com.liquid.notes.data.NoteText
import com.liquid.notes.ui.LocalNav
import com.liquid.notes.ui.LocalOverlay
import com.liquid.notes.ui.LocalStore
import com.liquid.notes.ui.LocalUpdates
import com.liquid.notes.ui.Screen
import com.liquid.notes.ui.components.BottomBar
import com.liquid.notes.ui.components.EmptyState
import com.liquid.notes.ui.components.GroupPos
import com.liquid.notes.ui.components.Hairline
import com.liquid.notes.ui.components.LargeTitle
import com.liquid.notes.ui.components.NavBar
import com.liquid.notes.ui.components.NoteListRow
import com.liquid.notes.ui.components.SearchField
import com.liquid.notes.ui.components.SectionHeader
import com.liquid.notes.ui.components.groupShape
import com.liquid.notes.ui.components.hasDivider
import com.liquid.notes.ui.components.noRippleClick
import com.liquid.notes.ui.components.posOf
import com.liquid.notes.ui.components.rememberNoteActions
import com.liquid.notes.ui.glass.BoundsHolder
import com.liquid.notes.ui.glass.GlassCircleButton
import com.liquid.notes.ui.glass.GlassTextButton
import com.liquid.notes.ui.glass.LocalBackdrop
import com.liquid.notes.ui.glass.ScrollEdge
import com.liquid.notes.ui.glass.backdropSource
import com.liquid.notes.ui.glass.rememberBackdrop
import com.liquid.notes.ui.glass.trackBounds
import com.liquid.notes.ui.icons.Sf
import com.liquid.notes.ui.overlay.AlertButton
import com.liquid.notes.ui.overlay.AlertRequest
import com.liquid.notes.ui.overlay.MenuAction
import com.liquid.notes.ui.overlay.MenuGroup
import com.liquid.notes.ui.overlay.MenuRequest
import com.liquid.notes.ui.theme.LocalIos
import com.liquid.notes.ui.theme.TS
import com.liquid.notes.util.LocalStrings

private class FolderEntry(
    val key: String,
    val title: String,
    val icon: ImageVector,
    val count: Int,
    val target: ListTarget,
    val folder: Folder?,
)

@Composable
fun FoldersScreen() {
    val store = LocalStore.current
    val data by store.data.collectAsState()
    val s = LocalStrings.current
    val ios = LocalIos.current
    val nav = LocalNav.current
    val overlay = LocalOverlay.current
    val updates = LocalUpdates.current
    val actions = rememberNoteActions()
    val backdrop = rememberBackdrop()
    val listState = rememberLazyListState()
    val openRow = remember { mutableStateOf<Any?>(null) }
    val menuBounds = remember { BoundsHolder() }
    var editing by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val collapsed by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 70 }
    }

    val live = remember(data) { data.notes.filter { it.deletedAt == null && !NoteText.isBlank(it.content) } }
    val deletedCount = remember(data) { data.notes.count { it.deletedAt != null } }
    val userFolders = remember(data) {
        data.folders.filter { it.id != DEFAULT_FOLDER }.sortedBy { it.name.lowercase() }
    }
    val rows = remember(live, deletedCount, userFolders, s) {
        buildList {
            if (userFolders.isNotEmpty()) add(FolderEntry("all", s.allNotes, Sf.Folder, live.size, ListTarget.All, null))
            add(
                FolderEntry(
                    DEFAULT_FOLDER, s.notes, Sf.Folder,
                    live.count { it.folderId == DEFAULT_FOLDER },
                    ListTarget.InFolder(DEFAULT_FOLDER), null,
                ),
            )
            userFolders.forEach { f ->
                add(FolderEntry(f.id, f.name, Sf.Folder, live.count { it.folderId == f.id }, ListTarget.InFolder(f.id), f))
            }
            if (deletedCount > 0) add(FolderEntry("deleted", s.recentlyDeleted, Sf.Trash, deletedCount, ListTarget.Deleted, null))
        }
    }

    fun nameTaken() {
        overlay.message(s.nameTaken, s.nameTakenMsg, s.ok)
    }

    fun newFolder() {
        overlay.alert = AlertRequest(
            title = s.newFolder,
            message = s.newFolderMsg,
            input = "",
            placeholder = s.name,
            buttons = listOf(
                AlertButton(s.cancel) { },
                AlertButton(s.save, bold = true, needsInput = true) { name ->
                    if (store.folderNameTaken(name, null, s.notes)) nameTaken() else store.createFolder(name)
                },
            ),
        )
    }

    fun renameFolder(f: Folder) {
        overlay.alert = AlertRequest(
            title = s.renameFolder,
            input = f.name,
            placeholder = s.name,
            buttons = listOf(
                AlertButton(s.cancel) { },
                AlertButton(s.save, bold = true, needsInput = true) { name ->
                    if (store.folderNameTaken(name, f.id, s.notes)) nameTaken() else store.renameFolder(f.id, name)
                },
            ),
        )
    }

    fun deleteFolder(f: Folder) {
        overlay.alert = AlertRequest(
            title = s.deleteFolder,
            message = s.deleteFolderMsg,
            buttons = listOf(
                AlertButton(s.cancel) { },
                AlertButton(s.delete, destructive = true) { store.deleteFolder(f.id) },
            ),
        )
    }

    fun folderMenu(f: Folder, anchor: Rect) {
        overlay.menu = MenuRequest(
            anchor = anchor,
            alignEnd = false,
            groups = listOf(
                MenuGroup(null, listOf(MenuAction(s.rename, Sf.Pencil) { renameFolder(f) })),
                MenuGroup(null, listOf(MenuAction(s.deleteFolder, Sf.Trash, destructive = true) { deleteFolder(f) })),
            ),
        )
    }

    fun moreMenu() {
        overlay.menu = MenuRequest(
            anchor = menuBounds.rect,
            alignEnd = true,
            groups = listOf(
                MenuGroup(
                    null,
                    listOf(
                        MenuAction(s.newFolder, Sf.FolderPlus) { newFolder() },
                        MenuAction(if (editing) s.done else s.edit, Sf.Pencil) { editing = !editing },
                    ),
                ),
                MenuGroup(
                    null,
                    listOf(
                        MenuAction(if (updates.checking) s.checking else s.checkUpdates, Sf.Download) { updates.check(silent = false) },
                        MenuAction(s.currentVersion(updates.versionName), Sf.Info, enabled = false) { },
                    ),
                ),
            ),
        )
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .backdropSource(backdrop)
                .background(ios.background),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = top + 56.dp, bottom = bottom + 110.dp),
        ) {
            item(key = "title") { LargeTitle(s.folders) }
            item(key = "search") { SearchField(query, { query = it }) }
            val q = query.trim()
            if (q.isEmpty()) {
                item(key = "header") { SectionHeader(s.onMyPhone) }
                itemsIndexed(rows, key = { _, r -> "row_" + r.key }) { i, r ->
                    FolderRow(
                        entry = r,
                        pos = posOf(i, rows.size),
                        editing = editing,
                        onClick = {
                            val f = r.folder
                            if (editing && f != null) renameFolder(f) else nav.push(Screen.Notes(r.target))
                        },
                        onLongPress = { rect -> r.folder?.let { folderMenu(it, rect) } },
                        onDelete = { r.folder?.let { deleteFolder(it) } },
                    )
                }
            } else {
                val results = live
                    .filter { it.content.contains(q, ignoreCase = true) }
                    .sortedByDescending { it.modifiedAt }
                if (results.isEmpty()) {
                    item(key = "empty") { EmptyState(s.noResults) }
                } else {
                    item(key = "res_header") { SectionHeader(s.notesCount(results.size)) }
                    itemsIndexed(results, key = { _, n -> n.id }) { i, n ->
                        NoteListRow(
                            note = n,
                            pos = posOf(i, results.size),
                            openId = openRow,
                            actions = actions,
                            deletedMode = false,
                            showFolder = true,
                        )
                    }
                }
            }
        }

        CompositionLocalProvider(LocalBackdrop provides backdrop) {
            ScrollEdge(top = true, height = top + 66.dp, color = ios.background, modifier = Modifier.align(Alignment.TopCenter))
            ScrollEdge(top = false, height = bottom + 86.dp, color = ios.background, modifier = Modifier.align(Alignment.BottomCenter))
            NavBar(
                title = s.folders,
                showTitle = collapsed,
                right = {
                    if (editing) {
                        GlassTextButton(s.done, onClick = { editing = false }, bold = true)
                    } else {
                        GlassCircleButton(Sf.Ellipsis, onClick = { moreMenu() }, bounds = menuBounds)
                    }
                },
            )
            BottomBar(
                modifier = Modifier.align(Alignment.BottomCenter),
                left = { GlassCircleButton(Sf.FolderPlus, onClick = { newFolder() }, iconSize = 23.dp) },
                right = {
                    GlassCircleButton(Sf.Compose, onClick = {
                        val id = store.createNote(DEFAULT_FOLDER)
                        nav.push(Screen.Editor(id))
                    }, iconSize = 22.dp)
                },
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderRow(
    entry: FolderEntry,
    pos: GroupPos,
    editing: Boolean,
    onClick: () -> Unit,
    onLongPress: (Rect) -> Unit,
    onDelete: () -> Unit,
) {
    val ios = LocalIos.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val bounds = remember { BoundsHolder() }
    val canEdit = entry.folder != null
    Column(
        Modifier
            .fillMaxWidth()
            .clip(groupShape(pos))
            .background(if (pressed) ios.pressed else ios.card)
            .trackBounds(bounds)
            .combinedClickable(
                interactionSource = src,
                indication = null,
                onLongClick = if (canEdit && !editing) ({ onLongPress(bounds.rect) }) else null,
                onClick = onClick,
            ),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(52.dp)
                .padding(start = 16.dp, end = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AnimatedVisibility(visible = editing && canEdit) {
                Box(
                    Modifier
                        .padding(end = 12.dp)
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(ios.red)
                        .noRippleClick(onClick = onDelete),
                    contentAlignment = Alignment.Center,
                ) {
                    Box(Modifier.size(width = 10.dp, height = 2.dp).background(Color.White))
                }
            }
            Icon(entry.icon, null, Modifier.size(25.dp), tint = ios.accent)
            Spacer(Modifier.width(14.dp))
            Text(
                entry.title,
                style = TS.body,
                color = ios.label,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Text(entry.count.toString(), style = TS.body, color = ios.secondaryLabel)
            Spacer(Modifier.width(8.dp))
            Icon(
                if (editing && canEdit) Sf.Pencil else Sf.ChevronRight,
                null,
                Modifier.size(if (editing && canEdit) 16.dp else 13.dp),
                tint = ios.tertiaryLabel,
            )
        }
        if (pos.hasDivider) Hairline(start = 55.dp)
    }
}
