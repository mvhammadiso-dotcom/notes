package com.liquid.notes.ui

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import com.liquid.notes.data.ListTarget
import com.liquid.notes.data.NotesStore
import com.liquid.notes.ui.overlay.OverlayState
import com.liquid.notes.ui.update.UpdateController

sealed interface Screen {
    val key: String

    data object Folders : Screen {
        override val key: String get() = "folders"
    }

    data class Notes(val target: ListTarget) : Screen {
        override val key: String get() = "notes:" + target.key
    }

    data class Editor(val noteId: String) : Screen {
        override val key: String get() = "editor:$noteId"
    }
}

/** Minimal iOS-style navigation stack. */
@Stable
class Navigator(initial: List<Screen>, private val onRemoved: (Screen) -> Unit) {
    val stack = mutableStateListOf<Screen>().also { it.addAll(initial) }

    var lastWasPush by mutableStateOf(true)
        private set

    val current: Screen get() = stack[stack.size - 1]

    val canPop: Boolean get() = stack.size > 1

    fun push(screen: Screen) {
        if (current == screen) return
        lastWasPush = true
        stack.add(screen)
    }

    fun pop(): Boolean {
        if (stack.size <= 1) return false
        lastWasPush = false
        val removed = stack.removeAt(stack.size - 1)
        onRemoved(removed)
        return true
    }

    fun replaceTop(screen: Screen) {
        lastWasPush = true
        val removed = stack.removeAt(stack.size - 1)
        stack.add(screen)
        onRemoved(removed)
    }
}

val LocalStore = staticCompositionLocalOf<NotesStore> { error("NotesStore not provided") }
val LocalNav = staticCompositionLocalOf<Navigator> { error("Navigator not provided") }
val LocalOverlay = staticCompositionLocalOf<OverlayState> { error("OverlayState not provided") }
val LocalUpdates = staticCompositionLocalOf<UpdateController> { error("UpdateController not provided") }
